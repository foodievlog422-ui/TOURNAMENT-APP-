#!/bin/sh
# Start MariaDB for the EXALOTE EXN project (bind 127.0.0.1:3306).
# Usage: sh start_db.sh
if pgrep -l 'mariadbd|mysqld' > /dev/null; then
  echo "MariaDB already running"
  exit 0
fi
exec mariadbd \
  --datadir=/var/lib/mysql \
  --skip-networking=0 \
  --bind-address=127.0.0.1 \
  --port=3306 \
  --innodb-buffer-pool-size=32M \
  --innodb-log-file-size=16M \
  --key-buffer-size=8M \
  --max-connections=20 \
  --performance-schema=OFF \
  --skip-name-resolve \
  --user=root
