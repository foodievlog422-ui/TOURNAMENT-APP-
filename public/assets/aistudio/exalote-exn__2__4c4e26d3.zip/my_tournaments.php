<?php
/**
 * EXALOTE EXN — My Matches: registrations, history + custom requests.
 */
require_once __DIR__ . '/common/config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$uid = current_user_id();
$user = current_user();

$upcoming = db()->prepare("
    SELECT r.id AS reg_id, r.status AS reg_status, m.*, c.name AS cat_name, c.format AS cat_format
    FROM registrations r
    JOIN matches m ON m.id = r.match_id
    JOIN categories c ON c.id = m.category_id
    WHERE r.user_id = ? AND m.status IN ('Upcoming','Live')
    ORDER BY m.match_date ASC, m.start_time ASC
");
$upcoming->execute([$uid]);
$upcoming = $upcoming->fetchAll();

$history = db()->prepare("
    SELECT r.status AS reg_status, m.*, c.name AS cat_name, c.format AS cat_format, wu.username AS winner_name
    FROM registrations r
    JOIN matches m ON m.id = r.match_id
    JOIN categories c ON c.id = m.category_id
    LEFT JOIN users wu ON wu.id = m.winner_user_id
    WHERE r.user_id = ? AND m.status IN ('Completed','Cancelled')
    ORDER BY m.match_date DESC, m.start_time DESC
");
$history->execute([$uid]);
$history = $history->fetchAll();

$requests = db()->prepare('SELECT * FROM custom_requests WHERE user_id = ? ORDER BY created_at DESC');
$requests->execute([$uid]);
$requests = $requests->fetchAll();

// ---- Submit / update result claim (screenshot + kill/rank + hack report) ----
$claimError = null;
$claimOk = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_claim'])) {
    csrf_verify();
    $mid = (int)($_POST['match_id'] ?? 0);
    $rank = max(0, (int)($_POST['claimed_rank'] ?? 0));
    $kills = max(0, (int)($_POST['claimed_kills'] ?? 0));
    $suspect = trim((string)($_POST['report_suspect_ign'] ?? ''));
    $reason = trim((string)($_POST['report_reason'] ?? ''));

    // Must be an Approved registration for the match.
    $reg = db()->prepare("SELECT id FROM registrations WHERE match_id = ? AND user_id = ? AND status = 'Approved'");
    $reg->execute([$mid, $uid]);
    if (!$reg->fetch()) {
        $claimError = 'You can only submit a result claim for a match you are approved in.';
    } elseif ($rank === 0 && $kills === 0 && $suspect === '' && $reason === '') {
        $claimError = 'Enter at least a kill count or rank.';
    } else {
        $screenshot = null;
        if (!empty($_FILES['screenshot']) && ($_FILES['screenshot']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $f = $_FILES['screenshot'];
            if ($f['error'] !== UPLOAD_ERR_OK) {
                $claimError = 'Screenshot upload failed (error ' . (int)$f['error'] . ').';
            } elseif ($f['size'] > 5 * 1024 * 1024) {
                $claimError = 'Screenshot must be under 5MB.';
            } else {
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($f['tmp_name']);
                $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
                if (!isset($allowed[$mime])) {
                    $claimError = 'Only JPG, PNG or WEBP screenshots are allowed.';
                } else {
                    $random = bin2hex(random_bytes(12));
                    $path = 'uploads/results/' . $random . '.' . $allowed[$mime];
                    if (!move_uploaded_file($f['tmp_name'], __DIR__ . '/' . $path)) {
                        $claimError = 'Could not save screenshot.';
                    } else {
                        $screenshot = $path;
                    }
                }
            }
        }

        if (!$claimError) {
            db()->prepare("
                INSERT INTO match_claims (match_id, user_id, claimed_kills, claimed_rank, screenshot_path, report_suspect_ign, report_reason, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
                ON DUPLICATE KEY UPDATE
                  claimed_kills = VALUES(claimed_kills),
                  claimed_rank = VALUES(claimed_rank),
                  screenshot_path = COALESCE(VALUES(screenshot_path), screenshot_path),
                  report_suspect_ign = VALUES(report_suspect_ign),
                  report_reason = VALUES(report_reason),
                  status = 'pending'
            ")->execute([$mid, $uid, $kills, $rank, $screenshot, $suspect ?: null, $reason ?: null]);
            $claimOk = 'Claim submitted for admin verification.';
        }
    }
}

// Load any existing claims for the user.
$claims = [];
$cs = db()->prepare('SELECT * FROM match_claims WHERE user_id = ?');
$cs->execute([$uid]);
foreach ($cs->fetchAll() as $c) {
    $claims[(int)$c['match_id']] = $c;
}

function reg_chip(string $status): string
{
    return match ($status) {
        'Approved' => '<span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-green-500/15 text-green-300 border border-green-500/40">Approved</span>',
        'Pending'  => '<span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-yellow-500/15 text-yellow-300 border border-yellow-500/40">Pending</span>',
        'Rejected' => '<span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-gray-700 text-gray-400 border border-gray-700">Rejected</span>',
        'Completed' => '<span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-green-500/15 text-green-300 border border-green-500/40">Played</span>',
        'Cancelled' => '<span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-gray-700 text-gray-400 border border-gray-700">Cancelled</span>',
        default => '<span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full bg-gray-700 text-gray-400 border border-gray-700">' . htmlspecialchars($status) . '</span>',
    };
}
?>
<?php $page_title = 'My Matches'; $active_tab = 'matches'; require __DIR__ . '/common/header.php'; ?>

<?php if ($claimOk): ?>
  <div class="mb-4 px-4 py-3 rounded-2xl border text-sm font-medium bg-green-500/10 border-green-500/30 text-green-300">
    <i class="fa-solid fa-circle-check mr-2"></i><?= e($claimOk) ?>
  </div>
<?php elseif ($claimError): ?>
  <div class="mb-4 px-4 py-3 rounded-2xl border text-sm font-medium bg-red-500/10 border-red-500/30 text-red-300">
    <i class="fa-solid fa-circle-exclamation mr-2"></i><?= e($claimError) ?>
  </div>
<?php endif; ?>

<!-- Points card -->
<section class="fade-up relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#7a0b1c] to-black p-5 ring-1 ring-red-500/30">
  <div class="absolute -bottom-8 -right-8 w-36 h-36 rounded-full bg-red-500/20 blur-2xl"></div>
  <div class="relative flex items-center justify-between">
    <div>
      <p class="text-red-200/90 text-xs font-semibold tracking-widest uppercase">My Virtual Points</p>
      <div class="text-4xl font-extrabold text-white mt-1"><?= (int)$user['virtual_points'] ?></div>
    </div>
    <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-600 flex items-center justify-center text-white text-2xl shadow-lg shadow-yellow-500/30">
      <i class="fa-solid fa-star"></i>
    </div>
  </div>
</section>

<!-- Upcoming registrations -->
<section class="mt-6">
  <h2 class="font-bold text-white mb-3">My Upcoming Matches</h2>
  <?php if (!$upcoming): ?>
    <div class="text-center py-8 text-gray-500 text-sm">You have no upcoming registrations.</div>
  <?php endif; ?>
  <?php foreach ($upcoming as $m): ?>
    <div class="mb-3 bg-[#121212] border border-gray-800 rounded-2xl p-4">
      <div class="flex items-start justify-between">
        <div>
          <div class="font-bold text-white"><?= e($m['cat_name']) ?></div>
          <div class="text-[11px] text-gray-500 mt-0.5">
            <span class="inline-block bg-red-500/10 text-red-400 text-[10px] font-bold px-2 py-0.5 rounded-full mr-1.5"><?= e($m['cat_format']) ?></span>
            <?= e($m['match_date']) ?> · <?= e(date('h:i A', strtotime($m['start_time']))) ?> IST
          </div>
        </div>
        <?= reg_chip($m['reg_status']) ?>
      </div>
      <div class="mt-3 flex items-center gap-2 text-gray-400 text-xs">
        <i class="fa-solid fa-network-wired text-red-500"></i>
        <span><?= e($m['status']) ?> · <?= e($m['session']) ?> session</span>
      </div>

      <?php if ($m['reg_status'] === 'Approved' && $m['status'] === 'Live'): ?>
        <?php $my = $claims[(int)$m['id']] ?? null; ?>
        <form method="post" enctype="multipart/form-data" class="mt-3 bg-black/30 border border-gray-800 rounded-xl p-3 space-y-2">
          <input type="hidden" name="action" value="submit_claim">
          <input type="hidden" name="match_id" value="<?= (int)$m['id'] ?>">
          <?= csrf_field() ?>
          <div class="text-xs font-bold text-white uppercase"><i class="fa-solid fa-upload mr-1 text-red-500"></i>Submit Result</div>
          <div class="grid grid-cols-2 gap-2">
            <div>
              <label class="text-[10px] text-gray-500 uppercase">Kills</label>
              <input type="number" name="claimed_kills" min="0" value="<?= (int)($my['claimed_kills'] ?? 0) ?>" class="mt-1 w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-sm text-center outline-none focus:border-red-500/60">
            </div>
            <div>
              <label class="text-[10px] text-gray-500 uppercase">Rank</label>
              <input type="number" name="claimed_rank" min="0" value="<?= (int)($my['claimed_rank'] ?? 0) ?>" class="mt-1 w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-sm text-center outline-none focus:border-red-500/60">
            </div>
          </div>
          <div>
            <label class="text-[10px] text-gray-500 uppercase">Screenshot proof (JPG/PNG/WEBP, up to 5MB)</label>
            <input type="file" name="screenshot" accept="image/jpeg,image/png,image/webp" class="mt-1 w-full text-xs text-gray-400 file:mr-3 file:rounded-lg file:border-0 file:bg-[#1a1a1a] file:px-3 file:py-2 file:text-xs file:text-gray-300">
          </div>
          <div class="grid grid-cols-2 gap-2">
            <div>
              <label class="text-[10px] text-gray-500 uppercase">Suspect IGN (optional)</label>
              <input type="text" name="report_suspect_ign" maxlength="100" value="<?= e($my['report_suspect_ign'] ?? '') ?>" class="mt-1 w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-xs outline-none focus:border-red-500/60">
            </div>
            <div>
              <label class="text-[10px] text-gray-500 uppercase">Report reason (optional)</label>
              <input type="text" name="report_reason" maxlength="200" value="<?= e($my['report_reason'] ?? '') ?>" class="mt-1 w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-xs outline-none focus:border-red-500/60">
            </div>
          </div>
          <button type="submit" name="submit_claim" value="1" class="w-full bg-red-600 hover:bg-red-500 text-white text-xs font-bold py-2.5 rounded-xl transition">
            <i class="fa-solid fa-paper-plane mr-1"></i><?= $my ? 'Update Claim' : 'Submit Claim' ?>
          </button>
        </form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</section>

<!-- History -->
<section class="mt-6">
  <h2 class="font-bold text-white mb-3">Match History</h2>
  <?php if (!$history): ?>
    <div class="text-center py-8 text-gray-500 text-sm">No completed matches yet.</div>
  <?php endif; ?>
  <?php foreach ($history as $m): ?>
    <div class="mb-3 bg-[#121212] border border-gray-800 rounded-2xl p-4 opacity-90">
      <div class="flex items-start justify-between">
        <div>
          <div class="font-bold text-white"><?= e($m['cat_name']) ?></div>
          <div class="text-[11px] text-gray-500 mt-0.5">
            <?= e($m['match_date']) ?> · <?= e(date('h:i A', strtotime($m['start_time']))) ?> IST
          </div>
        </div>
        <?= reg_chip($m['status']) ?>
      </div>
      <div class="mt-3 text-xs text-gray-400">
        <?php if ($m['status'] === 'Completed'): ?>
          Winner: <span class="text-yellow-400 font-semibold"><?= e($m['winner_name'] ?: '—') ?></span>
        <?php else: ?>
          This match was cancelled.
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</section>

<!-- Custom requests -->
<section class="mt-6 mb-4">
  <h2 class="font-bold text-white mb-3">Custom Match Requests</h2>
  <?php if (!$requests): ?>
    <div class="text-center py-6 text-gray-500 text-sm">No custom requests yet. You can request one from the home page.</div>
  <?php endif; ?>
  <?php foreach ($requests as $q): ?>
    <div class="mb-3 bg-[#121212] border border-gray-800 rounded-2xl p-4">
      <div class="flex items-start justify-between">
        <div>
          <div class="font-bold text-white"><?= e($q['title']) ?></div>
          <div class="text-[11px] text-gray-500 mt-0.5">
            <?= e($q['category_name']) ?> · <?= e($q['format']) ?> · <?= e($q['match_date']) ?> <?= e($q['start_time']) ?>
          </div>
          <?php if ($q['notes']): ?>
            <div class="text-[11px] text-gray-400 mt-2 bg-black/30 border border-gray-800 rounded-lg px-3 py-2"><?= e($q['notes']) ?></div>
          <?php endif; ?>
        </div>
        <?= reg_chip($q['status']) ?>
      </div>
    </div>
  <?php endforeach; ?>
</section>

<?php require __DIR__ . '/common/bottom.php'; ?>
