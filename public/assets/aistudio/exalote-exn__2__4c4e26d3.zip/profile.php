<?php
/**
 * EXALOTE EXN — User profile: username, password, UPI ID, logout.
 */
require_once __DIR__ . '/common/config.php';
require_once __DIR__ . '/common/header.php';

$userId = current_user_id();
$user = current_user();
$flash = null;

// ---- Update profile ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    csrf_verify();
    $username = trim($_POST['username'] ?? '');
    $upi = trim($_POST['upi_id'] ?? '');
    $ffUid = trim($_POST['ff_uid'] ?? '');
    $ffIgn = trim($_POST['ff_ign'] ?? '');

    if ($username === '') {
        $flash = ['type' => 'error', 'text' => 'Username cannot be empty.'];
    } elseif ($ffUid !== '' && !preg_match('/^\d{8,12}$/', $ffUid)) {
        $flash = ['type' => 'error', 'text' => 'Free Fire UID must be 8–12 digits.'];
    } elseif ($ffIgn !== '' && mb_strlen($ffIgn) > 60) {
        $flash = ['type' => 'error', 'text' => 'In-Game Name is too long (max 60 chars).'];
    } else {
        $dup = db()->prepare('SELECT id FROM users WHERE username = ? AND id != ?');
        $dup->execute([$username, $userId]);
        if ($dup->fetch()) {
            $flash = ['type' => 'error', 'text' => 'That username is already taken.'];
        } else {
            db()->prepare('UPDATE users SET username = ?, upi_id = ?, ff_uid = ?, ff_ign = ? WHERE id = ?')
                ->execute([$username, $upi !== '' ? $upi : null, $ffUid !== '' ? $ffUid : null, $ffIgn !== '' ? $ffIgn : null, $userId]);
            $flash = ['type' => 'success', 'text' => 'Profile updated successfully.'];
            $user = current_user();
        }
    }
}

// ---- Change password ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    csrf_verify();
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $user['password'])) {
        $flash = ['type' => 'error', 'text' => 'Current password is incorrect.'];
    } elseif (strlen($new) < 6) {
        $flash = ['type' => 'error', 'text' => 'New password must be at least 6 characters.'];
    } elseif ($new !== $confirm) {
        $flash = ['type' => 'error', 'text' => 'New passwords do not match.'];
    } else {
        db()->prepare('UPDATE users SET password = ? WHERE id = ?')
            ->execute([password_hash($new, PASSWORD_BCRYPT), $userId]);
        $flash = ['type' => 'success', 'text' => 'Password changed successfully.'];
    }
}

// ---- Logout ----
if (isset($_GET['logout'])) {
    session_destroy();
    redirect('login.php');
}
?>
<?php if ($flash): ?>
  <div class="mb-4 rounded-xl px-4 py-3 text-sm flex items-center gap-2 <?= $flash['type'] === 'error' ? 'bg-red-500/10 border border-red-500/30 text-red-300' : 'bg-green-500/10 border border-green-500/30 text-green-300' ?>">
    <i class="fa-solid <?= $flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<!-- Profile header -->
<div class="flex items-center gap-4 mb-6">
  <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center text-white text-2xl font-extrabold shadow-lg shadow-indigo-500/30">
    <?= e(strtoupper(substr($user['username'], 0, 1))) ?>
  </div>
  <div>
    <h2 class="text-xl font-extrabold"><?= e($user['username']) ?></h2>
    <div class="text-sm text-gray-400"><?= e($user['email']) ?></div>
  </div>
</div>

<!-- Edit profile -->
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mb-4">
  <h3 class="font-bold mb-4 flex items-center gap-2">
    <i class="fa-solid fa-user-pen text-indigo-400"></i>Profile Details
  </h3>
  <form method="post" class="space-y-4">
    <?= csrf_field() ?>
    <div>
      <label class="text-xs text-gray-400 mb-1 block">Username</label>
      <input type="text" name="username" value="<?= e($user['username']) ?>" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500">
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Free Fire UID <span class="text-red-400">*</span></label>
        <input type="text" name="ff_uid" inputmode="numeric" value="<?= e($user['ff_uid'] ?? '') ?>" placeholder="8–12 digits" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">IGN <span class="text-red-400">*</span></label>
        <input type="text" name="ff_ign" maxlength="60" value="<?= e($user['ff_ign'] ?? '') ?>" placeholder="In-Game Name" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500">
      </div>
    </div>
    <?php if (empty($user['ff_uid']) || empty($user['ff_ign'])): ?>
      <div class="rounded-lg bg-red-500/10 border border-red-500/30 px-3 py-2 text-xs text-red-300">
        <i class="fa-solid fa-circle-exclamation mr-1"></i>Binding your Free Fire UID &amp; IGN is required to join matches.
      </div>
    <?php endif; ?>
    <div>
      <label class="text-xs text-gray-400 mb-1 block">UPI ID <span class="text-gray-600">(for withdrawals)</span></label>
      <input type="text" name="upi_id" value="<?= e($user['upi_id'] ?? '') ?>" placeholder="yourname@upi" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500">
    </div>
    <button type="submit" name="update_profile" value="1"
      class="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl py-3 text-sm transition">
      <i class="fa-solid fa-floppy-disk mr-2"></i>Save Profile
    </button>
  </form>
</div>

<!-- Change password -->
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mb-4">
  <h3 class="font-bold mb-4 flex items-center gap-2">
    <i class="fa-solid fa-lock text-amber-400"></i>Change Password
  </h3>
  <form method="post" class="space-y-3">
    <?= csrf_field() ?>
    <div>
      <label class="text-xs text-gray-400 mb-1 block">Current Password</label>
      <input type="password" name="current_password" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs text-gray-400 mb-1 block">New Password</label>
        <input type="password" name="new_password" required minlength="6" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Confirm</label>
        <input type="password" name="confirm_password" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
      </div>
    </div>
    <button type="submit" name="change_password" value="1"
      class="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl py-3 text-sm transition">
      <i class="fa-solid fa-rotate mr-2"></i>Update Password
    </button>
  </form>
</div>

<!-- Logout -->
<a href="profile.php?logout=1"
  class="w-full flex items-center justify-center gap-2 bg-red-500/10 border border-red-500/30 text-red-300 font-semibold rounded-xl py-3 text-sm hover:bg-red-500/20 transition">
  <i class="fa-solid fa-right-from-bracket"></i>Logout
</a>

<?php $active_tab = 'profile'; require_once __DIR__ . '/common/bottom.php'; ?>
