# EXALOTE EXN — Deployment & Installation Guide

A PHP 8+ / MySQL tournament app. Dark mobile-first UI, optional wallet (UPI),
auto-scheduling, notifications and leaderboards.

---

## 1. Requirements (host)

| Requirement | Version / detail |
|---|---|
| PHP | **8.1+** (recommended 8.2). PHP 8.0+ minimum. |
| Extensions | `pdo`, `pdo_mysql` (required), `session`, `openssl`, `json`, `mbstring`, `fileinfo`, `ctype`, `filter`, `curl` (recommended). |
| Database | MySQL / MariaDB **10.2+** (recommended 10.4+). `utf8mb4`. |
| Web server | Apache (with `mod_rewrite` + `.htaccess`) or nginx. |
| Cron | Optional — the app falls back to auto-running scheduling/reminders on page load if no cron exists. |
| Python | **Only if you run the optional FamPay auto-verify gateway.** Free shared hosts usually do NOT support a persistent Python daemon. See §6. |

**Hosting honesty check:** typical free PHP hosting (e.g. InfinityFree,
000webhost, AwardSpace) gives you PHP+MySQL and sometimes cron, but **not** a
persistent Python service. The app fully works without Python using the
**manual-UTR deposit mode** (§6.2).

---

## 2. Database setup

Two options:

**Option A — import schema (simplest)**
```bash
mariadb -u root -p < database.sql
```

**Option B — web installer (token-protected)**
1. Set the `INSTALLER_TOKEN` env or `common/config.local.php` (see §3).
2. Open `install.php?token=YOUR_TOKEN`.
3. The installer creates the DB, tables, default admin and settings.
4. Never run the installer with the default token — it is refused.

**Migrations** — `update_database.php` only **adds** new columns/tables and is
safe to re-run. Use `update_database.php?token=YOUR_TOKEN`.

---

## 3. Configuration (secrets)

Copy `common/config.local.php.example` → `common/config.local.php` and fill in
values, OR export environment variables. **No hardcoded secrets remain.**

| Variable | Purpose |
|---|---|
| `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` | Database connection |
| `INSTALLER_TOKEN` | Protects installer/migrations (refused if default) |
| `GATEWAY_BASE` | URL of the optional gateway service (default `http://127.0.0.1:8666`) |
| `GATEWAY_HOOK_SECRET` | Shared secret between the gateway and `api/payment-hook.php` |
| `GMAIL_ADDRESS`, `GMAIL_APP_PASSWORD`, `FAMPAY_UPI_ID` | Only used by the Python gateway |

All values fall back to safe defaults; set the production ones.

---

## 4. First login & admin password

- Admin login: `/admin/login.php`.
- Default admin `admin` / `admin123` — **you are forced to change the password on
  first login** (all admin pages redirect to the change-password screen until you do).

---

## 5. Cron (optional but recommended)

If your host supports cron:
```
# Auto-generate daily matches (every hour, minute 30)
30 * * * * /usr/bin/php /path/to/exn/cron/auto_schedule.php

# Match reminders / notifications (every 5 minutes)
*/5 * * * * /usr/bin/php /path/to/exn/cron/send_notifications.php
```
If no cron exists, the app auto-runs both on page load (throttled).

---

## 6. Wallet / payments

The wallet is controlled by the **Wallet Features** toggle in admin → Settings.

### 6.1 Auto-verify mode (requires the Python gateway)
Only if your host runs Python services. Start the gateway:
```bash
cd payment
GMAIL_ADDRESS="you@gmail.com" \
GMAIL_APP_PASSWORD="your-app-password" \
FAMPAY_UPI_ID="yournumber@fam" \
GATEWAY_HOOK_SECRET="same-secret-as-php" \
sh start_gateway.sh start
```
Set `GATEWAY_HOOK_SECRET` to the **same value** as the PHP app's
`GATEWAY_HOOK_SECRET`. The gateway's sqlite ledger (`payment/gateway.db`) is only
its internal pending-payment/UTR record; **the MySQL `users.wallet_balance` is
the single source of truth** — PHP only ever trusts `api/payment-hook.php`.

### 6.2 Manual-UTR mode (works anywhere, no Python)
1. Users enter amount + UPI Transaction Reference (UTR) on the Wallet page.
2. It appears as a **Pending** deposit in admin → Deposits.
3. Admin verifies the UTR and clicks **Approve** → balance is credited.
This uses the same `deposits`/`transactions` tables.

---

## 7. Android / PWA install (optional)

1. Open the app URL in Chrome.
2. Menu → **Add to Home screen**.
3. It launches full-screen like an app (theme color `#0a0a0a`).

---

## 8. Security notes

- All POST forms are CSRF-protected (`csrf_field()`/`csrf_verify()`).
- Login is rate-limited (5 failed attempts / 15 min per IP+username).
- Session cookies are `HttpOnly`, `SameSite=Lax`, `Secure` over HTTPS.
- Errors are logged to `storage/app.log`, never displayed.
- `.htaccess` blocks `common/`, `cron/`, `payment/`, `storage/`, and
  `.sql`/`.log`/`.md`/`.py`/`.local` files.

---

## 9. Manual test checklist

1. **Signup** — create an account, log in.
2. **Deposit (manual)** — enter amount + UTR on Wallet → appears Pending in
   admin → Approve → balance credited, transaction logged.
3. **Join with fee** — create a match with an entry fee → join with enough
   balance → fee debited, registration Pending.
4. **Low-balance join** — join a fee match with too little balance → clear
   "Insufficient" error, nothing deducted.
5. **Reject refund** — reject a paid registration → fee credited back once.
6. **Cancel match** — cancel a match → every paid player refunded once.
7. **Withdraw** — request a withdrawal → balance deducted, Pending in admin.
8. **Double-click withdraw** — submit twice fast → only one withdrawal/one debit.
9. **Admin result publish** — publish results → points awarded to leaderboard,
   cash credited only if wallet enabled; duplicate publish blocked.
10. **Wallet toggle** — disable wallet → deposit/withdraw hidden, `api/payment.php`
    returns 403, fee deduction skipped.
