<?php
/**
 * EXALOTE EXN — Installer
 * Creates the database, all tables, default admin (admin/admin123) and settings.
 * Safe to run multiple times (idempotent).
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

define('EXN_INSTALLING', true);
require_once __DIR__ . '/common/config.php';

// --- Installer gate: requires the INSTALLER_TOKEN (GET ?token=) ---
$ok = false;
if (!empty($_GET['token']) && !INSTALLER_TOKEN_IS_DEFAULT) {
    $ok = hash_equals(INSTALLER_TOKEN, (string)$_GET['token']);
}
if (!$ok) {
    http_response_code(403);
    die(
        '<div style="font-family:system-ui;max-width:480px;margin:80px auto;padding:24px;' .
        'background:#111;color:#eee;border-radius:14px;border:1px solid #333">' .
        '<h2 style="margin-top:0;color:#ff5c5c">Access denied</h2>' .
        '<p>This installer is protected. Set the <code>INSTALLER_TOKEN</code> environment ' .
        'variable and access this page as <code>install.php?token=YOUR_TOKEN</code>.</p>' .
        '<p style="color:#888;font-size:13px">Default token is never accepted for safety.</p>' .
        '</div>'
    );
}

// Disable after a successful install.
$lock = __DIR__ . '/storage/installed.lock';
if (is_file($lock)) {
    http_response_code(403);
    die('<p style="font-family:system-ui;color:#ff5c5c;text-align:center;margin-top:80px">Install has already run. Delete storage/installed.lock only to re-run on a fresh database.</p>');
}

$step = $_GET['step'] ?? 'run';
$host = DB_HOST;
$user = DB_USER;
$pass = DB_PASS;

// Bootstrap connection without selecting a database yet.
try {
    $pdo = new PDO("mysql:host={$host};charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
} catch (PDOException $e) {
    die('Unable to connect to MySQL. Please set DB_HOST/DB_USER/DB_PASS environment variables (or defaults in common/config.php).');
}

if ($step === 'run') {
    $pdo->exec("CREATE DATABASE IF NOT EXISTS tournament_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE tournament_app");

    $sql = file_get_contents(__DIR__ . '/database.sql');
    // database.sql contains CREATE DATABASE/USE; strip those lines for a clean run.
    $sql = preg_replace('/CREATE DATABASE.*?;/s', '', $sql);
    $sql = preg_replace('/^USE tournament_app;/m', '', $sql);
    $pdo->exec($sql);

    // Ensure default admin exists (password_hash regenerate-safe)
    $stmt = $pdo->prepare("SELECT id FROM admin WHERE username = ?");
    $stmt->execute(['admin']);
    if (!$stmt->fetch()) {
        $hash = password_hash('admin123', PASSWORD_BCRYPT);
        $ins = $pdo->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
        $ins->execute(['admin', $hash]);
    }

    // Ensure a single settings row exists.
    $pdo->prepare(
        "INSERT INTO settings (id, upi_id) VALUES (1, 'admin@upi')
         ON DUPLICATE KEY UPDATE id = id"
    )->execute();

    $msg = "Installation complete. Admin credentials were created — please log in and change the password immediately.";

    // Mark installed so the installer cannot be re-run accidentally.
    @file_put_contents($lock, date('c'));
} else {
    $msg = 'Unknown step.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Install — EXALOTE EXN</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-950 text-gray-100 min-h-screen flex items-center justify-center p-6">
  <div class="max-w-md w-full bg-gray-900 border border-gray-800 rounded-2xl p-8 text-center">
    <div class="text-4xl mb-3">🏆</div>
    <h1 class="text-xl font-bold mb-2">EXALOTE EXN</h1>
    <p class="text-green-400 font-medium mb-4"><?= htmlspecialchars($msg) ?></p>
    <a href="login.php" class="inline-block bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-6 py-3 rounded-xl transition">
      Go to User Login
    </a>
    <div class="mt-3">
      <a href="admin/login.php" class="text-indigo-400 text-sm hover:underline">Admin Login →</a>
    </div>
  </div>
</body>
</html>
