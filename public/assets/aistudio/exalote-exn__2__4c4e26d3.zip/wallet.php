<?php
/**
 * EXALOTE EXN — Wallet: balance, deposit (FamPay UPI), withdraw, history.
 */
require_once __DIR__ . '/common/config.php';
require_once __DIR__ . '/common/header.php';

$userId = current_user_id();
$user = current_user();
$walletOn = wallet_enabled();

// ---- Withdraw request (atomic balance check on WINNINGS only) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['withdraw'])) {
    csrf_verify();
    $amount = round((float)($_POST['amount'] ?? 0), 2);
    $upi = trim($_POST['upi_id'] ?? '');
    $flash = null;

    if (!$walletOn) {
        $flash = ['type' => 'error', 'text' => 'Withdrawals are currently disabled.'];
    } elseif ($amount < 50) {
        $flash = ['type' => 'error', 'text' => 'Minimum withdrawal is ₹50.'];
    } elseif ($upi === '') {
        $flash = ['type' => 'error', 'text' => 'Please enter your UPI ID for the withdrawal.'];
    } elseif (!preg_match('/^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/', $upi)) {
        $flash = ['type' => 'error', 'text' => 'Please enter a valid UPI ID (e.g. yourname@upi).'];
    } else {
        try {
            db()->beginTransaction();
            // Atomic guarded deduction on WINNINGS balance: only succeeds if winnings >= amount.
            $ded = db()->prepare('UPDATE users SET winnings_balance = winnings_balance - ?, wallet_balance = wallet_balance - ? WHERE id = ? AND winnings_balance >= ?');
            $ded->execute([$amount, $amount, $userId, $amount]);
            if ($ded->rowCount() !== 1) {
                db()->rollBack();
                $flash = ['type' => 'error', 'text' => 'Insufficient winnings balance. Only winnings can be withdrawn.'];
            } else {
                db()->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'debit', ?)")
                    ->execute([$userId, $amount, 'Withdrawal request to ' . $upi]);
                db()->prepare("INSERT INTO withdrawals (user_id, amount, status) VALUES (?, ?, 'Pending')")
                    ->execute([$userId, $amount]);
                db()->commit();
                $flash = ['type' => 'success', 'text' => 'Withdrawal request submitted. It will be processed by the admin.'];
                $user = current_user();
                $bal = (float)$user['wallet_balance'];
            }
        } catch (Throwable $e) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            $flash = ['type' => 'error', 'text' => 'Withdrawal failed. Please try again.'];
        }
    }
    $_SESSION['wallet_flash'] = $flash;
    redirect('wallet.php');
}

// ---- Manual-UTR deposit (gateway-less mode; admin approves) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_deposit'])) {
    csrf_verify();
    $amount = round((float)($_POST['amount'] ?? 0), 2);
    $utr = trim($_POST['utr'] ?? '');
    $flash = null;

    if (!$walletOn) {
        $flash = ['type' => 'error', 'text' => 'Deposits are currently disabled.'];
    } elseif ($amount < 10 || $amount > 50000) {
        $flash = ['type' => 'error', 'text' => 'Amount must be between ₹10 and ₹50,000.'];
    } elseif ($utr === '') {
        $flash = ['type' => 'error', 'text' => 'Please enter the UPI transaction reference (UTR).'];
    } else {
        try {
            db()->prepare("INSERT INTO deposits (user_id, amount, transaction_id, status) VALUES (?, ?, ?, 'Pending')")
                ->execute([$userId, $amount, $utr]);
            $flash = ['type' => 'success', 'text' => 'Deposit submitted for admin verification. You will be credited once approved.'];
        } catch (Throwable $e) {
            $flash = ['type' => 'error', 'text' => 'Could not submit deposit (UTR may already be used).'];
        }
    }
    $_SESSION['wallet_flash'] = $flash;
    redirect('wallet.php');
}

$flash = $_SESSION['wallet_flash'] ?? null;
unset($_SESSION['wallet_flash']);

// ---- Balance + recent transactions ----
$bal = (float)($user['wallet_balance'] ?? 0);
$txStmt = db()->prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20');
$txStmt->execute([$userId]);
$txns = $txStmt->fetchAll();
$upiSaved = trim($user['upi_id'] ?? '');
?>
<?php if ($flash): ?>
  <div class="mb-4 rounded-xl px-4 py-3 text-sm flex items-center gap-2 <?= $flash['type'] === 'error' ? 'bg-red-500/10 border border-red-500/30 text-red-300' : 'bg-green-500/10 border border-green-500/30 text-green-300' ?>">
    <i class="fa-solid <?= $flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<?php $depositBal = (float)($user['deposit_balance'] ?? 0); $winningsBal = (float)($user['winnings_balance'] ?? 0); $bonusBal = (float)($user['bonus_balance'] ?? 0); ?>

<!-- Balance hero -->
<div class="rounded-2xl bg-gradient-to-br from-[#7a0b1c] to-black p-5 text-white shadow-xl ring-1 ring-red-500/30 mb-5">
  <div class="flex items-center justify-between">
    <span class="text-sm opacity-90">Wallet Balance</span>
    <i class="fa-solid fa-wallet text-xl"></i>
  </div>
  <div class="text-4xl font-extrabold mt-2"><?= money($bal) ?></div>
  <div class="text-xs opacity-80 mt-2">Earn by winning tournaments. Withdraw anytime to your UPI.</div>
</div>

<!-- Three-bucket breakdown -->
<div class="grid grid-cols-3 gap-2 mb-5">
  <div class="bg-gray-900 border border-gray-800 rounded-2xl p-3 text-center">
    <div class="text-[10px] uppercase text-gray-500 font-semibold">Deposit Cash</div>
    <div class="text-lg font-extrabold text-emerald-400 mt-1"><?= money($depositBal) ?></div>
    <div class="text-[9px] text-gray-600 mt-0.5">not withdrawable</div>
  </div>
  <div class="bg-gray-900 border border-amber-500/30 rounded-2xl p-3 text-center">
    <div class="text-[10px] uppercase text-gray-500 font-semibold">Winnings Cash</div>
    <div class="text-lg font-extrabold text-amber-400 mt-1"><?= money($winningsBal) ?></div>
    <div class="text-[9px] text-gray-600 mt-0.5">withdrawable</div>
  </div>
  <div class="bg-gray-900 border border-gray-800 rounded-2xl p-3 text-center">
    <div class="text-[10px] uppercase text-gray-500 font-semibold">Bonus Cash</div>
    <div class="text-lg font-extrabold text-indigo-400 mt-1"><?= money($bonusBal) ?></div>
    <div class="text-[9px] text-gray-600 mt-0.5">up to 10% entry</div>
  </div>
</div>

<!-- Deposit (only when wallet enabled) -->
<?php if ($walletOn): ?>
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mb-5">
  <h3 class="font-bold text-white mb-1 flex items-center gap-2">
    <i class="fa-solid fa-circle-plus text-emerald-400"></i>Add Money
  </h3>
  <p class="text-xs text-gray-500 mb-4">Pay via UPI. Min ₹10, max ₹50,000.</p>

  <!-- Manual-UTR deposit (works without the gateway service) -->
  <form method="post" class="mb-5 space-y-3 border-b border-gray-800 pb-5">
    <?= csrf_field() ?>
    <div class="text-xs font-bold text-gray-400 mb-1">Manual UPI deposit (admin-verified)</div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Amount (₹)</label>
        <input type="number" name="amount" min="10" max="50000" step="0.01" placeholder="e.g. 500" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-emerald-500">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">UTR / Txn Ref</label>
        <input type="text" name="utr" placeholder="12-digit UPI ref" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-emerald-500">
      </div>
    </div>
    <button type="submit" name="manual_deposit" value="1" class="w-full bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl py-3 text-sm transition">
      <i class="fa-solid fa-money-check-dollar mr-2"></i>Submit for Verification
    </button>
  </form>

  <div class="text-xs font-bold text-gray-400 mb-2">Auto-verify via FamPay gateway (optional)</div>

  <div id="fp-step1">
    <form id="fp-create-form" class="space-y-3">
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Amount (₹)</label>
        <input type="number" id="fp-amount" min="10" max="50000" step="0.01" placeholder="e.g. 500" required
          class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-emerald-500">
        <p id="fp-err" class="hidden text-xs text-red-400 mt-1"></p>
      </div>
      <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl py-3 text-sm transition">
        <i class="fa-solid fa-arrow-right-to-bracket mr-2"></i>Continue to Pay
      </button>
    </form>
  </div>

  <!-- Step 2: UPI URI / QR + countdown -->
  <div id="fp-step2" class="hidden">
    <div class="bg-black/40 border border-gray-800 rounded-xl p-4 text-center mb-3">
      <div class="text-xs text-gray-400 mb-2">Scan &amp; pay with any UPI app</div>
      <img id="fp-qr" src="" alt="UPI QR" class="mx-auto w-40 h-40 rounded-xl bg-white p-2 object-contain">
      <div class="mt-3 text-xs text-gray-400">or pay to</div>
      <div id="fp-upi-uri" class="text-sm font-semibold text-white break-all mt-1"></div>
    </div>
    <button id="fp-open-upi" class="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl py-3 text-sm transition mb-2">
      <i class="fa-solid fa-mobile-screen-button mr-2"></i>Open UPI App
    </button>
    <div class="text-center text-xs text-gray-500 mb-3">After paying, continue to verify.</div>
    <button id="fp-next" class="w-full bg-white text-black font-bold rounded-xl py-3 text-sm transition mb-2">
      <i class="fa-solid fa-circle-check mr-2"></i>I've Paid — Verify
    </button>
    <button id="fp-cancel" class="w-full bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl py-3 text-sm transition">
      Cancel
    </button>
  </div>

  <!-- Step 3: UTR entry -->
  <div id="fp-step3" class="hidden">
    <div class="text-sm text-gray-300 mb-3">Enter the 12-digit UPI reference (UTR) from your bank SMS / transaction.</div>
    <form id="fp-utr-form" class="space-y-3">
      <div>
        <label class="text-xs text-gray-400 mb-1 block">UTR / Transaction Ref</label>
        <input type="text" id="fp-utr" placeholder="e.g. 404432403279" required
          class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm tracking-widest uppercase outline-none focus:border-emerald-500">
      </div>
      <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl py-3 text-sm transition">
        <i class="fa-solid fa-magnifying-glass mr-2"></i>Verify Payment
      </button>
      <button type="button" id="fp-back2" class="w-full bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl py-3 text-sm transition">
        Back
      </button>
    </form>
  </div>

  <!-- Step 4: verifying spinner -->
  <div id="fp-step4" class="hidden text-center py-6">
    <div class="mx-auto w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mb-3"></div>
    <div class="text-sm text-gray-300">Verifying payment…</div>
  </div>
</div>

<?php endif; ?><!-- /wallet enabled deposit -->

<?php if (!$walletOn): ?>
  <div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mb-5 text-center">
    <i class="fa-solid fa-wallet text-3xl text-gray-600 mb-2"></i>
    <p class="text-sm text-gray-400">Wallet features (deposits / withdrawals) are currently disabled.</p>
  </div>
<?php endif; ?>

<?php if ($walletOn): ?>
<!-- Withdraw card -->
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mb-5">
  <h3 class="font-bold text-white mb-1 flex items-center gap-2">
    <i class="fa-solid fa-money-bill-transfer text-amber-400"></i>Withdraw
  </h3>
  <p class="text-xs text-gray-500 mb-4">Min ₹50. Only Winnings Cash is withdrawable (₹<?= number_format($winningsBal, 2) ?> available). Funds go to your UPI ID after admin approval.</p>
  <form method="post" class="space-y-3">
    <?= csrf_field() ?>
    <div>
      <label class="text-xs text-gray-400 mb-1 block">Amount (₹)</label>
      <input type="number" name="amount" min="50" step="0.01" max="<?= (float)$winningsBal ?>" required
        class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
    </div>
    <div>
      <label class="text-xs text-gray-400 mb-1 block">UPI ID</label>
      <input type="text" name="upi_id" value="<?= e($upiSaved) ?>" placeholder="yourname@upi" required
        class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
    </div>
    <button type="submit" name="withdraw" value="1" class="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl py-3 text-sm transition">
      <i class="fa-solid fa-right-from-bracket mr-2"></i>Request Withdrawal
    </button>
  </form>
</div>
<?php endif; ?>

<!-- Transaction history -->
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow">
  <div class="flex items-center justify-between mb-4">
    <h3 class="font-bold text-white">Transaction History</h3>
    <span class="text-[10px] text-gray-500">Last <?= count($txns) ?> entries</span>
  </div>

  <?php if (!$txns): ?>
    <div class="text-center py-8 text-gray-500 text-sm">
      <i class="fa-solid fa-clock-rotate-left text-2xl text-gray-700 mb-2"></i>
      <p>No transactions yet. Add money to get started!</p>
    </div>
  <?php endif; ?>

  <?php foreach ($txns as $tx): ?>
    <?php $isCredit = $tx['type'] === 'credit'; ?>
    <div class="flex items-center justify-between py-2.5 border-b border-gray-800/70 last:border-0">
      <div class="flex items-center gap-3">
        <div class="w-8 h-8 rounded-lg flex items-center justify-center text-sm <?= $isCredit ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400' ?>">
          <i class="fa-solid <?= $isCredit ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down' ?>"></i>
        </div>
        <div>
          <div class="text-sm text-gray-200"><?= e($tx['description']) ?></div>
          <div class="text-[10px] text-gray-500"><?= e(date('d M Y, h:i A', strtotime($tx['created_at']))) ?> IST</div>
        </div>
      </div>
      <div class="text-sm font-extrabold <?= $isCredit ? 'text-emerald-400' : 'text-red-400' ?>">
        <?= $isCredit ? '+' : '−' ?><?= money($tx['amount']) ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<script>
(function () {
  var el = function (id) { return document.getElementById(id); };
  var show = function (id) { el(id).classList.remove('hidden'); };
  var hide = function (id) { el(id).classList.add('hidden'); };
  var err = function (msg) {
    var e = el('fp-err');
    e.textContent = msg; e.classList.remove('hidden');
  };
  var clearErr = function () { el('fp-err').classList.add('hidden'); };

  function api(action, params) {
    var body = new URLSearchParams();
    body.set('action', action);
    for (var k in params) body.set(k, params[k]);
    var headers = { 'X-CSRF-Token': <?= json_encode(csrf_token()) ?> };
    return fetch('api/payment.php', { method: 'POST', body: body, headers: headers })
      .then(function (r) { return r.json().then(function (d) { return { status: r.status, data: d }; }); });
  }

  var currentOrder = null;

  el('fp-create-form').addEventListener('submit', function (ev) {
    ev.preventDefault(); clearErr();
    var amt = el('fp-amount').value;
    if (!amt || parseFloat(amt) < 10 || parseFloat(amt) > 50000) { err('Enter an amount between ₹10 and ₹50,000.'); return; }
    api('create', { amount: amt }).then(function (r) {
      if (r.status !== 200 || !r.data.order_id) { err((r.data.error || 'Could not start payment.').replace(/_/g, ' ')); return; }
      currentOrder = r.data.order_id;
      el('fp-upi-uri').textContent = 'upi://pay?pa=' + encodeURIComponent(r.data.upi_id || '');
      if (r.data.upi_uri) el('fp-upi-uri').textContent = r.data.upi_uri;
      el('fp-qr').src = 'api/payment.php?action=qr&order_id=' + encodeURIComponent(currentOrder);
      hide('fp-step1'); show('fp-step2');
    }).catch(function () { err('Network error. Make sure the gateway service is running.'); });
  });

  el('fp-open-upi').addEventListener('click', function () {
    var uri = el('fp-upi-uri').textContent;
    if (uri) window.location.href = uri;
  });

  el('fp-next').addEventListener('click', function () {
    hide('fp-step2'); show('fp-step3');
  });

  el('fp-cancel').addEventListener('click', function () {
    if (currentOrder) api('cancel', { order_id: currentOrder });
    currentOrder = null;
    hide('fp-step2'); show('fp-step1');
  });

  el('fp-back2').addEventListener('click', function () {
    hide('fp-step3'); show('fp-step2');
  });

  el('fp-utr-form').addEventListener('submit', function (ev) {
    ev.preventDefault();
    var utr = el('fp-utr').value.trim();
    if (!utr || utr.length < 10) { err('Enter a valid UTR / transaction reference.'); return; }
    hide('fp-step3'); show('fp-step4');
    api('submit-utr', { order_id: currentOrder, raw_utr: utr }).then(function (r) {
      if (r.data.ok) {
        // poll status
        var tries = 0;
        (function poll() {
          api('status', { order_id: currentOrder }).then(function (s) {
            if (s.data.order && s.data.order.status === 'completed') {
              window.location.href = 'wallet.php';
            } else if (++tries < 20) {
              setTimeout(poll, 1500);
            } else {
              window.location.href = 'wallet.php';
            }
          });
        })();
      } else {
        err((r.data.code || 'Verification failed.').replace(/_/g, ' '));
        hide('fp-step4'); show('fp-step1');
      }
    }).catch(function () { err('Verification error.'); hide('fp-step4'); show('fp-step1'); });
  });
})();
</script>

<?php $active_tab = 'wallet'; require_once __DIR__ . '/common/bottom.php'; ?>
