<?php
/**
 * EXALOTE EXN — FamPay gateway webhook endpoint.
 * Called by the local Python service (gateway_service.py) after verification.
 * Protected by a shared secret header.
 */
require_once __DIR__ . '/../common/config.php';

$secret = $_SERVER['HTTP_X_GATEWAY_SECRET'] ?? '';
if (!hash_equals(GATEWAY_HOOK_SECRET, $secret)) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'forbidden']);
    exit;
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);
if (!is_array($payload) || empty($payload['action'])) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'bad_request']);
    exit;
}

$action = $payload['action'];

switch ($action) {
    case 'credit':
        $userId = (int)($payload['user_id'] ?? 0);
        $amount = (float)($payload['amount'] ?? 0);
        $utr = (string)($payload['utr'] ?? '');
        $orderId = (string)($payload['order_id'] ?? '');

        // Idempotency guard: if this UTR was already credited, this is a replay.
        // Return 200/ok so the gateway does not retry indefinitely, and never
        // double-credit. The UNIQUE index on deposits.transaction_id is the backstop.
        $exists = db()->prepare('SELECT id FROM deposits WHERE transaction_id = ? LIMIT 1');
        $exists->execute([$utr]);
        if ($exists->fetch()) {
            header('Content-Type: application/json');
            echo json_encode(['ok' => true, 'duplicate' => true]);
            exit;
        }

        $ok = credit_wallet($userId, $amount, $utr, $orderId);
        if ($ok) {
            notify_user_db($userId, '✅ Payment successful! ₹' . number_format($amount, 2) . ' added to your wallet. UTR: ' . $utr);
        }
        http_response_code($ok ? 200 : 500);
        header('Content-Type: application/json');
        echo json_encode(['ok' => $ok]);
        exit;
        break;

    case 'notify-user':
        $userId = (int)($payload['user_id'] ?? 0);
        $msg = (string)($payload['message'] ?? '');
        notify_user_db($userId, $msg);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true]);
        exit;
        break;

    case 'notify-admin':
        $event = (string)($payload['event'] ?? 'unknown');
        $data = $payload['payload'] ?? [];
        $stmt = db()->prepare('INSERT INTO admin_log (event, payload) VALUES (?, ?)');
        $stmt->execute([$event, json_encode($data)]);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true]);
        exit;
        break;

    case 'activity':
        $userId = (int)($payload['user_id'] ?? 0);
        $action2 = (string)($payload['activity'] ?? '');
        $detail = (string)($payload['detail'] ?? '');
        $stmt = db()->prepare('INSERT INTO admin_log (event, payload) VALUES (?, ?)');
        $stmt->execute(['USER_ACTIVITY', json_encode(['user_id' => $userId, 'action' => $action2, 'detail' => $detail])]);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true]);
        exit;
        break;

    default:
        http_response_code(400);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'unknown_action']);
        exit;
}
