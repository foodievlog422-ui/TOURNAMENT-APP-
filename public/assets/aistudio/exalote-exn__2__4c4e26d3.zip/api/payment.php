<?php
/**
 * EXALOTE EXN — FamPay deposit API routes (proxies to the local gateway service).
 *
 * Actions (all require a logged-in user session):
 *   ?action=create          POST {amount} -> {order_id, upi_uri, ...}
 *   ?action=submit-utr      POST {order_id, raw_utr} -> {ok, code}
 *   ?action=status          GET  ?order_id= -> order status
 *   ?action=cancel          POST {order_id} -> {ok}
 *   ?action=qr              GET  ?order_id= -> PNG image (redirect)
 */
require_once __DIR__ . '/../common/config.php';

function respond(int $code, array $data): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

if (!is_logged_in()) {
    respond(401, ['error' => 'unauthorized']);
}

// Reject all gateway actions when the wallet is disabled.
if (!wallet_enabled()) {
    respond(403, ['error' => 'wallet_disabled']);
}

$userId = current_user_id();
$action = $_GET['action'] ?? ($_POST['action'] ?? '');

// CSRF: require the header token for every request (GET and POST),
// except the QR image which is loaded via <img> (read-only).
if ($action !== 'qr') {
    $headerToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (empty($_SESSION['csrf_token']) || $headerToken === '' || !hash_equals($_SESSION['csrf_token'], $headerToken)) {
        respond(419, ['error' => 'csrf_failed']);
    }
}

switch ($action) {
    case 'create':
        $amount = (int)($_POST['amount'] ?? 0);
        if ($amount < 10 || $amount > 50000) {
            respond(400, ['error' => 'amount_out_of_range']);
        }
        $res = gateway_request('POST', '/create', ['user_id' => $userId, 'amount' => $amount]);
        if (($res['body']['ok'] ?? false) === false) {
            respond(400, ['error' => $res['body']['error'] ?? 'gateway_error']);
        }
        respond($res['status'] ?: 200, $res['body']);
        break;

    case 'submit-utr':
        $orderId = trim($_POST['order_id'] ?? '');
        $rawUtr = trim($_POST['raw_utr'] ?? '');
        if ($orderId === '' || $rawUtr === '') {
            respond(400, ['error' => 'missing_fields']);
        }
        $res = gateway_request('POST', '/submit-utr', [
            'user_id' => $userId,
            'order_id' => $orderId,
            'raw_utr' => $rawUtr,
        ]);
        respond(200, $res['body']);
        break;

    case 'status':
        $orderId = trim($_GET['order_id'] ?? '');
        if ($orderId === '') {
            respond(400, ['error' => 'missing_order_id']);
        }
        $res = gateway_request('GET', '/status?order_id=' . rawurlencode($orderId));
        if ($res['status'] === 404) {
            respond(404, ['error' => 'order_not_found']);
        }
        // only reveal status if it belongs to this user
        $order = $res['body']['order'] ?? [];
        if (isset($order['user_id']) && (int)$order['user_id'] !== $userId) {
            respond(403, ['error' => 'forbidden']);
        }
        respond(200, $res['body']);
        break;

    case 'cancel':
        $orderId = trim($_POST['order_id'] ?? '');
        $res = gateway_request('POST', '/cancel', ['user_id' => $userId, 'order_id' => $orderId]);
        respond(200, $res['body']);
        break;

    case 'qr':
        $orderId = trim($_GET['order_id'] ?? '');
        if ($orderId === '') {
            respond(400, ['error' => 'missing_order_id']);
        }
        $url = GATEWAY_BASE . '/qr?order_id=' . rawurlencode($orderId);
        $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);
        $png = @file_get_contents($url, false, $ctx);
        if ($png === false) {
            respond(502, ['error' => 'gateway_error']);
        }
        header('Content-Type: image/png');
        header('Content-Length: ' . strlen($png));
        echo $png;
        exit;
        break;

    default:
        respond(404, ['error' => 'unknown_action']);
}
