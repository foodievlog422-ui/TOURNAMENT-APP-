<?php
/**
 * EXALOTE EXN — Player Dashboard.
 */
require_once __DIR__ . '/common/config.php';
require_once __DIR__ . '/common/notify.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$uid = current_user_id();

// --- Actions ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $mid = (int)($_POST['match_id'] ?? 0);
        $wallet = wallet_enabled();

        // Mandatory Free Fire UID + IGN binding.
        $ffUid = trim((string)($uid ? (current_user()['ff_uid'] ?? '') : ''));
        $ffIgn = trim((string)($uid ? (current_user()['ff_ign'] ?? '') : ''));
        if ($ffUid === '' || $ffIgn === '') {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Please bind your Free Fire UID & IGN in your profile before joining a match.'];
            redirect('profile.php');
        }

        try {
            db()->beginTransaction();

            // Lock the match row (serializes concurrent joins — fixes last-slot race).
            $m = db()->prepare('SELECT m.*, c.name AS cat_name, c.format AS cat_format FROM matches m JOIN categories c ON c.id = m.category_id WHERE m.id = ? AND m.status = "Upcoming" FOR UPDATE');
            $m->execute([$mid]);
            $match = $m->fetch();
            if (!$match) {
                db()->rollBack();
                $_SESSION['flash'] = ['type' => 'error', 'text' => 'This match is not open for registration.'];
                redirect('index.php');
            }

            // Duplicate registration check (same user) inside the transaction.
            $dup = db()->prepare('SELECT id FROM registrations WHERE match_id = ? AND user_id = ?');
            $dup->execute([$mid, $uid]);
            if ($dup->fetch()) {
                db()->rollBack();
                $_SESSION['flash'] = ['type' => 'info', 'text' => 'You are already registered for this match.'];
                redirect('index.php');
            }

            // Same FF UID cannot join the same match twice.
            $dupUid = db()->prepare('SELECT id FROM registrations WHERE match_id = ? AND ff_uid = ?');
            $dupUid->execute([$mid, $ffUid]);
            if ($dupUid->fetch()) {
                db()->rollBack();
                $_SESSION['flash'] = ['type' => 'error', 'text' => 'This Free Fire UID is already registered for this match.'];
                redirect('index.php');
            }

            // Team-size validation for Duo/Squad/Clash Squad (2v2, 4v4) formats.
            $format = strtolower((string)$match['cat_format']);
            $needTeammates = 0;
            if (in_array($format, ['duo', '2v2'], true)) {
                $needTeammates = 1;
            } elseif (in_array($format, ['squad', '4v4'], true)) {
                $needTeammates = 3;
            }
            $teamMembers = [];
            if ($needTeammates > 0) {
                $tuids = $_POST['team_uid'] ?? [];
                $tigns = $_POST['team_ign'] ?? [];
                $seen = [];
                for ($i = 0; $i < $needTeammates; $i++) {
                    $tu = trim((string)($tuids[$i] ?? ''));
                    $ti = trim((string)($tigns[$i] ?? ''));
                    if (!preg_match('/^\d{8,12}$/', $tu)) {
                        db()->rollBack();
                        $_SESSION['flash'] = ['type' => 'error', 'text' => 'Teammate #' . ($i + 1) . ' Free Fire UID must be 8–12 digits.'];
                        redirect('index.php');
                    }
                    if ($ti === '') {
                        db()->rollBack();
                        $_SESSION['flash'] = ['type' => 'error', 'text' => 'Teammate #' . ($i + 1) . ' IGN is required.'];
                        redirect('index.php');
                    }
                    if ($tu === $ffUid) {
                        db()->rollBack();
                        $_SESSION['flash'] = ['type' => 'error', 'text' => 'Teammate Free Fire UID cannot be the same as yours.'];
                        redirect('index.php');
                    }
                    if (isset($seen[$tu])) {
                        db()->rollBack();
                        $_SESSION['flash'] = ['type' => 'error', 'text' => 'Duplicate teammate Free Fire UID entered.'];
                        redirect('index.php');
                    }
                    $seen[$tu] = true;
                    $teamMembers[] = ['ff_uid' => $tu, 'ff_ign' => $ti];
                }
                // No teammate may be a duplicate of an already-registered UID in this match.
                $uids = array_column($teamMembers, 'ff_uid');
                $ql = implode(',', array_fill(0, count($uids), '?'));
                $chk = db()->prepare("SELECT COUNT(*) FROM registrations WHERE match_id = ? AND ff_uid IN ($ql)");
                $chk->execute(array_merge([$mid], $uids));
                if ((int)$chk->fetchColumn() > 0) {
                    db()->rollBack();
                    $_SESSION['flash'] = ['type' => 'error', 'text' => 'One of your teammates is already registered for this match.'];
                    redirect('index.php');
                }
            }
            $teamJson = $teamMembers ? json_encode($teamMembers) : null;

            // Capacity: count Pending + Approved (fixes over-approval race).
            $cnt = db()->prepare("SELECT COUNT(*) FROM registrations WHERE match_id = ? AND status IN ('Pending','Approved')");
            $cnt->execute([$mid]);
            $taken = (int)$cnt->fetchColumn();
            if ($taken >= (int)$match['player_capacity']) {
                db()->rollBack();
                $_SESSION['flash'] = ['type' => 'error', 'text' => 'Match is full.'];
                redirect('index.php');
            }

            $fee = (float)$match['entry_fee'];

            // Wallet fee handling (only when wallet enabled and fee set).
            if ($wallet && $fee > 0) {
                if (!deduct_entry_fee($uid, $fee)) {
                    db()->rollBack();
                    $_SESSION['flash'] = ['type' => 'error', 'text' => 'Insufficient wallet balance. Entry fee is ₹' . number_format($fee, 2) . '.'];
                    redirect('index.php');
                }
                db()->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'debit', ?)")
                    ->execute([$uid, $fee, 'Entry fee for match #' . $mid]);
            }

            // Sequential slot assignment.
            $slot = $taken + 1;

            db()->prepare('INSERT INTO registrations (match_id, user_id, status, fee_status, ff_uid, ff_ign, slot_number, team_members) VALUES (?, ?, "Pending", ?, ?, ?, ?, ?)')
                ->execute([$mid, $uid, ($wallet && $fee > 0) ? 'paid' : 'none', $ffUid, $ffIgn, $slot, $teamJson]);

            // Auto-close registration when full (same transaction) — count Pending+Approved.
            $after = db()->prepare("SELECT COUNT(*) FROM registrations WHERE match_id = ? AND status IN ('Pending','Approved')");
            $after->execute([$mid]);
            if ((int)$after->fetchColumn() >= (int)$match['player_capacity']) {
                db()->prepare("UPDATE matches SET status = 'Registration Closed' WHERE id = ? AND status = 'Upcoming'")->execute([$mid]);
            }

            db()->commit();

            notify($uid, '🕓 Your registration for ' . $match['cat_name'] . ' on ' . $match['match_date'] . ' (Slot #' . $slot . ') has been submitted. Awaiting admin approval.', 'join', 'my_tournaments.php');
            $_SESSION['flash'] = ['type' => 'success', 'text' => 'Registration submitted! Awaiting admin approval (Slot #' . $slot . ').'];
        } catch (Throwable $e) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Registration failed. Please try again.'];
        }
        redirect('index.php');
    }

    if ($action === 'custom_request') {
        $title = trim($_POST['title'] ?? '');
        $cat   = trim($_POST['category_name'] ?? '');
        $fmt   = trim($_POST['format'] ?? 'Solo');
        $date  = trim($_POST['match_date'] ?? '');
        $time  = trim($_POST['start_time'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        if ($title === '' || $cat === '' || $date === '' || $time === '') {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Please fill the required fields.'];
            redirect('index.php');
        }
        db()->prepare('INSERT INTO custom_requests (user_id, title, category_name, format, match_date, start_time, notes) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$uid, $title, $cat, $fmt, $date, $time, $notes]);
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Custom match request sent for admin review.'];
        redirect('index.php');
    }
}

// --- Data ---
$user = current_user();
$today = date('Y-m-d');

$categories = db()->query('SELECT * FROM categories ORDER BY sort_order')->fetchAll();

$mQ = db()->prepare("
    SELECT m.*, c.name AS cat_name, c.format AS cat_format,
           (SELECT COUNT(*) FROM registrations r WHERE r.match_id = m.id AND r.status = 'Approved') AS approved_count
    FROM matches m
    JOIN categories c ON c.id = m.category_id
    WHERE m.match_date >= ? AND m.status IN ('Upcoming','Live')
    ORDER BY m.match_date ASC, FIELD(m.session,'morning','evening'), m.start_time ASC
");
$mQ->execute([$today]);
$matches = $mQ->fetchAll();

$mine = [];
if ($uid) {
    $st = db()->prepare('SELECT match_id, status FROM registrations WHERE user_id = ?');
    $st->execute([$uid]);
    foreach ($st->fetchAll() as $r) {
        $mine[$r['match_id']] = $r['status'];
    }
}

$leaderboard = db()->query('SELECT username, virtual_points FROM users WHERE virtual_points > 0 ORDER BY virtual_points DESC LIMIT 5')->fetchAll();

$sessionMeta = [
    'morning' => ['label' => 'Morning', 'window' => '10:00 – 14:00 IST'],
    'evening' => ['label' => 'Evening', 'window' => '20:00 – 00:00 IST'],
];

// Group matches by date + session
$grouped = [];
foreach ($matches as $m) {
    $key = $m['match_date'] . '|' . $m['session'];
    $grouped[$key][] = $m;
}
?>
<?php $page_title = 'Dashboard'; $active_tab = 'home'; require __DIR__ . '/common/header.php'; ?>

<?php if ($flash): ?>
  <div class="fade-up mb-4 px-4 py-3 rounded-2xl border text-sm font-medium
      <?= $flash['type'] === 'success' ? 'bg-green-500/10 border-green-500/30 text-green-300'
         : ($flash['type'] === 'error' ? 'bg-red-500/10 border-red-500/30 text-red-300' : 'bg-gray-800 border-gray-700 text-gray-200') ?>">
    <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check' : ($flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info') ?> mr-2"></i>
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<!-- Hero -->
<section class="fade-up relative overflow-hidden rounded-3xl bg-gradient-to-br from-red-600 via-[#7a0b1c] to-black p-5 ring-1 ring-red-500/30">
  <div class="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-red-500/20 blur-2xl"></div>
  <div class="relative">
    <p class="text-red-200/90 text-xs font-semibold tracking-widest uppercase">Tournament Center</p>
    <h1 class="text-2xl font-extrabold text-white mt-1">Hey, <?= e($user['username']) ?> 👋</h1>
    <p class="text-gray-300 text-sm mt-1"><?= date('l, d M Y') ?> · IST</p>
    <div class="mt-4 flex items-center gap-2">
      <div class="flex items-center gap-2 bg-black/30 border border-white/10 rounded-full px-4 py-2">
        <i class="fa-solid fa-star text-yellow-400"></i>
        <span class="text-white font-bold"><?= (int)$user['virtual_points'] ?> pts</span>
      </div>
      <div class="flex items-center gap-2 bg-black/30 border border-white/10 rounded-full px-4 py-2">
        <i class="fa-solid fa-fire text-orange-400"></i>
        <span class="text-white font-bold">Daily Auto Schedules</span>
      </div>
    </div>
  </div>
</section>

<!-- Categories strip -->
<section class="mt-6">
  <div class="flex items-center justify-between mb-3">
    <h2 class="font-bold text-white">Match Categories</h2>
    <span class="text-[11px] text-gray-500"><?= count($categories) ?> modes</span>
  </div>
  <div class="flex gap-2 overflow-x-auto scrollbar-hide -mx-4 px-4 pb-1">
    <?php foreach ($categories as $c): ?>
      <div class="shrink-0 bg-[#151515] border border-gray-800 rounded-2xl px-4 py-3 text-center min-w-[104px]">
        <div class="text-base text-red-500"><i class="fa-solid fa-crosshairs"></i></div>
        <div class="text-[11px] font-bold text-white leading-tight mt-1"><?= e($c['name']) ?></div>
        <div class="text-[10px] text-gray-500"><?= e($c['format']) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- Daily schedule -->
<section class="mt-6">
  <div class="flex items-center justify-between mb-3">
    <h2 class="font-bold text-white">Today's Matches</h2>
    <span class="text-[11px] text-gray-500">Auto-published daily</span>
  </div>

  <?php if (!$grouped): ?>
    <div class="text-center py-10 text-gray-500">
      <i class="fa-solid fa-calendar-xmark text-3xl mb-2 text-gray-700"></i>
      <p class="text-sm">No matches scheduled yet. Check back soon.</p>
    </div>
  <?php endif; ?>

  <?php foreach ($grouped as $key => $list): ?>
    <?php [$d, $sess] = explode('|', $key); ?>
    <?php
        $isToday = ($d === $today);
        $dateLabel = $isToday ? 'Today' : date('D, d M', strtotime($d));
    ?>
    <div class="mb-5">
      <div class="flex items-center gap-2 mb-2">
        <span class="text-xs font-bold text-red-400 uppercase tracking-wide"><?= $dateLabel ?></span>
        <span class="h-px flex-1 bg-gray-800"></span>
      </div>

      <?php foreach ($list as $m): ?>
        <?php
            $myStatus = $mine[$m['id']] ?? null;
            $full = (int)$m['approved_count'] >= (int)$m['player_capacity'];
            $meta = $sessionMeta[$m['session']];
            $statusChip = match ($m['status']) {
                'Live' => '<span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40">LIVE</span>',
                'Registration Closed' => '<span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/40">REG CLOSED</span>',
                default => '<span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-gray-700/40 text-gray-300 border border-gray-700">Upcoming</span>',
            };

            // Room visibility gate: only Approved/paid joined players see creds,
            // and only once the room is published (or within 15 min of start).
            $canSeeRoom = false;
            if ($myStatus === 'Approved') {
                $roomPub = (int)$m['room_published'];
                $startTs = strtotime($m['match_date'] . ' ' . $m['start_time']);
                $within15 = (time() >= ($startTs - 900));
                $canSeeRoom = ($roomPub === 1) || $within15;
            }
        ?>
        <div class="fade-up mb-3 bg-[#121212] border border-gray-800 rounded-2xl p-4 transition-colors hover:border-red-500/40">
          <div class="flex items-start justify-between">
            <div>
              <div class="font-bold text-white leading-tight"><?= e($m['cat_name']) ?></div>
              <div class="text-[11px] text-gray-500 mt-0.5">
                <span class="inline-block bg-red-500/10 text-red-400 text-[10px] font-bold px-2 py-0.5 rounded-full mr-1.5"><?= e($m['cat_format']) ?></span>
                <?= e($meta['label']) ?>
                <?php if ((float)$m['entry_fee'] > 0): ?>
                  <span class="inline-block bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full ml-1.5">Entry ₹<?= number_format((float)$m['entry_fee'], 2) ?></span>
                <?php endif; ?>
              </div>
            </div>
            <?= $statusChip ?>
          </div>

          <div class="mt-3 flex items-center justify-between">
            <div class="flex items-center gap-2 bg-black/40 border border-gray-800 rounded-xl px-3 py-2">
              <i class="fa-solid fa-clock text-red-500"></i>
              <span class="text-white font-extrabold text-lg tracking-wide"><?= e(date('h:i A', strtotime($m['start_time']))) ?></span>
            </div>
            <div class="flex items-center gap-1.5 text-gray-400 text-sm">
              <i class="fa-solid fa-users"></i>
              <span class="font-semibold text-white"><?= (int)$m['approved_count'] ?><span class="text-gray-500 font-normal text-xs">/<?= (int)$m['player_capacity'] ?></span></span>
            </div>
          </div>

          <div class="mt-3">
            <?php if ($myStatus === 'Approved'): ?>
              <div class="text-center w-full bg-green-500/10 border border-green-500/40 text-green-300 text-sm font-semibold py-2.5 rounded-xl">
                <i class="fa-solid fa-check mr-1.5"></i>Registered
              </div>
              <?php if ($canSeeRoom && (string)$m['room_id'] !== ''): ?>
                <div class="mt-2 bg-black/40 border border-green-500/30 rounded-xl p-3">
                  <div class="text-[10px] uppercase text-gray-500 font-semibold mb-1.5">Custom Room</div>
                  <div class="text-sm font-mono text-white">Room: <span class="text-green-300"><?= e($m['room_id']) ?></span></div>
                  <div class="text-sm font-mono text-white mt-1">Pass: <span class="text-green-300"><?= e($m['room_password']) ?></span></div>
                </div>
              <?php elseif ($canSeeRoom): ?>
                <div class="mt-2 text-center text-xs text-gray-500">Room details will appear here when published.</div>
              <?php endif; ?>
            <?php elseif ($myStatus === 'Pending'): ?>
              <div class="text-center w-full bg-yellow-500/10 border border-yellow-500/40 text-yellow-300 text-sm font-semibold py-2.5 rounded-xl">
                <i class="fa-solid fa-hourglass-half mr-1.5"></i>Pending Approval
              </div>
            <?php elseif ($myStatus === 'Rejected'): ?>
              <div class="text-center w-full bg-gray-800 text-gray-400 text-sm font-semibold py-2.5 rounded-xl">Rejected</div>
            <?php elseif ($m['status'] === 'Registration Closed' || $full): ?>
              <div class="text-center w-full bg-gray-800 text-gray-500 text-sm font-semibold py-2.5 rounded-xl cursor-not-allowed"><?= $m['status'] === 'Registration Closed' ? 'Registration Closed' : 'Full' ?></div>
            <?php else: ?>
              <?php
                // Determines if this match's format needs teammates (Duo/2v2 → 1, Squad/4v4 → 3).
                $fmt = strtolower((string)$m['cat_format']);
                $teamCount = in_array($fmt, ['duo', '2v2'], true) ? 1 : (in_array($fmt, ['squad', '4v4'], true) ? 3 : 0);
              ?>
              <form method="post" action="index.php">
                <input type="hidden" name="action" value="register">
                <input type="hidden" name="match_id" value="<?= (int)$m['id'] ?>">
                <?= csrf_field() ?>
                <?php if ($teamCount > 0): ?>
                  <div class="mb-2 bg-black/40 border border-gray-800 rounded-xl p-2 space-y-2">
                    <div class="text-[10px] uppercase text-gray-500 font-semibold">Teammates (<?= $teamCount ?>)</div>
                    <?php for ($i = 0; $i < $teamCount; $i++): ?>
                      <div class="grid grid-cols-[1fr_1fr] gap-2">
                        <input type="text" name="team_uid[]" required placeholder="FF UID" inputmode="numeric" pattern="\d{8,12}" maxlength="12" class="w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-xs text-white outline-none focus:border-red-500/60">
                        <input type="text" name="team_ign[]" required placeholder="IGN" maxlength="60" class="w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-xs text-white outline-none focus:border-red-500/60">
                      </div>
                    <?php endfor; ?>
                  </div>
                <?php endif; ?>
                <button type="submit" class="glow w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white text-sm font-extrabold py-2.5 rounded-xl transition-all">
                  <i class="fa-solid fa-bolt mr-1.5"></i><?= (float)$m['entry_fee'] > 0 ? 'Play ₹' . number_format((float)$m['entry_fee'], 2) : 'Register Free' ?>
                </button>
              </form>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
</section>

<!-- Request custom match -->
<section class="mt-6">
  <details class="group bg-[#121212] border border-gray-800 rounded-2xl overflow-hidden">
    <summary class="flex items-center justify-between px-4 py-4 cursor-pointer list-none">
      <div class="flex items-center gap-2.5">
        <div class="w-8 h-8 rounded-lg bg-red-500/15 text-red-400 flex items-center justify-center">
          <i class="fa-solid fa-screwdriver-wrench"></i>
        </div>
        <span class="font-bold text-white">Request Custom Match</span>
      </div>
      <i class="fa-solid fa-chevron-down text-gray-500 transition-transform group-open:rotate-180"></i>
    </summary>
    <form method="post" action="index.php" class="px-4 pb-4 space-y-3 border-t border-gray-800 pt-4">
      <input type="hidden" name="action" value="custom_request">
      <?= csrf_field() ?>
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Match title</label>
        <input type="text" name="title" required placeholder="e.g. BGMI Custom Room" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="text-[11px] text-gray-500 font-semibold uppercase">Category</label>
          <select name="category_name" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
            <?php foreach ($categories as $c): ?>
              <option value="<?= e($c['name']) ?>"><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="text-[11px] text-gray-500 font-semibold uppercase">Format</label>
          <select name="format" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
            <option value="Solo">Solo</option>
            <option value="1v1">1v1</option>
            <option value="2v2">2v2</option>
          </select>
        </div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="text-[11px] text-gray-500 font-semibold uppercase">Date (IST)</label>
          <input type="date" name="match_date" required value="<?= e($today) ?>" min="<?= e($today) ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
        </div>
        <div>
          <label class="text-[11px] text-gray-500 font-semibold uppercase">Time (IST)</label>
          <input type="time" name="start_time" required value="20:00" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
        </div>
      </div>
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Notes</label>
        <textarea name="notes" rows="2" placeholder="Room settings, rules, etc." class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-red-500/60 resize-none"></textarea>
      </div>
      <button type="submit" class="w-full bg-[#1a1a1a] border border-gray-700 hover:border-red-500/60 text-white text-sm font-bold py-3 rounded-xl transition-colors">
        <i class="fa-solid fa-paper-plane mr-1.5 text-red-500"></i>Send Request
      </button>
    </form>
  </details>
</section>

<!-- Leaderboard -->
<section class="mt-6">
  <div class="flex items-center justify-between mb-3">
    <h2 class="font-bold text-white">Leaderboard</h2>
    <span class="text-[11px] text-gray-500">Virtual points</span>
  </div>
  <div class="bg-[#121212] border border-gray-800 rounded-2xl divide-y divide-gray-800/70 overflow-hidden">
    <?php if (!$leaderboard): ?>
      <div class="text-center py-8 text-gray-500 text-sm">No points awarded yet.</div>
    <?php endif; ?>
    <?php foreach ($leaderboard as $i => $lb): ?>
      <div class="flex items-center gap-3 px-4 py-3">
        <div class="w-7 text-center font-extrabold <?= $i === 0 ? 'text-yellow-400' : ($i === 1 ? 'text-gray-300' : ($i === 2 ? 'text-amber-600' : 'text-gray-600')) ?>">
          <?= $i + 1 ?>
        </div>
        <div class="w-9 h-9 rounded-full bg-gradient-to-br from-gray-700 to-black flex items-center justify-center text-white text-sm font-bold">
          <?= e(strtoupper(substr($lb['username'], 0, 1))) ?>
        </div>
        <div class="flex-1 font-semibold text-white text-sm"><?= e($lb['username']) ?></div>
        <div class="flex items-center gap-1.5 text-yellow-400 font-bold text-sm">
          <i class="fa-solid fa-star text-xs"></i><?= (int)$lb['virtual_points'] ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<?php require __DIR__ . '/common/bottom.php'; ?>
