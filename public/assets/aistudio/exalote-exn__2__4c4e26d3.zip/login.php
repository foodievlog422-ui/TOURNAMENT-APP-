<?php
/**
 * EXALOTE EXN — User login / signup.
 */
require_once __DIR__ . '/common/config.php';

if (is_logged_in()) {
    redirect('index.php');
}

$error = null;
$success = null;
$mode = $_POST['mode'] ?? 'login';
$clientIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

// ---- Handle signup ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['mode'] ?? '') === 'signup') {
    csrf_verify();
    $identifier = trim($_POST['username'] ?? '') . '|' . trim($_POST['email'] ?? '');
    if (login_rate_limit($identifier, $clientIp)) {
        $error = 'Too many attempts. Please try again in 15 minutes.';
        $mode = 'signup';
    } else {
    $username = trim($_POST['username'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $pass2   = $_POST['password2'] ?? '';

    if ($username === '' || $email === '' || $pass === '') {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($pass) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($pass !== $pass2) {
        $error = 'Passwords do not match.';
    } else {
        $stmt = db()->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $error = 'Username or email already registered.';
        } else {
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $ins = db()->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
            $ins->execute([$username, $email, $hash]);
            log_transaction((int)db()->lastInsertId(), 0, 'credit', 'Welcome bonus — account created');
            $success = 'Account created! You can now log in.';
            $mode = 'login';
        }
    }
    } // end else (not rate-limited)
}

// ---- Handle login ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['mode'] ?? '') === 'login') {
    csrf_verify();
    $ident = trim($_POST['username'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if (login_rate_limit($ident, $clientIp)) {
        $error = 'Too many failed attempts. Please try again in 15 minutes.';
    } else {
        $stmt = db()->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$ident, $ident]);
        $row = $stmt->fetch();

        if (!$row || !password_verify($pass, $row['password'])) {
            login_rate_limit($ident, $clientIp, true);
            $error = 'Invalid username or password.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$row['id'];
            redirect('index.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#030712">
<title>Login · EXALOTE EXN</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
  :root { color-scheme: dark; }
  body { -webkit-tap-highlight-color: transparent; }
  .no-select { -webkit-user-select: none; user-select: none; }
</style>
</head>
<body class="bg-gray-950 text-gray-100 no-select min-h-screen antialiased">
<script>
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  document.addEventListener('selectstart', function (e) { e.preventDefault(); });
</script>

<div class="min-h-screen flex items-center justify-center px-5 py-10">
  <div class="w-full max-w-md">

    <!-- Brand -->
    <div class="text-center mb-8">
      <div class="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center text-white text-3xl shadow-xl shadow-indigo-500/30 mb-3">
        <i class="fa-solid fa-trophy"></i>
      </div>
      <h1 class="text-2xl font-extrabold">EXALOTE EXN</h1>
      <p class="text-gray-400 text-sm">Play tournaments. Win real wallet rewards.</p>
    </div>

    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-2xl">

      <?php if ($error): ?>
        <div class="bg-red-500/10 border border-red-500/30 text-red-300 text-sm rounded-xl px-4 py-3 mb-4 flex items-center gap-2">
          <i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?>
        </div>
      <?php endif; ?>
      <?php if ($success): ?>
        <div class="bg-green-500/10 border border-green-500/30 text-green-300 text-sm rounded-xl px-4 py-3 mb-4 flex items-center gap-2">
          <i class="fa-solid fa-circle-check"></i> <?= e($success) ?>
        </div>
      <?php endif; ?>

      <?php if ($mode === 'login'): ?>
        <!-- LOGIN FORM -->
        <form method="post" class="space-y-4">
          <input type="hidden" name="mode" value="login">
          <?= csrf_field() ?>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">Username or Email</label>
            <input type="text" name="username" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 transition" placeholder="you@example.com">
          </div>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">Password</label>
            <input type="password" name="password" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 transition" placeholder="••••••••">
          </div>
          <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl py-3.5 transition shadow-lg shadow-indigo-500/25">
            <i class="fa-solid fa-right-to-bracket mr-2"></i>Login
          </button>
        </form>
        <p class="text-center text-sm text-gray-400 mt-5">
          New here?
          <button type="button" onclick="document.getElementById('mode-signup').classList.remove('hidden');this.closest('p').classList.add('hidden')" class="text-indigo-400 font-semibold hover:underline">
            Create an account
          </button>
        </p>
        <div id="mode-signup" class="hidden">
          <?php // Signup form shown via toggle below ?>
        </div>
      <?php else: ?>
        <!-- SIGNUP FORM -->
        <form method="post" class="space-y-4">
          <input type="hidden" name="mode" value="signup">
          <?= csrf_field() ?>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">Username</label>
            <input type="text" name="username" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 transition" placeholder="gamer_01">
          </div>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">Email</label>
            <input type="email" name="email" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 transition" placeholder="you@example.com">
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-xs text-gray-400 mb-1 block">Password</label>
              <input type="password" name="password" required minlength="6" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 transition" placeholder="Min 6 chars">
            </div>
            <div>
              <label class="text-xs text-gray-400 mb-1 block">Confirm</label>
              <input type="password" name="password2" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 transition" placeholder="Repeat password">
            </div>
          </div>
          <button type="submit" class="w-full bg-gradient-to-r from-indigo-600 to-fuchsia-600 hover:opacity-90 text-white font-bold rounded-xl py-3.5 transition shadow-lg shadow-indigo-500/25">
            <i class="fa-solid fa-user-plus mr-2"></i>Create Account
          </button>
        </form>
        <p class="text-center text-sm text-gray-400 mt-5">
          Already have an account?
          <a href="login.php" class="text-indigo-400 font-semibold hover:underline">Login</a>
        </p>
      <?php endif; ?>

    </div>

    <p class="text-center text-gray-600 text-xs mt-6">
      <a href="admin/login.php" class="hover:text-gray-400"><i class="fa-solid fa-shield-halved mr-1"></i>Admin</a>
    </p>
  </div>
</div>
</body>
</html>
