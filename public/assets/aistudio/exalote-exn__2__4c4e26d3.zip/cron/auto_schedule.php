#!/usr/bin/env php
<?php
/**
 * EXALOTE EXN — cron entry point for the daily auto-scheduler.
 * Invoked by crond; safe to run repeatedly (idempotent).
 */

require_once __DIR__ . '/../common/scheduler.php';

date_default_timezone_set('Asia/Kolkata');
[$created, $log] = auto_schedule_run();

echo '[' . date('Y-m-d H:i:s T') . '] EXALOTE EXN scheduler' . PHP_EOL;
foreach ($log as $line) {
    echo '  ' . $line . PHP_EOL;
}
