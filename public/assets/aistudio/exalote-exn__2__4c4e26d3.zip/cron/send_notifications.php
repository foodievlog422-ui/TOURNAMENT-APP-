#!/usr/bin/env php
<?php
/**
 * EXALOTE EXN — cron entry point for match reminder / room notifications.
 * Runs frequently (e.g. every 5 minutes). Idempotent via dedupe.
 */

require_once __DIR__ . '/../common/notify.php';

date_default_timezone_set('Asia/Kolkata');
$res = send_match_reminders();

echo '[' . date('Y-m-d H:i:s T') . '] EXALOTE EXN notifications' . PHP_EOL;
foreach ($res['log'] as $line) {
    echo '  ' . $line . PHP_EOL;
}
echo '  reminders=' . $res['reminders'] . ' rooms=' . $res['rooms'] . PHP_EOL;
