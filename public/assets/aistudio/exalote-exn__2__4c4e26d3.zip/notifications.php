<?php
/**
 * EXALOTE EXN — Notification center: history, mark read, mark all read, filter.
 */
require_once __DIR__ . '/common/config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$uid = current_user_id();

// ---- Actions (traditional form POSTs) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'mark_read') {
        $id = (int)($_POST['id'] ?? 0);
        db()->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        redirect('notifications.php');
    }

    if ($action === 'mark_all_read') {
        db()->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0')->execute([$uid]);
        redirect('notifications.php');
    }

    if ($action === 'clear_read') {
        db()->prepare('DELETE FROM notifications WHERE user_id = ? AND is_read = 1')->execute([$uid]);
        redirect('notifications.php');
    }
}

$filter = $_GET['filter'] ?? 'all';

// ---- List ----
$notifs = [];
if ($filter === 'unread') {
    $stmt = db()->prepare('SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC, id DESC');
    $stmt->execute([$uid]);
    $notifs = $stmt->fetchAll();
} else {
    $stmt = db()->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 100');
    $stmt->execute([$uid]);
    $notifs = $stmt->fetchAll();
}

$unread = unread_notifications($uid);

function notif_icon(string $kind): string
{
    return match ($kind) {
        'join', 'approve'  => 'fa-user-check text-green-400',
        'reject'           => 'fa-user-xmark text-red-400',
        'start'            => 'fa-bolt text-red-400',
        'room'             => 'fa-network-wired text-indigo-400',
        'cancel'           => 'fa-ban text-gray-400',
        'result'           => 'fa-flag-checkered text-yellow-400',
        'win'              => 'fa-trophy text-yellow-400',
        'deposit'          => 'fa-circle-plus text-emerald-400',
        'withdraw'         => 'fa-hand-holding-usd text-amber-400',
        'new_match'        => 'fa-calendar-plus text-purple-400',
        'reminder'         => 'fa-clock text-blue-400',
        default            => 'fa-bell text-gray-400',
    };
}
?>
<?php $page_title = 'Notifications'; $active_tab = 'none'; require __DIR__ . '/common/header.php'; ?>

<section class="fade-up">
  <div class="flex items-center justify-between mb-4">
    <h2 class="text-xl font-extrabold text-white">Notifications</h2>
    <span class="text-xs text-gray-500">
      <?= $unread ?> unread
    </span>
  </div>

  <!-- Filter chips -->
  <div class="flex gap-2 mb-4">
    <a href="notifications.php?filter=all" class="px-3 py-1.5 rounded-full text-xs font-bold transition border <?= $filter === 'all' ? 'bg-red-600 border-red-500 text-white' : 'bg-[#151515] border-gray-800 text-gray-400 hover:text-white' ?>">All</a>
    <a href="notifications.php?filter=unread" class="px-3 py-1.5 rounded-full text-xs font-bold transition border <?= $filter === 'unread' ? 'bg-red-600 border-red-500 text-white' : 'bg-[#151515] border-gray-800 text-gray-400 hover:text-white' ?>">Unread</a>
    <form method="post" class="ml-auto">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="clear_read">
      <button type="submit" class="px-3 py-1.5 rounded-full text-xs font-bold bg-[#151515] border border-gray-800 text-gray-400 hover:text-white transition">
        <i class="fa-solid fa-trash-can mr-1"></i>Clear read
      </button>
    </form>
  </div>

  <!-- Mark all as read -->
  <?php if ($unread > 0): ?>
    <form method="post" class="mb-4">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="mark_all_read">
      <button type="submit" class="w-full bg-[#151515] border border-red-900/40 text-red-300 text-sm font-semibold py-2.5 rounded-xl hover:bg-[#1a1a1a] transition">
        <i class="fa-solid fa-check-double mr-1.5"></i>Mark all as read
      </button>
    </form>
  <?php endif; ?>

  <?php if (!$notifs): ?>
    <div class="text-center py-16 text-gray-500">
      <i class="fa-solid fa-bell-slash text-4xl text-gray-700 mb-3"></i>
      <p class="text-sm">No notifications here.</p>
    </div>
  <?php endif; ?>

  <div class="space-y-3">
    <?php foreach ($notifs as $n): ?>
      <div class="bg-[#121212] border rounded-2xl p-4 <?= $n['is_read'] ? 'border-gray-800/60 opacity-80' : 'border-red-800/50' ?>">
        <div class="flex items-start gap-3">
          <div class="shrink-0 w-9 h-9 rounded-xl bg-black/40 border border-gray-800 flex items-center justify-center">
            <i class="fa-solid <?= notif_icon($n['kind'] ?? '') ?>"></i>
          </div>
          <div class="min-w-0 flex-1">
            <p class="text-sm text-gray-200 leading-snug"><?= $n['message'] ?></p>
            <div class="mt-1.5 flex items-center gap-3 text-[10px] text-gray-500">
              <span><?= e(date('d M Y, h:i A', strtotime($n['created_at']))) ?> IST</span>
              <?php if (!$n['is_read']): ?>
                <span class="text-red-400 font-bold">NEW</span>
              <?php endif; ?>
            </div>
            <div class="mt-2 flex items-center gap-3">
              <?php if (!empty($n['link'])): ?>
                <a href="<?= e($n['link']) ?>" class="text-xs text-red-400 font-semibold hover:text-red-300">View <i class="fa-solid fa-arrow-right ml-0.5"></i></a>
              <?php endif; ?>
              <?php if (!$n['is_read']): ?>
                <form method="post">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="mark_read">
                  <input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                  <button type="submit" class="text-xs text-gray-400 hover:text-white font-semibold">Mark read</button>
                </form>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<?php require __DIR__ . '/common/bottom.php'; ?>
