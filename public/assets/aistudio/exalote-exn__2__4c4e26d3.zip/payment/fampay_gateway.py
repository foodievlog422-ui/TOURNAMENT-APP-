"""
FamPay UPI Payment Gateway (Gmail IMAP Auto-Verify Module)
Run: python paid_fampay_getway_soucre.py --selftest
"""
from __future__ import annotations

import html as _html
import imaplib
import io
import logging
import os
import re
import secrets
import socket
import sqlite3
import ssl
import threading
import time
import urllib.parse
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from email import message_from_bytes
from email.header import decode_header, make_header
from email.utils import parseaddr, parsedate_to_datetime
from typing import Callable, Optional

log = logging.getLogger("fampay_gateway")


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Config:
    gmail_address: str = os.getenv("GMAIL_ADDRESS", "").strip()
    gmail_app_password: str = os.getenv("GMAIL_APP_PASSWORD", "").strip()
    upi_id: str = os.getenv("FAMPAY_UPI_ID", "").strip()
    store_name: str = "EXALOTE EXN"

    imap_server: str = "imap.gmail.com"
    imap_port: int = 993
    imap_timeout: int = 20
    lookback_days: int = 3
    max_fetch: int = 10
    max_mail_bytes: int = 3_000_000

    sender_domains: tuple = ("famapp.in", "fampay.in", "famapp.co", "fampay.com")
    require_auth: bool = True  # Gmail ke DKIM/SPF pass ke bina mail trust nahi hoti

    order_window: int = 900          # QR 15 min valid
    late_utr_window: int = 86400     # order ke 24h tak UTR submit ho sakta hai
    clock_skew: int = 300
    max_payment_age: int = 7200
    email_max_delay: int = 3600
    verify_max_age: int = 21600      # UTR ke 6h baad bhi mail na mile -> admin review

    max_utr_tries: int = 5
    max_open_orders: int = 5
    min_amount: int = 10
    max_amount: int = 50000

    worker_interval: int = 15
    retry_fast: int = 30
    retry_slow: int = 300

    breaker_threshold: int = 3       # itne IMAP failures ke baad pause
    breaker_pause: int = 600

    @classmethod
    def from_env(cls, **overrides) -> "Config":
        base = dict(
    gmail_address=os.getenv("GMAIL_ADDRESS", "").strip(),
    gmail_app_password=os.getenv("GMAIL_APP_PASSWORD", "").strip(),
    upi_id=os.getenv("FAMPAY_UPI_ID", "").strip(),
            store_name=os.getenv("STORE_NAME", "EXALOTE EXN").strip(),
        )
        base.update(overrides)
        return cls(**base)

    @property
    def configured(self) -> bool:
        return bool(self.gmail_address and self.gmail_app_password and self.upi_id)


@dataclass
class Hooks:
    """Bot se judne ke points. Sab optional (get_db ko chhod ke).
    NOTE: get_db() har baar NAYA sqlite3 connection de aur row_factory = sqlite3.Row ho."""

    get_db: Callable[[], sqlite3.Connection]
    notify_user: Callable[[int, str], None] = lambda uid, text: None  # HTML text
    notify_admin: Callable[..., None] = lambda event, **kw: None      # event name + details
    on_credited: Callable[[int, int, str, str], None] = lambda uid, amt, utr, oid: None
    log_activity: Callable[[int, str, str], None] = lambda uid, action, detail: None


# ---------------------------------------------------------------------------
# Small utilities
# ---------------------------------------------------------------------------
_MON_ABBR = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
_MONTHS = {m.lower(): i for i, m in enumerate(_MON_ABBR, 1)}
OPEN_STATUSES = ("pending", "expired")  # in states me abhi bhi credit ho sakta hai


def epoch_now() -> int:
    return int(time.time())


def _fmt_ts(ts) -> str:
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC") if ts else "?"
    except Exception:
        return "?"


def esc(s) -> str:
    return _html.escape(str(s or ""))


def new_order_id() -> str:
    return "RX" + time.strftime("%y%m%d%H%M%S", time.gmtime()) + secrets.token_hex(2).upper()


# ---------------------------------------------------------------------------
# UTR helpers
# ---------------------------------------------------------------------------
_FAMPAY_ID_RX = re.compile(r"^(?:FMPIB\d{6,14}|FAMA[A-Z0-9]{8,35})$", re.I)


def normalize_utr(raw) -> Optional[str]:
    """Canonical UTR (UPPERCASE alnum, 8-40, kam se kam ek digit) ya None.
    FamPay ka FMPIB674930533 aur 674930533 ek hi payment hai -> digits wala canonical."""
    if raw is None:
        return None
    s = str(raw).strip()
    s = re.sub(
        r"^(?:fam(?:\s*pay|\s*app)?|utr|upi|ref(?:erence)?|rrn|txn|transaction)"
        r"(?:\s*(?:no|number|id|ref|code))?[\s:#=-]+",
        "",
        s,
        flags=re.I,
    )
    s = re.sub(r"[\s-]+", "", s).upper()
    if not re.fullmatch(r"[A-Z0-9]{8,40}", s) or not re.search(r"\d", s):
        return None
    m = re.fullmatch(r"FMPIB(\d{6,14})", s)
    return m.group(1) if m else s


def utr_aliases(utr: str) -> list:
    """Ek payment ke saare roop (duplicate check + mail search ke liye)."""
    u = str(utr or "").strip().upper()
    out = [u] if u else []
    m = re.fullmatch(r"FMPIB(\d{6,14})", u)
    if m:
        out.append(m.group(1))
    elif re.fullmatch(r"\d{6,14}", u):
        out.append("FMPIB" + u)
    return out


def looks_like_utr(raw) -> bool:
    t = str(raw or "").strip()
    if re.fullmatch(r"\d{10,12}", t):
        return True
    return bool(_FAMPAY_ID_RX.fullmatch(t) and normalize_utr(t) is not None)


# ---------------------------------------------------------------------------
# Email parsing (pure functions)
# ---------------------------------------------------------------------------
def _html_to_text(h: str) -> str:
    h = re.sub(r"<(script|style)\b[^>]*>.*?</\1>", " ", h, flags=re.I | re.S)
    h = re.sub(r"<br\s*/?>", "\n", h, flags=re.I)
    h = re.sub(r"</(p|div|tr|li|h[1-6]|table|section)>", "\n", h, flags=re.I)
    h = re.sub(r"<[^>]+>", " ", h)
    return _html.unescape(h)


def get_email_text(msg) -> str:
    chunks = []
    for part in msg.walk():
        if part.get_content_maintype() == "multipart":
            continue
        ctype = (part.get_content_type() or "").lower()
        if ctype not in ("text/plain", "text/html"):
            continue
        if "attachment" in str(part.get("Content-Disposition", "")).lower():
            continue
        try:
            payload = part.get_payload(decode=True)
        except Exception:
            continue
        if not payload:
            continue
        try:
            txt = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
        except LookupError:
            txt = payload.decode("utf-8", errors="replace")
        chunks.append(txt if ctype == "text/plain" else _html_to_text(txt))
    out = "\n".join(chunks).replace("\xa0", " ")
    return re.sub(r"[ \t\r\f\v]+", " ", out)[:200_000]


_CUR = r"(?:₹|\b(?:rs|inr)(?![a-z])\.?)"
_NUM = r"([0-9][0-9,]*(?:\.[0-9]{1,2})?)"
_AMT_KEYED = (
    re.compile(
        r"(?:received|credited|credit|paid|deposited|amount)[^0-9₹\n]{0,40}?" + _CUR + r"\s*" + _NUM,
        re.I,
    ),
    re.compile(
        _CUR + r"\s*" + _NUM + r"\s*(?:has\s+been\s+|was\s+)?(?:received|credited|paid)",
        re.I,
    ),
)
_AMT_ANY = re.compile(_CUR + r"\s*" + _NUM, re.I)


def _to_paise(s: str) -> Optional[int]:
    try:
        d = Decimal(s.replace(",", "")) * 100
    except (InvalidOperation, AttributeError):
        return None
    return int(d) if d > 0 and d == d.to_integral_value() else None


def parse_amount_paise(text: str) -> Optional[int]:
    """Mail me likha amount (paise). Agar na mile ya confusing ho -> None (kabhi guess nahi)."""
    keyed = {
        p
        for rx in _AMT_KEYED
        for m in rx.finditer(text)
        if (p := _to_paise(m.group(1))) is not None
    }
    if len(keyed) == 1:
        return next(iter(keyed))
    if len(keyed) > 1:
        return None
    anyamt = {
        p
        for m in _AMT_ANY.finditer(text)
        if (p := _to_paise(m.group(1))) is not None
    }
    return next(iter(anyamt)) if len(anyamt) == 1 else None


_UTR_LABELED = re.compile(
    r"\b(?:utr|upi\s*ref(?:erence)?(?:\s*(?:no|id|number))?|upi\s*transaction\s*id|"
    r"rrn|ref(?:erence)?(?:\s*(?:no|id|number))?|txn(?:\s*(?:id|no|number))?|"
    r"transaction(?:\s*(?:id|no|number))?|fampay\s*(?:id|ref)|payment\s*id)"
    r"\s*[:#=-]?\s*(?:is\s+)?([A-Za-z0-9]{8,40})\b",
    re.I,
)
_TOKEN = re.compile(r"\b([A-Za-z0-9]{8,40})\b")


def utr_in_text(text: str, utr: str) -> bool:
    labeled = {m.group(1).upper() for m in _UTR_LABELED.finditer(text)}
    tokens = {t.upper() for t in _TOKEN.findall(text)}
    for u in utr_aliases(utr):
        if u in labeled:
            return True
        if not labeled:
            if u in tokens:
                return True
        elif u in tokens and (re.fullmatch(r"\d{10,12}", u) or _FAMPAY_ID_RX.fullmatch(u)):
            return True
    return False


_MON_RX = r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*"
_TIME_RX = r"(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?\b"

_DT_PATTERNS = (
    (
        re.compile(r"\b(20\d\d)[-/](\d{1,2})[-/](\d{1,2})[T\s]+" + _TIME_RX, re.I),
        "ymd",
    ),
    (
        re.compile(r"\b(\d{1,2})[-/](\d{1,2})[-/](20\d\d)[,\s]+" + _TIME_RX, re.I),
        "dmy",
    ),
    (
        re.compile(r"\b(\d{1,2})\s+" + _MON_RX + r"[\s,]+(20\d\d)[\s,]+(?:at\s+)?" + _TIME_RX, re.I),
        "dMy",
    ),
    (
        re.compile(r"\b" + _MON_RX + r"\s+(\d{1,2})[\s,]+(20\d\d)[\s,]+(?:at\s+)?" + _TIME_RX, re.I),
        "Mdy",
    ),
)


def _ist_to_utc_naive(y, mo, d, h, mi, s, ap) -> datetime:
    if ap:
        ap = ap.lower().replace(".", "")
        if ap == "pm" and h < 12:
            h += 12
        elif ap == "am" and h == 12:
            h = 0
    return datetime(y, mo, d, h, mi, s) - timedelta(hours=5, minutes=30)


def parse_body_datetimes(text: str) -> list:
    """Body ke saare date/time (IST maanke) -> naive UTC datetimes."""
    out = []
    for rx, kind in _DT_PATTERNS:
        for m in rx.finditer(text):
            g = m.groups()
            try:
                if kind == "ymd":
                    y, mo, d = int(g[0]), int(g[1]), int(g[2])
                elif kind == "dmy":
                    d, mo, y = int(g[0]), int(g[1]), int(g[2])
                elif kind == "dMy":
                    d, y = int(g[0]), int(g[2])
                    mo = _MONTHS.get(g[1][:3].lower(), 0)
                else:
                    d, y = int(g[1]), int(g[2])
                    mo = _MONTHS.get(g[0][:3].lower(), 0)
                if not mo:
                    continue
                h, mi, s, ap = int(g[3]), int(g[4]), int(g[5] or 0), g[6]
                if ap and not (1 <= h <= 12):
                    continue
                out.append(_ist_to_utc_naive(y, mo, d, h, mi, s, ap))
            except (ValueError, TypeError):
                continue
    return out


def _header_epoch(msg) -> Optional[int]:
    try:
        dt = parsedate_to_datetime(str(msg.get("Date", "")))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.astimezone(timezone.utc).timestamp())
    except Exception:
        return None


def _decode_header_value(v) -> str:
    if not v:
        return ""
    try:
        return str(make_header(decode_header(str(v))))
    except Exception:
        return str(v)


def _domain_allowed(cfg: Config, dom: str) -> bool:
    dom = (dom or "").lower().strip(".")
    return bool(dom) and any(dom == d or dom.endswith("." + d) for d in cfg.sender_domains)


def _sender_domain(msg) -> str:
    _, addr = parseaddr(_decode_header_value(msg.get("From", "")))
    return addr.rsplit("@", 1)[-1].lower() if "@" in addr else ""


def _auth_ok(cfg: Config, msg) -> bool:
    """Sirf Gmail (mx.google.com) ka Authentication-Results trust hota hai ->
    koi spoof karke fake payment received mail bhej kar balance nahi badha sakta.
    Gmail apna header sabse upar lagata hai, isliye pehla mx.google.com wala hi dekhte hain
    (sender ka khud ka nakli header neeche hota hai)."""
    if not cfg.require_auth:
        return True
    for h in (msg.get_all("Authentication-Results") or []):
        hs = re.sub(r"\s+", " ", str(h)).lower().strip()
        if not hs.startswith("mx.google.com"):
            continue
        for m in re.finditer(r"dkim=pass\b[^;]*?header\.(?:i|d)=(?:[^;\s@]*@)?([a-z0-9.-]+)", hs):
            if _domain_allowed(cfg, m.group(1)):
                return True
        for m in re.finditer(r"spf=pass\b[^;]*?smtp\.mailfrom=[^;\s@]*@([a-z0-9.-]+)", hs):
            if _domain_allowed(cfg, m.group(1)):
                return True
        return False
    return False


_INTERNALDATE_RX = re.compile(
    r'INTERNALDATE\s+"\s*(\d{1,2})-([A-Za-z]{3})-(\d{4})\s+(\d{2}):(\d{2}):(\d{2})\s+([+-]\d{4})"'
)


def _fetch_internaldate(data) -> Optional[int]:
    """Gmail ka apna arrival time (epoch UTC). Sender isse fake nahi kar sakta."""
    try:
        for item in data or []:
            blob = item[0] if isinstance(item, tuple) else item
            if not isinstance(blob, (bytes, bytearray)):
                continue
            m = _INTERNALDATE_RX.search(blob.decode("ascii", "ignore"))
            if not m:
                continue
            d, mon, y, hh, mi, ss, off = m.groups()
            mo = _MONTHS.get(mon.lower(), 0)
            base = int(datetime(int(y), mo, int(d), int(hh), int(mi), int(ss), tzinfo=timezone.utc).timestamp())
            sign = -1 if off[0] == "+" else 1
            return base + sign * (int(off[1:3]) * 3600 + int(off[3:5]) * 60)
    except Exception as e:
        log.debug("internaldate parse fail: %s", e)
    return None


def parse_payment_email(cfg: Config, msg, utr: str, arrival_ts: Optional[int] = None) -> dict:
    """Kabhi raise nahi karta. Mail kya kehti hai wo dict me deta hai; trust ka faisla verifier karta hai.
    Body ka time tabhi maana jata hai jab Gmail arrival time se consistent ho (pehle IST, phir UTC reading)."""
    info = {
        "sender_ok": False,
        "auth_ok": False,
        "utr_match": False,
        "amount_paise": None,
        "paid_at": None,
        "paid_src": None,
        "arrival_at": arrival_ts,
        "header_at": None,
        "time_conflict": False,
        "subject": _decode_header_value(msg.get("Subject", ""))[:120],
    }
    try:
        dom = _sender_domain(msg)
        info["auth_ok"] = _auth_ok(cfg, msg)
        info["sender_ok"] = bool(dom) and _domain_allowed(cfg, dom) and info["auth_ok"]

        text = get_email_text(msg)
        info["utr_match"] = utr_in_text(text, utr)
        info["amount_paise"] = parse_amount_paise(text)

        hdr_ts = _header_epoch(msg)
        info["header_at"] = hdr_ts
        ref = arrival_ts if arrival_ts is not None else hdr_ts
        body_times = parse_body_datetimes(text)
        chosen, src = None, None
        if body_times:
            if ref is None:
                chosen, src = int(body_times[0].replace(tzinfo=timezone.utc).timestamp()), "body"
            else:
                for t in body_times:
                    base = int(t.replace(tzinfo=timezone.utc).timestamp())
                    for cand in (base, base + 19800):  # IST reading, phir UTC reading
                        gap = ref - cand
                        if -cfg.clock_skew <= gap <= cfg.email_max_delay:
                            if chosen is None or abs(ref - cand) < abs(ref - chosen):
                                chosen, src = cand, "body"
            if chosen is None:
                info["time_conflict"] = True  # body time arrival se match nahi -> auto-credit nahi
        elif hdr_ts is not None and (ref is None or abs(ref - hdr_ts) <= cfg.email_max_delay):
            chosen, src = hdr_ts, "header"
        elif arrival_ts is not None:
            chosen, src = arrival_ts, "arrival"

        info["paid_at"], info["paid_src"] = chosen, src
    except Exception as e:
        log.warning("parse_payment_email error: %s", e)
    return info


def check_payment_time(
    cfg: Config, em: dict, created_at: int, utr_submitted_at: Optional[int], now: int
) -> tuple:
    """Pure time validation -> (ok, reason)."""
    ts, arr, src = em.get("paid_at"), em.get("arrival_at"), em.get("paid_src")
    skew = cfg.clock_skew
    if ts is None:
        return False, ("time_inconsistent" if em.get("time_conflict") else "time_unreadable")
    if ts > now + skew or (arr is not None and arr > now + skew):
        return False, "future_timestamp"
    if ts < int(created_at) - skew:
        return False, "payment_before_order"
    max_age = (
        cfg.max_payment_age
        if src == "body"
        else max(cfg.max_payment_age, cfg.order_window + cfg.email_max_delay)
    )
    if ts - int(created_at) > max_age:
        return False, "payment_too_late"
    if utr_submitted_at:
        tol = skew if src == "body" else cfg.email_max_delay + skew
        if ts > int(utr_submitted_at) + tol:
            return False, "payment_after_utr_submit"  # pay karne se pehle UTR nahi jaan sakta
    return True, ""


# ---------------------------------------------------------------------------
# Gmail IMAP client (circuit breaker + backoff)
# ---------------------------------------------------------------------------
class ImapUnavailable(Exception):
    pass


class GmailClient:
    def __init__(self, cfg: Config, on_alert: Callable[[str], None] = lambda t: None):
        self.cfg = cfg
        self._lock = threading.Lock()
        self._fails = 0
        self._paused_until = 0.0
        self._last_alert = 0.0
        self._on_alert = on_alert

    # -- connection --
    def _connect(self) -> imaplib.IMAP4_SSL:
        ctx = ssl.create_default_context()
        M = imaplib.IMAP4_SSL(
            self.cfg.imap_server,
            self.cfg.imap_port,
            ssl_context=ctx,
            timeout=self.cfg.imap_timeout,
        )
        try:
            # App Password "abcd efgh ijkl mnop" ho ya "abcdefghijklmnop" -> dono chalte hain
            M.login(self.cfg.gmail_address, self.cfg.gmail_app_password.replace(" ", ""))
        except Exception:
            try:
                M.logout()
            except Exception:
                pass
            raise
        return M

    def _alert(self, text: str):
        if time.time() - self._last_alert < 3600:
            return
        self._last_alert = time.time()
        try:
            self._on_alert(text)
        except Exception as e:
            log.error("imap alert failed: %s", e)

    def _record(self, ok: bool, why: str = ""):
        if ok:
            self._fails = 0
            return
        self._fails += 1
        if self._fails >= self.cfg.breaker_threshold:
            self._paused_until = time.time() + self.cfg.breaker_pause
            self._alert(
                f"Gmail IMAP {self._fails} baar fail ({why}). {self.cfg.breaker_pause // 60} min pause."
            )

    @property
    def paused(self) -> bool:
        return time.time() < self._paused_until

    def selftest(self) -> tuple:
        if not self.cfg.configured:
            return False, "GMAIL_ADDRESS / GMAIL_APP_PASSWORD / FAMPAY_UPI_ID missing"
        try:
            with self._lock:
                M = self._connect()
                M.logout()
            return True, "login OK"
        except imaplib.IMAP4.error as e:
            return (
                False,
                f"Gmail login failed ({str(e)[:150]}) - 2-Step ON, App Password sahi, IMAP enabled?",
            )
        except Exception as e:
            return False, f"Gmail connection failed ({str(e)[:150]})"

    # -- search --
    def _search_ids(self, M, utr: str) -> list:
        # imaplib args ko khud quote nahi karta -> poori Gmail query ek quoted string honi chahiye
        q = f'"{utr} newer_than:{int(self.cfg.lookback_days)}d"'
        try:
            typ, data = M.search(None, "X-GM-RAW", q)
            if typ == "OK":
                return data[0].split() if data and data[0] else []
        except Exception as e:
            log.debug("X-GM-RAW failed, fallback: %s", e)
        d = datetime.now(timezone.utc) - timedelta(days=self.cfg.lookback_days)
        since = f"{d.day:02d}-{_MON_ABBR[d.month - 1]}-{d.year}"
        typ, data = M.search(None, "SINCE", since, "TEXT", f'"{utr}"')
        return data[0].split() if typ == "OK" and data and data[0] else []

    def search_utr(self, utr: str) -> tuple:
        """-> (status, emails, error). status: ok | error. Kabhi raise nahi karta."""
        if not self.cfg.configured:
            return "error", [], "gmail_not_configured"
        if not re.fullmatch(r"[A-Z0-9]{8,40}", str(utr or "")):
            return "error", [], "bad_utr"
        if self.paused:
            return "error", [], "imap_paused"
        err = "imap_error"
        for attempt in range(2):  # 1 quick retry (network hiccup)
            M = None
            with self._lock:
                try:
                    M = self._connect()
                    emails = []
                    for mbox in ("INBOX", '"[Gmail]/All Mail"'):
                        try:
                            typ, _ = M.select(mbox, readonly=True)
                        except Exception:
                            continue
                        if typ != "OK":
                            continue
                        ids = []
                        for alias in utr_aliases(utr):
                            ids += [i for i in self._search_ids(M, alias) if i not in ids]
                        for num in ids[-self.cfg.max_fetch :]:
                            typ, data = M.fetch(num, "(INTERNALDATE BODY.PEEK[])")
                            if typ != "OK" or not data or not isinstance(data[0], tuple):
                                continue
                            raw = data[0][1]
                            if not raw or len(raw) > self.cfg.max_mail_bytes:
                                continue
                            try:
                                emails.append(
                                    parse_payment_email(
                                        self.cfg,
                                        message_from_bytes(raw),
                                        utr,
                                        _fetch_internaldate(data),
                                    )
                                )
                            except Exception as e:
                                log.warning("malformed email skipped: %s", e)
                        if emails:
                            break
                    self._record(True)
                    return "ok", emails, ""
                except imaplib.IMAP4.error as e:
                    err = f"login/imap: {str(e)[:120]}"
                    break
                except (socket.timeout, ssl.SSLError, OSError) as e:
                    err = f"network: {str(e)[:120]}"
                except Exception as e:
                    err = f"unexpected: {str(e)[:120]}"
                finally:
                    if M is not None:
                        try:
                            M.logout()
                        except Exception:
                            pass
            if attempt == 0:
                time.sleep(1.0)
        self._record(False, err)
        return "error", [], err


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------
_PENDING_EXTRA_COLS = (
    ("expected_amount", "INTEGER"),
    ("pay_method", "TEXT DEFAULT 'upi_gmail'"),
    ("utr", "TEXT"),
    ("utr_submitted_at", "INTEGER"),
    ("last_check_at", "INTEGER DEFAULT 0"),
    ("check_count", "INTEGER DEFAULT 0"),
    ("utr_tries", "INTEGER DEFAULT 0"),
    ("reject_reason", "TEXT"),
    ("received_amount", "REAL"),
    ("paid_at", "INTEGER"),
)


def ensure_schema(conn: sqlite3.Connection) -> None:
    """Idempotent: tables + missing columns + indexes."""
    cur = conn.cursor()
    cur.execute(
        """CREATE TABLE IF NOT EXISTS pending_payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            order_id TEXT NOT NULL UNIQUE,
            amount INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at INTEGER NOT NULL
        )"""
    )
    cur.execute(
        """CREATE TABLE IF NOT EXISTS payment_utrs (
            utr TEXT PRIMARY KEY,
            order_id TEXT NOT NULL,
            user_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            received_paise INTEGER,
            paid_at INTEGER,
            credited_at INTEGER NOT NULL
        )"""
    )
    have = {
        r[1] for r in cur.execute("PRAGMA table_info(pending_payments)").fetchall()
    }
    for col, decl in _PENDING_EXTRA_COLS:
        if col not in have:
            cur.execute(f"ALTER TABLE pending_payments ADD COLUMN {col} {decl}")
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_pp_status ON pending_payments(pay_method, status)"
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_pp_user ON pending_payments(user_id, status)"
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_payment_utrs_user ON payment_utrs(user_id)"
    )
    conn.commit()
    cur.close()


# ---------------------------------------------------------------------------
# QR
# ---------------------------------------------------------------------------
def build_upi_uri(cfg: Config, amount: int, order_id: str) -> str:
    q = {
        "pa": cfg.upi_id,
        "pn": cfg.store_name,
        "am": f"{int(amount)}.00",
        "cu": "INR",
        "tn": order_id,  # note me order_id -> user ke statement me bhi dikhega
        "tr": order_id,
    }
    return "upi://pay?" + urllib.parse.urlencode(q, quote_via=urllib.parse.quote, safe="@.")


def make_qr_png(uri: str) -> Optional[io.BytesIO]:
    """QR locally banta hai (external API nahi -> privacy + reliability). Library na ho to None."""
    try:
        import segno

        buf = io.BytesIO()
        segno.make(uri, error="m").save(buf, kind="png", scale=10, border=4)
        buf.seek(0)
        buf.name = "upi_qr.png"
        return buf
    except ImportError:
        pass
    except Exception as e:
        log.error("segno failed: %s", e)
    try:
        import qrcode

        qr = qrcode.QRCode(
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4,
        )
        qr.add_data(uri)
        qr.make(fit=True)
        buf = io.BytesIO()
        qr.make_image(fill_color="black", back_color="white").save(buf, format="PNG")
        buf.seek(0)
        buf.name = "upi_qr.png"
        return buf
    except ImportError:
        log.error("QR library missing: pip install segno")
    except Exception as e:
        log.error("qrcode failed: %s", e)
    return None


# ---------------------------------------------------------------------------
# Gateway
# ---------------------------------------------------------------------------
REVIEW_MSG = {
    "amount_mismatch": "Payment mili par amount order ke amount se match nahi hua.",
    "amount_unreadable": "Payment email se amount verify nahi ho paya.",
    "time_unreadable": "Payment ka time verify nahi ho paya.",
    "payment_before_order": "Yeh payment order banne se pehle ki hai, isliye accept nahi hui.",
    "payment_too_late": "Payment order ki maximum allowed time ke baad hui hai.",
    "future_timestamp": "Payment email ka time invalid (future) hai.",
    "time_inconsistent": "Payment email ka time Gmail ke arrival time se match nahi hua.",
    "payment_after_utr_submit": "Payment time UTR submit hone ke baad ka dikh raha hai.",
    "duplicate_utr": "Yeh UTR pehle hi use ho chuka hai.",
    "email_not_found_timeout": "Is UTR ki payment email abhi tak nahi mili.",
}


class FamPayGateway:
    def __init__(self, cfg: Config, hooks: Hooks):
        self.cfg = cfg
        self.h = hooks
        self.mail = GmailClient(
            cfg,
            on_alert=lambda t: self._admin(
                "PAYMENT_GATEWAY_ERROR",
                method="GMAIL IMAP",
                status="FAILED",
                details=t,
            ),
        )
        self._locks: dict = {}
        self._locks_guard = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # -- small helpers --
    def _admin(self, event, **kw):
        try:
            self.h.notify_admin(event, **kw)
        except Exception as e:
            log.error("notify_admin failed: %s", e)

    def _user(self, uid: int, text: str):
        try:
            self.h.notify_user(uid, text)
        except Exception as e:
            log.warning("notify_user failed uid=%s: %s", uid, e)

    def _activity(self, uid: int, action: str, detail: str):
        try:
            self.h.log_activity(uid, action, detail)
        except Exception as e:
            log.warning("log_activity failed uid=%s: %s", uid, e)

    def _run(self, sql, params=()) -> int:
        conn = self.h.get_db()
        try:
            cur = conn.cursor()
            cur.execute(sql, params)
            conn.commit()
            n = cur.rowcount
            cur.close()
            return n
        finally:
            conn.close()

    def _one(self, sql, params=()):
        conn = self.h.get_db()
        try:
            cur = conn.cursor()
            cur.execute(sql, params)
            row = cur.fetchone()
            cur.close()
            return row
        finally:
            conn.close()

    def get_order(self, order_id: str):
        return self._one(
            "SELECT * FROM pending_payments WHERE order_id=?", (order_id,)
        )

    def _order_lock(self, order_id: str) -> threading.Lock:
        with self._locks_guard:
            if len(self._locks) > 1000:
                self._locks = {k: v for k, v in self._locks.items() if v.locked()}
            return self._locks.setdefault(order_id, threading.Lock())

    # -- init + health --
    def init(self) -> None:
        conn = self.h.get_db()
        try:
            ensure_schema(conn)
        finally:
            conn.close()

    def health(self) -> dict:
        ok, msg = self.mail.selftest()
        return {
            "configured": self.cfg.configured,
            "gmail_ok": ok,
            "message": msg,
            "qr_ok": make_qr_png("upi://pay?pa=test@fam") is not None,
            "breaker_paused": self.mail.paused,
        }

    # -- 1. order --
    def create_order(self, user_id: int, amount: int) -> tuple:
        if not self.cfg.configured:
            return None, "not_configured"
        try:
            amount = int(amount)
        except (TypeError, ValueError):
            return None, "invalid_amount"
        if amount < self.cfg.min_amount or amount > self.cfg.max_amount:
            return None, "amount_out_of_range"
        now = epoch_now()
        self._run(
            "UPDATE pending_payments SET status='expired' WHERE user_id=? AND status='pending' AND (utr IS NULL OR utr='') AND (? - created_at) > ?",
            (user_id, now, self.cfg.order_window),
        )
        open_cnt = self._one(
            "SELECT COUNT(*) FROM pending_payments WHERE user_id=? AND status='pending'",
            (user_id,),
        )
        if open_cnt and int(open_cnt[0]) >= self.cfg.max_open_orders:
            return None, "too_many_open_orders"
        oid = new_order_id()
        try:
            self._run(
                """INSERT INTO pending_payments
                   (user_id, order_id, amount, expected_amount, status, created_at, pay_method)
                   VALUES (?, ?, ?, ?, 'pending', ?, 'upi_gmail')""",
                (user_id, oid, amount, amount, now),
            )
        except Exception as e:
            log.error("create_order failed: %s", e)
            return None, "db_error"
        self._activity(user_id, "FAMPAY_QR_GEN", f"₹{amount} | {oid}")
        self._admin(
            "INSTANT_PAYMENT_STARTED",
            user_id=user_id,
            amount=amount,
            ref=oid,
            status="QR GENERATED",
        )
        return oid, build_upi_uri(self.cfg, amount, oid)

    def cancel_order(self, user_id: int, order_id: str) -> bool:
        return bool(
            self._run(
                "UPDATE pending_payments SET status='cancelled' WHERE order_id=? AND user_id=? AND status='pending' AND (utr IS NULL OR utr='')",
                (order_id, user_id),
            )
        )

    # -- 2. UTR --
    def submit_utr(self, user_id: int, order_id: str, raw_utr: str) -> tuple:
        """-> (ok, code). Success par verification background thread me chalti hai."""
        row = self.get_order(order_id)
        if not row or int(row["user_id"]) != int(user_id):
            return False, "order_not_found"
        if row["status"] == "completed":
            return False, "already_done"
        if row["status"] not in ("pending", "expired", "review"):
            return False, "order_not_open"
        if int(row["utr_tries"] or 0) >= self.cfg.max_utr_tries:
            return False, "max_tries_exceeded"
        if epoch_now() - int(row["created_at"]) > self.cfg.late_utr_window:
            return False, "order_too_old"

        utr = normalize_utr(raw_utr)
        if not utr:
            self._run(
                "UPDATE pending_payments SET utr_tries=COALESCE(utr_tries,0)+1 WHERE order_id=?",
                (order_id,),
            )
            return False, "invalid_utr"

        a, b = (utr_aliases(utr) + [utr, utr])[:2]
        used = self._one(
            "SELECT 1 FROM payment_utrs WHERE UPPER(utr) IN (?, ?)",
            (a.upper(), b.upper()),
        )
        if not used and self._table_exists("manual_deposits"):
            used = self._one(
                "SELECT 1 FROM manual_deposits WHERE UPPER(utr) IN (?, ?) AND status IN ('pending','approved') LIMIT 1",
                (a.upper(), b.upper()),
            )
        if used:
            self._admin(
                "SUSPICIOUS_PAYMENT",
                user_id=user_id,
                amount=row["amount"],
                utr=utr,
                ref=order_id,
                status="BLOCKED",
                details="Duplicate UTR submitted",
            )
            return False, "duplicate_utr"

        n = self._run(
            """UPDATE pending_payments SET utr=?, utr_submitted_at=?, status='pending',
                   reject_reason=NULL, last_check_at=0, check_count=0, utr_tries=COALESCE(utr_tries,0)+1
               WHERE order_id=? AND user_id=? AND status IN ('pending','expired','review')""",
            (utr, epoch_now(), order_id, user_id),
        )
        if n != 1:
            return False, "update_failed"
        self._activity(
            user_id, "UPI_UTR_SUBMIT", f"₹{row['amount']} | {order_id} | {utr}"
        )
        self._admin(
            "UTR_SUBMITTED",
            user_id=user_id,
            amount=row["amount"],
            utr=utr,
            ref=order_id,
            status="PENDING",
        )
        threading.Thread(
            target=self.verify_order, args=(order_id, True), daemon=True
        ).start()
        return True, utr

    def _table_exists(self, name: str) -> bool:
        return (
            self._one(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
            )
            is not None
        )

    # -- 3. verify (read-only) --
    def _check_mail(self, order, utr: str) -> dict:
        status, emails, err = self.mail.search_utr(utr)
        if status != "ok":
            return {"state": "error", "reason": err, "received_paise": None, "paid_at": None, "detail": ""}
        expected_paise = int(order["expected_amount"] or order["amount"]) * 100
        created = int(order["created_at"])
        utr_sub = (
            int(order["utr_submitted_at"]) if order["utr_submitted_at"] else None
        )
        now = epoch_now()
        matched, reject = False, None
        res = {"state": "waiting", "reason": "not_found", "received_paise": None, "paid_at": None, "detail": ""}
        for em in emails:
            if not (em["sender_ok"] and em["auth_ok"] and em["utr_match"]):
                continue
            matched = True
            if em["amount_paise"] is None:
                reject = reject or "amount_unreadable"
                continue
            res["received_paise"] = em["amount_paise"]
            if em["amount_paise"] != expected_paise:
                reject = "amount_mismatch"
                continue
            ok_t, why_t = check_payment_time(
                self.cfg, em, created, utr_sub, now
            )
            res["detail"] = (
                f"order={_fmt_ts(created)} | payment={_fmt_ts(em.get('paid_at'))} ({em.get('paid_src') or 'none'}) | arrival={_fmt_ts(em.get('arrival_at'))}"
            )
            if not ok_t:
                reject = reject or why_t
                continue
            res["state"] = "matched"
            res["reason"] = "ok"
            res["paid_at"] = em["paid_at"]
            return res
        if matched and reject:
            res.update(state="rejected", reason=reject)
        elif not matched:
            res.update(state="not_found", reason="email_not_found")
        return res

    def _credit(
        self,
        order_id: str,
        utr: str,
        received_paise: int,
        paid_at: Optional[int],
    ) -> tuple:
        """Single IMMEDIATE transaction -> double-credit namumkin."""
        conn = self.h.get_db()
        try:
            cur = conn.cursor()
            cur.execute("BEGIN IMMEDIATE")
            cur.execute(
                "SELECT * FROM pending_payments WHERE order_id=?", (order_id,)
            )
            row = cur.fetchone()
            if not row or row["status"] not in OPEN_STATUSES:
                conn.rollback()
                return "already_done", None
            if received_paise != int(row["amount"]) * 100:
                conn.rollback()
                return "amount_mismatch", row
            a, b = (utr_aliases(utr) + [utr, utr])[:2]
            if cur.execute(
                "SELECT 1 FROM payment_utrs WHERE UPPER(utr) IN (?, ?)",
                (a.upper(), b.upper()),
            ).fetchone():
                conn.rollback()
                return "duplicate_utr", row
            try:
                cur.execute(
                    """INSERT INTO payment_utrs
                       (utr, order_id, user_id, amount, received_paise, paid_at, credited_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        utr,
                        order_id,
                        row["user_id"],
                        int(row["amount"]),
                        received_paise,
                        paid_at,
                        epoch_now(),
                    ),
                )
            except sqlite3.IntegrityError:
                conn.rollback()
                return "duplicate_utr", row
            cur.execute(
                """UPDATE pending_payments SET status='completed', reject_reason=NULL,
                       received_amount=?, paid_at=?
                   WHERE id=? AND status IN ('pending','expired')""",
                (received_paise / 100.0, paid_at, row["id"]),
            )
            if cur.rowcount != 1:
                conn.rollback()
                return "already_done", None
            cur.execute(
                "UPDATE users SET balance = balance + ? WHERE id = ?",
                (int(row["amount"]), row["user_id"]),
            )
            if cur.rowcount != 1:
                conn.rollback()
                return "error", row
            cur.execute(
                """INSERT INTO transactions (user_id, amount, type, details, reference)
                   VALUES (?, ?, 'add_money', 'fam_pay', ?)""",
                (row["user_id"], int(row["amount"]), utr),
            )
            conn.commit()
            return "credited", row
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            log.error("credit error: %s", e)
            return "error", None
        finally:
            conn.close()

    def _mark_review(
        self, row, reason: str, received_paise: Optional[int], detail: str = ""
    ) -> None:
        rec = round(received_paise / 100.0, 2) if received_paise is not None else None
        n = self._run(
            "UPDATE pending_payments SET status='rejected', reject_reason=?, received_amount=? WHERE id=? AND status IN ('pending','expired')",
            (reason, rec, row["id"]),
        )
        if n != 1:
            return
        msg = REVIEW_MSG.get(reason, "Payment verify nahi ho payi.")
        self._user(
            row["user_id"],
            f"⚠️ <b>PAYMENT HOLD / REVIEW</b>\n\nOrder: <code>{esc(row['order_id'])}</code>\nReason: {esc(msg)}\n\nAdmin ko notify kar diya gaya hai.",
        )
        self._admin(
            "PAYMENT_REVIEW",
            user_id=row["user_id"],
            amount=row["amount"],
            utr=row["utr"],
            ref=row["order_id"],
            status="REVIEW",
            details=f"{reason} | got={rec} | {detail}".strip(" |"),
        )

    def verify_order(self, order_id: str, force: bool = False) -> str:
        lk = self._order_lock(order_id)
        if not lk.acquire(blocking=force):
            return "busy"
        try:
            row = self.get_order(order_id)
            if not row or row["status"] not in OPEN_STATUSES:
                return "already_done"
            if not row["utr"]:
                return "no_utr"
            if not force and epoch_now() - int(row["last_check_at"] or 0) < 10:
                return "skip"
            self._run(
                "UPDATE pending_payments SET last_check_at=?, check_count=COALESCE(check_count,0)+1 WHERE id=?",
                (epoch_now(), row["id"]),
            )
            res = self._check_mail(row, row["utr"])
            st = res["state"]
            if st == "matched":
                out, crow = self._credit(
                    order_id, row["utr"], res["received_paise"], res["paid_at"]
                )
                if out == "credited":
                    self._activity(
                        row["user_id"],
                        "UPI_PAYMENT_OK",
                        f"₹{row['amount']} | UTR:{row['utr']}",
                    )
                    self._user(
                        row["user_id"],
                        f"✅ <b>PAYMENT SUCCESS</b>\n\n💰 ₹{row['amount']} aapke balance me add ho gaya!\n🧾 UTR: <code>{esc(row['utr'])}</code>",
                    )
                    try:
                        self.h.on_credited(
                            row["user_id"], int(row["amount"]), row["utr"], order_id
                        )
                    except Exception as e:
                        log.exception("on_credited hook failed: %s", e)
                elif out == "duplicate_utr":
                    self._mark_review(
                        row, "duplicate_utr", res["received_paise"], ""
                    )
                elif out == "error":
                    self._admin(
                        "PAYMENT_ERROR",
                        user_id=row["user_id"],
                        amount=row["amount"],
                        utr=row["utr"],
                        ref=order_id,
                        status="FAILED",
                        details="db credit failed - balance NOT added",
                    )
                return out
            if st == "rejected":
                self._mark_review(
                    row, res["reason"], res["received_paise"], res["detail"]
                )
                return "rejected"
            return st
        except Exception as e:
            log.exception("verify_order error: %s", e)
            return "error"
        finally:
            lk.release()

    # -- 4. background worker --
    def _tick(self) -> None:
        now = epoch_now()
        conn = self.h.get_db()
        try:
            cur = conn.cursor()
            cur.execute(
                """SELECT id, user_id, order_id, amount FROM pending_payments
                   WHERE pay_method='upi_gmail' AND status='pending'
                   AND (utr IS NULL OR utr='') AND (? - created_at) > ?""",
                (now, self.cfg.order_window),
            )
            stale = cur.fetchall()
            cur.execute(
                """SELECT order_id, utr_submitted_at, created_at, last_check_at FROM pending_payments
                   WHERE pay_method='upi_gmail' AND status IN ('pending','expired')
                   AND utr IS NOT NULL AND utr != ''"""
            )
            todo = cur.fetchall()
            cur.close()
        finally:
            conn.close()

        for s in stale:
            if self._run(
                "UPDATE pending_payments SET status='expired' WHERE id=? AND status='pending' AND (utr IS NULL OR utr='')",
                (s["id"],),
            ):
                self._user(
                    s["user_id"],
                    f"⌛ Order <code>{esc(s['order_id'])}</code> (₹{s['amount']}) ka QR expire ho gaya. Agar payment kar di hai to UTR abhi bhi bhej sakte ho, warna naya QR generate karo.",
                )

        if self.mail.paused:
            return
        for r in todo:
            sub_at = int(r["utr_submitted_at"] or r["created_at"] or now)
            age = now - sub_at
            if age > self.cfg.verify_max_age:
                row = self.get_order(r["order_id"])
                if row and row["status"] in OPEN_STATUSES:
                    self._mark_review(row, "email_not_found_timeout", None, "")
                continue
            interval = self.cfg.retry_fast if age < 600 else self.cfg.retry_slow
            if now - int(r["last_check_at"] or 0) >= interval:
                self.verify_order(r["order_id"])

    def start_worker(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()

        def _loop():
            while not self._stop.is_set():
                try:
                    self._tick()
                except Exception as e:
                    log.exception("worker error: %s", e)
                self._stop.wait(self.cfg.worker_interval)

        self._thread = threading.Thread(
            target=_loop, name="fampay-worker", daemon=True
        )
        self._thread.start()

    def stop_worker(self, timeout: float = 5.0) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=timeout)


# ---------------------------------------------------------------------------
# Self-test (python paid_fampay_getway_soucre.py --selftest)
# ---------------------------------------------------------------------------
def _selftest() -> int:
    import tempfile
    from email.message import EmailMessage

    cfg = Config(
    gmail_address=os.getenv("GMAIL_ADDRESS", ""),
    gmail_app_password=os.getenv("GMAIL_APP_PASSWORD", ""),
        upi_id="9365989016@fam",
        store_name="EXALOTE EXN",
    )
    fails = []

    def ok(name, cond):
        print(("PASS " if cond else "FAIL ") + name)
        if not cond:
            fails.append(name)

    ok(
        "normalize FMPIB -> digits",
        normalize_utr("FMPIB674930533") == "674930533",
    )
    ok(
        "normalize UTR: prefix",
        normalize_utr("UTR: 123456789012") == "123456789012",
    )
    ok("reject short", normalize_utr("1234") is None)
    ok(
        "aliases",
        utr_aliases("674930533") == ["674930533", "FMPIB674930533"],
    )
    ok(
        "amount parse",
        parse_amount_paise("You received ₹ 125.50 from Rahul") == 12550,
    )
    ok(
        "amount ambiguous -> None",
        parse_amount_paise("received ₹100 and received ₹200") is None,
    )
    ok(
        "uri",
        build_upi_uri(cfg, 100, "RX1").startswith("upi://pay?pa=9365989016@fam&"),
    )

    now = epoch_now()
    m = EmailMessage()
    m["From"] = "FamPay <no-reply@fampay.in>"
    m["Subject"] = "You received ₹100"
    m["Authentication-Results"] = "mx.google.com; dkim=pass header.i=@fampay.in"
    m.set_content("You received ₹100.00 via UPI. UTR: FMPIB123456789012")
    em = parse_payment_email(cfg, m, "123456789012", now - 30)
    ok(
        "email parse + auth",
        em["sender_ok"] and em["auth_ok"] and em["utr_match"] and em["amount_paise"] == 10000,
    )
    ok(
        "time check passes",
        check_payment_time(cfg, em, now - 600, now - 60, now)[0],
    )
    ok(
        "time before order rejected",
        check_payment_time(cfg, em, now + 3000, now, now)[1] == "payment_before_order",
    )

    fake = EmailMessage()
    fake["From"] = "FamPay <evil@evil.com>"
    fake.set_content("You received ₹100.00 UTR: 123456789012")
    ok(
        "fake sender rejected",
        not parse_payment_email(cfg, fake, "123456789012", now - 10)["sender_ok"],
    )

    # DB flow (mail layer stubbed)
    path = os.path.join(tempfile.mkdtemp(), "t.db")

    def get_db():
        c = sqlite3.connect(path, timeout=10)
        c.row_factory = sqlite3.Row
        return c

    c = get_db()
    c.executescript(
        """CREATE TABLE users(id INTEGER PRIMARY KEY, balance INTEGER DEFAULT 0);
        CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INT, amount INT, type TEXT, details TEXT, reference TEXT);
        INSERT INTO users VALUES(1, 0);"""
    )
    c.commit()
    c.close()

    credited = []
    gw = FamPayGateway(
        cfg,
        Hooks(
            get_db=get_db,
            on_credited=lambda u, a, utr, o: credited.append((u, a, utr, o)),
        ),
    )
    gw.init()
    gw.mail.search_utr = lambda u: ("ok", [em], "")
    oid, uri = gw.create_order(1, 100)
    ok("create_order", oid is not None and "am=100.00" in uri)
    ok("bad utr rejected", gw.submit_utr(1, oid, "bad") == (False, "invalid_utr"))
    good = gw.submit_utr(1, oid, "123456789012") == (True, "123456789012")
    ok("submit_utr", good)
    time.sleep(0.5)
    out = gw.verify_order(oid, True)
    bal = get_db().execute("SELECT balance FROM users WHERE id=1").fetchone()[0]
    ok(
        f"credited once (balance={bal}, out={out})",
        bal == 100 and len(credited) == 1,
    )
    gw.verify_order(oid, True)
    ok(
        "replay does not double-credit",
        get_db().execute("SELECT balance FROM users WHERE id=1").fetchone()[0] == 100,
    )
    oid2, _ = gw.create_order(1, 100)
    ok(
        "same UTR on new order blocked",
        gw.submit_utr(1, oid2, "123456789012") == (False, "duplicate_utr"),
    )

    print("\nALL OK" if not fails else f"\nFAILED ({len(fails)}): {fails}")
    return 1 if fails else 0


if __name__ == "__main__":
    import sys

    if "--selftest" in sys.argv:
        raise SystemExit(_selftest())
    print(__doc__)
