#!/usr/bin/env python3
"""
EXALOTE EXN — FamPay Gateway HTTP service.

Runs the verbatim `fampay_gateway.py` module as a persistent local service
on 127.0.0.1:8666. Hooks bridge into the PHP/MySQL app over HTTP webhooks.
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fampay_gateway import (
    Config,
    FamPayGateway,
    Hooks,
    build_upi_uri,
    make_qr_png,
)

# ---- integration config ----
APP_BASE = os.getenv("APP_BASE", "http://127.0.0.1:8080")
HOOK_SECRET = os.getenv("GATEWAY_HOOK_SECRET", "").strip()
GATEWAY_DB = os.getenv("GATEWAY_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "gateway.db"))
PORT = int(os.getenv("GATEWAY_PORT", "8666"))


def get_db():
    """New sqlite connection to the gateway ledger (row_factory = Row)."""
    conn = sqlite3.connect(GATEWAY_DB, timeout=20)
    conn.row_factory = sqlite3.Row
    return conn


def prepare_ledger():
    """Create the mirror users/transactions tables expected by the gateway's
    internal `_credit` credit (users(id,balance), transactions(...))."""
    conn = get_db()
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                balance INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                type TEXT,
                details TEXT,
                reference TEXT,
                created_at INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        conn.commit()
    finally:
        conn.close()


def _post_hook_sync(action: str, payload: dict) -> None:
    """POST to the PHP webhook endpoint with shared-secret header (blocking)."""
    url = f"{APP_BASE}/api/payment-hook.php"
    data = json.dumps({"action": action, **payload}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "X-Gateway-Secret": HOOK_SECRET,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp.read()
    except Exception as exc:  # never crash the worker
        print(f"[webhook:{action}] failed: {exc}", file=sys.stderr)


def _post_hook(action: str, payload: dict) -> None:
    """Fire-and-forget webhook. Runs in a background thread so a single-threaded
    PHP dev server is never blocked waiting on the gateway while the gateway
    calls back into it (deadlock avoidance)."""
    threading.Thread(
        target=_post_hook_sync, args=(action, payload), daemon=True
    ).start()


def ensure_user_seeded(uid: int) -> None:
    """Seed a user row in the gateway's ledger `users` table so the gateway's
    internal `_credit` succeeds (it updates users.balance). The authoritative
    wallet credit happens later via the on_credited webhook into MySQL."""
    conn = get_db()
    try:
        cur = conn.cursor()
        cur.execute("INSERT OR IGNORE INTO users (id, balance) VALUES (?, 0)", (uid,))
        conn.commit()
        cur.close()
    finally:
        conn.close()


def make_hooks() -> Hooks:
    def on_credited(uid, amt, utr, oid):
        _post_hook("credit", {"user_id": uid, "amount": amt, "utr": utr, "order_id": oid})

    def notify_user(uid, text):
        _post_hook("notify-user", {"user_id": uid, "message": text})

    def notify_admin(event, **kw):
        _post_hook("notify-admin", {"event": event, "payload": kw})

    def log_activity(uid, act, detail):
        _post_hook("activity", {"user_id": uid, "activity": act, "detail": detail})

    return Hooks(
        get_db=get_db,
        on_credited=on_credited,
        notify_user=notify_user,
        notify_admin=notify_admin,
        log_activity=log_activity,
    )


gateway = FamPayGateway(Config.from_env(), make_hooks())


def _send(handler, code: int, data):
    body = json.dumps(data).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def _read_json(handler):
    length = int(handler.headers.get("Content-Length") or 0)
    if not length:
        return {}
    raw = handler.rfile.read(length)
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return {}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        qs = {}
        if "?" in self.path:
            for kv in self.path.split("?", 1)[1].split("&"):
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    qs[k] = v

        if path == "/health":
            h = gateway.health()
            _send(self, 200, {"ok": True, "health": h})
        elif path == "/status":
            oid = qs.get("order_id", "")
            row = gateway.get_order(oid)
            if not row:
                _send(self, 404, {"ok": False, "error": "order_not_found"})
                return
            _send(self, 200, {
                "ok": True,
                "order": dict(row),
                "status": row["status"],
                "reject_reason": row["reject_reason"],
                "utr": row["utr"],
                "amount": row["amount"],
                "created_at": row["created_at"],
                "received_amount": row["received_amount"],
            })
        elif path == "/qr":
            oid = qs.get("order_id", "")
            row = gateway.get_order(oid)
            if not row:
                _send(self, 404, {"ok": False, "error": "order_not_found"})
                return
            uri = build_upi_uri(gateway.cfg, int(row["amount"]), oid)
            png = make_qr_png(uri)
            if png is None:
                _send(self, 500, {"ok": False, "error": "qr_unavailable"})
                return
            data = png.read()
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        else:
            _send(self, 404, {"ok": False, "error": "not_found"})

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        body = _read_json(self)

        if path == "/create":
            uid = int(body.get("user_id") or 0)
            amount = int(body.get("amount") or 0)
            ensure_user_seeded(uid)
            oid, uri = gateway.create_order(uid, amount)
            if oid is None:
                _send(self, 400, {"ok": False, "error": uri})
                return
            row = gateway.get_order(oid)
            _send(self, 200, {
                "ok": True,
                "order_id": oid,
                "upi_uri": uri,
                "amount": amount,
                "created_at": row["created_at"],
                "expires_in": gateway.cfg.order_window,
            })
        elif path == "/cancel":
            uid = int(body.get("user_id") or 0)
            oid = body.get("order_id", "")
            ok = gateway.cancel_order(uid, oid)
            _send(self, 200, {"ok": ok})
        elif path == "/submit-utr":
            uid = int(body.get("user_id") or 0)
            oid = body.get("order_id", "")
            raw = body.get("raw_utr", "")
            ok, code = gateway.submit_utr(uid, oid, raw)
            _send(self, 200, {"ok": ok, "code": code})
        else:
            _send(self, 404, {"ok": False, "error": "not_found"})


def main():
    prepare_ledger()
    gateway.init()
    gateway.start_worker()
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"gateway service on 127.0.0.1:{PORT} (worker started)", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        gateway.stop_worker()
        srv.server_close()


if __name__ == "__main__":
    main()
