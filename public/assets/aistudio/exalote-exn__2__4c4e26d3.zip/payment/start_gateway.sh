#!/bin/sh
# EXALOTE EXN — start/stop the FamPay gateway service.
# Usage: sh payment/start_gateway.sh [start|stop|restart|status]
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
PY="$DIR/venv/bin/python"
LOG="$DIR/gateway.log"
PIDFILE="$DIR/gateway.pid"

start() {
  if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "gateway already running (pid $(cat "$PIDFILE"))"
    return 0
  fi
  # Environment (optional) — set these before starting to configure the gateway:
  #   GMAIL_ADDRESS, GMAIL_APP_PASSWORD, FAMPAY_UPI_ID,
  #   GATEWAY_HOOK_SECRET (must match the PHP app's GATEWAY_HOOK_SECRET),
  #   APP_BASE (PHP app URL for webhooks), GATEWAY_PORT, GATEWAY_DB.
  nohup "$PY" "$DIR/gateway_service.py" >> "$LOG" 2>&1 &
  echo $! > "$PIDFILE"
  sleep 1
  echo "gateway started (pid $(cat "$PIDFILE"))"
}

stop() {
  if [ -f "$PIDFILE" ]; then
    kill "$(cat "$PIDFILE")" 2>/dev/null || true
    rm -f "$PIDFILE"
    echo "gateway stopped"
  else
    echo "gateway not running"
  fi
}

status() {
  if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "running (pid $(cat "$PIDFILE"))"
  else
    echo "stopped"
  fi
}

case "${1:-start}" in
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
  status) status ;;
  *) echo "usage: $0 [start|stop|restart|status]"; exit 1 ;;
esac
