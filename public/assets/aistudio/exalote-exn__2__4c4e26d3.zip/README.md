# EXALOTE EXN — Tournament Management System

EXALOTE EXN is a mobile-first, free-to-play tournament platform built with **PHP + MySQL**, styled with **Tailwind CSS** and **Font Awesome**. It auto-publishes a daily tournament schedule in **IST** across 9 match categories, with single-host scheduling, player and admin dashboards, leaderboards and virtual points.

No frameworks, no AJAX — all actions run through traditional PHP form submissions + page reloads.

---

## ✨ Core Features

### 9 Match Categories
1. Lone Wolf Body — Solo
2. Lone Wolf Headshot — Solo
3. Full Map Per Kill — Solo
4. Full Map Survival — Solo
5. Headshot — 1v1
6. Headshot — 2v2
7. UMP — 1v1
8. Shotgun — 1v1
9. Desert Eagle — 1v1

### Free Registration
- Standard registration for auto-generated matches (free).
- Custom Match Registration — players request a custom room; admin approves/rejects.

### Daily Sessions (IST)
- Morning: 10:00 AM – 2:00 PM IST
- Evening: 8:00 PM – 12:00 AM IST
- Matches are only scheduled inside these windows.

### Automatic Daily Generation
- Auto-creates all 9 categories for both sessions **every day** (idempotent — no duplicates).
- Spacing uses match duration + buffer so the single host never overlaps.
- Missed scheduler runs are back-filled automatically.
- Old, never-started matches are archived as Cancelled.

### Single Host (Admin) Controls
- Create / override matches (category, date, time, capacity).
- Approve / reject registrations.
- Start match, Complete with winner selection, Cancel, Publish results.
- Winner gets **50 pts**, participants get **10 pts** (virtual points / leaderboard).
- Manage custom requests and automation settings.

### Player Dashboard
- Upcoming & available matches, category strip, register buttons, registration status.
- My Matches (registrations, history, custom request status), leaderboard, virtual points.

---

## 🛠 Requirements
- PHP 8+ with `pdo_mysql`
- MariaDB / MySQL
- Tailwind CSS + Font Awesome (CDN, no build step)
- A cron-capable server (Linux) for the scheduler

---

## 🚀 Quick Start (local)

1. **Place files** in your web root (e.g. XAMPP `htdocs`).
2. **Configure secrets**: copy `common/config.local.php.example` → `common/config.local.php` and set `INSTALLER_TOKEN` (and DB creds if not root/root). Or set env vars.
3. **Create the database** — open `http://localhost/install.php?token=YOUR_TOKEN` once. It creates the DB, tables, seeds categories and inserts the default admin. The installer refuses to run with the default token.
4. **Open the app**:
   - Player: `http://localhost/login.php`
   - Admin: `http://localhost/admin/login.php` → **admin / admin123** (you are forced to change it on first login)
5. **Run migrations after upgrades**: `http://localhost/update_database.php?token=YOUR_TOKEN` (add-only, safe to re-run).

### PHP built-in server (no Apache)
```bash
php -S 127.0.0.1:8080 -t /workspace
```
(On Alpine, use `php84` instead of `php`.)

---

## ⏰ Daily Automation Setup (IMPORTANT)

The app also has a page-load fallback, but for reliability set up a real cron job.

**1. Configure the crontab** (Linux):
```bash
crontab -e
```
Add (runs hourly; the script is safe to run repeatedly):
```
30 * * * * php /path/to/project/cron/auto_schedule.php >> /path/to/project/storage/scheduler.log 2>&1
```

**2. Verify** the generator:
```bash
php cron/auto_schedule.php
```
Expected: creates 18 matches (9 morning + 9 evening). Re-running reports `already generated` (idempotent).

**3. MariaDB start (if needed):**
```bash
sh start_db.sh
```

All times use the `Asia/Kolkata` timezone — set in `common/config.php`.

---

## 📁 Project Structure
```
├── common/            config.php, header.php, bottom.php, scheduler.php
├── admin/             login, dashboard, matches, custom_requests, automation,
│                      users, depositsits, withdrawals, transactions, settings
├── cron/              auto_schedule.php (daily generator)
├── storage/           runtime log + throttle marker
├── index.php          Player dashboard
├── my_tournaments.php My matches / history
├── login.php          Login/signup
├── wallet.php, profile.php
├── install.php, update_database.php, database.sql
├── start_db.sh
└── .htaccess
```

---

## 🌍 Deployment (shared hosting / VPS)
1. Upload the project to your web root.
2. Create a MySQL database + user, and update `common/config.php` credentials.
3. Visit `/install.php` once, then `/update_database.php`.
4. Create the cron job above (cPanel → Cron Jobs if on shared hosting).
5. Use HTTPS. Secure the admin password. Optionally protect `install.php` and `update_database.php` with `.htaccess`.

---

## 📱 Android APK / AAB (wrap the web app)

This is a web app, so the Android package wraps the site in a WebView.

**Option A — Trusted Web Activity (TWA) — recommended**
1. Build your site (it's already responsive).
2. Use [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap) to generate a TWA from your PWA/URL.
3. It produces an AAB (Google Play) and APK (sideload).

**Option B — Android Studio WebView wrapper**
1. New project → Empty Activity.
2. Add a `WebView` filling the screen, enable JavaScript, and load your deployed URL.
3. Build → Generate Signed Bundle/APK.

Add the URL to `android:scheme`/host config, and ensure your site is served over HTTPS (WebView requires it for many features).

---

## 🔒 Security Notes
- All queries use PHP **prepared statements**.
- Passwords are hashed with `password_hash()` (bcrypt).
- **CSRF** on every POST form + `api/payment.php` header token.
- **Login rate limiting** (5 fails / 15 min per IP+username).
- **Session cookies**: HttpOnly, SameSite=Lax, Secure on HTTPS.
- **No hardcoded secrets** — env / `config.local.php` (see `config.local.php.example`).
- Errors logged to `storage/app.log` (never displayed).
- `.htaccess` blocks `common/`, `cron/`, `payment/`, `storage/`, and sensitive file types.
- Sessions guard user + admin areas with redirects; first admin login forces a password change.

---

## 🧪 Tested flows
- Registration + admin approval → match start → completion with winner → points & leaderboard.
- Custom request → admin approve creates a match (overlap blocked).
- Daily generation idempotency, IST scheduling, overlap prevention.
- Fresh-install SQL validated.
