<?php
/**
 * EXALOTE EXN — Safe migration script.
 * Runs idempotent ALTER statements for features added after the base install.
 * Safe to run multiple times.
 */

require_once __DIR__ . '/common/config.php';

// --- Migration gate: requires the INSTALLER_TOKEN (GET ?token=) ---
$ok = false;
if (!empty($_GET['token']) && !INSTALLER_TOKEN_IS_DEFAULT) {
    $ok = hash_equals(INSTALLER_TOKEN, (string)$_GET['token']);
}
if (!$ok) {
    http_response_code(403);
    die('<p style="font-family:system-ui;color:#ff5c5c;text-align:center;margin-top:80px">Access denied. Run as <code>update_database.php?token=YOUR_TOKEN</code> with the INSTALLER_TOKEN env set.</p>');
}

function column_exists(PDO $pdo, string $table, string $col): bool
{
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $stmt->execute([$table, $col]);
    return (int)$stmt->fetchColumn() > 0;
}

$ran = [];
$pdo = db();

// --- tournaments: winner_user_id (prize payout) ---
if (!column_exists($pdo, 'tournaments', 'winner_user_id')) {
    $pdo->exec("ALTER TABLE tournaments ADD COLUMN winner_user_id INT UNSIGNED NULL AFTER status");
    $ran[] = 'tournaments.winner_user_id added';
}

// --- tournaments: description (optional) ---
if (!column_exists($pdo, 'tournaments', 'description')) {
    $pdo->exec("ALTER TABLE tournaments ADD COLUMN description VARCHAR(255) NULL AFTER title");
    $ran[] = 'tournaments.description added';
}

// --- users: phone (optional) ---
if (!column_exists($pdo, 'users', 'phone')) {
    $pdo->exec("ALTER TABLE users ADD COLUMN phone VARCHAR(15) NULL AFTER email");
    $ran[] = 'users.phone added';
}

// --- users: virtual_points (leaderboard) ---
if (!column_exists($pdo, 'users', 'virtual_points')) {
    $pdo->exec("ALTER TABLE users ADD COLUMN virtual_points INT NOT NULL DEFAULT 0 AFTER upi_id");
    $ran[] = 'users.virtual_points added';
}

function table_exists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
    );
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() > 0;
}

// --- categories (the 9 match categories) ---
if (!table_exists($pdo, 'categories')) {
    $pdo->exec("
        CREATE TABLE categories (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            format VARCHAR(30) NOT NULL DEFAULT 'Solo',
            code VARCHAR(60) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            UNIQUE KEY uq_code (code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $categories = [
        ['Lone Wolf Body', 'Solo', 'lone-wolf-body', 1],
        ['Lone Wolf Headshot', 'Solo', 'lone-wolf-headshot', 2],
        ['Full Map Per Kill', 'Solo', 'full-map-per-kill', 3],
        ['Full Map Survival', 'Solo', 'full-map-survival', 4],
        ['Headshot', '1v1', 'headshot-1v1', 5],
        ['Headshot', '2v2', 'headshot-2v2', 6],
        ['UMP', '1v1', 'ump-1v1', 7],
        ['Shotgun', '1v1', 'shotgun-1v1', 8],
        ['Desert Eagle', '1v1', 'desert-eagle-1v1', 9],
    ];
    $ins = $pdo->prepare('INSERT INTO categories (name, format, code, sort_order) VALUES (?, ?, ?, ?)');
    foreach ($categories as $c) {
        $ins->execute($c);
    }
    $ran[] = 'categories created + 9 seeded';
} else {
    $ran[] = 'categories already exist';
}

// --- matches (admin-scheduled matches) ---
if (!table_exists($pdo, 'matches')) {
    $pdo->exec("
        CREATE TABLE matches (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            category_id INT UNSIGNED NOT NULL,
            match_date DATE NOT NULL,
            session ENUM('morning','evening') NOT NULL,
            start_time TIME NOT NULL,
            player_capacity INT NOT NULL DEFAULT 10,
            status ENUM('Upcoming','Live','Completed','Cancelled') NOT NULL DEFAULT 'Upcoming',
            winner_user_id INT UNSIGNED NULL,
            published TINYINT(1) NOT NULL DEFAULT 0,
            host_note VARCHAR(255) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_cat_date_session (category_id, match_date, session),
            KEY idx_date (match_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $ran[] = 'matches created';
} else {
    $ran[] = 'matches already exist';
}

// --- registrations (free player signups for matches) ---
if (!table_exists($pdo, 'registrations')) {
    $pdo->exec("
        CREATE TABLE registrations (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            match_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            status ENUM('Approved','Pending','Rejected') NOT NULL DEFAULT 'Pending',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_match_user (match_id, user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $ran[] = 'registrations created';
} else {
    $ran[] = 'registrations already exist';
}

// --- custom_requests (players request a custom match) ---
if (!table_exists($pdo, 'custom_requests')) {
    $pdo->exec("
        CREATE TABLE custom_requests (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            title VARCHAR(120) NOT NULL,
            category_name VARCHAR(100) NOT NULL,
            format VARCHAR(30) NOT NULL DEFAULT 'Solo',
            match_date DATE NOT NULL,
            start_time TIME NOT NULL,
            notes TEXT NULL,
            status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
            admin_note VARCHAR(255) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $ran[] = 'custom_requests created';
} else {
    $ran[] = 'custom_requests already exist';
}

// --- settings (singleton automation config) ---
if (!table_exists($pdo, 'settings')) {
    $pdo->exec("
        CREATE TABLE settings (
            id TINYINT NOT NULL DEFAULT 1 PRIMARY KEY,
            automation_enabled TINYINT(1) NOT NULL DEFAULT 1,
            duration_min INT NOT NULL DEFAULT 20,
            buffer_min INT NOT NULL DEFAULT 5,
            capacity_default INT NOT NULL DEFAULT 10,
            last_generated_date DATE NULL,
            skip_dates TEXT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $pdo->exec("INSERT INTO settings (id) VALUES (1)");
    $ran[] = 'settings created (singleton)';
} else {
    $ran[] = 'settings already exist';
}

// --- settings: add automation columns to the existing settings table ---
foreach ([
    'automation_enabled' => 'TINYINT(1) NOT NULL DEFAULT 1',
    'duration_min'       => 'INT NOT NULL DEFAULT 20',
    'buffer_min'         => 'INT NOT NULL DEFAULT 5',
    'capacity_default'   => 'INT NOT NULL DEFAULT 10',
    'last_generated_date' => 'DATE NULL',
    'skip_dates'         => 'TEXT NULL',
] as $col => $def) {
    if (table_exists($pdo, 'settings') && !column_exists($pdo, 'settings', $col)) {
        $pdo->exec("ALTER TABLE settings ADD COLUMN $col $def");
        $ran[] = "settings.$col added";
    }
}
if (table_exists($pdo, 'settings')) {
    $chk = $pdo->query('SELECT COUNT(*) FROM settings WHERE id = 1');
    if ((int)$chk->fetchColumn() === 0) {
        $pdo->exec("INSERT INTO settings (id) VALUES (1)");
        $ran[] = 'settings row 1 ensured';
    }
}

// --- matches: ensure required columns exist if table pre-exists ---
foreach (['winner_user_id' => 'INT UNSIGNED NULL', 'published' => 'TINYINT(1) NOT NULL DEFAULT 0', 'host_note' => 'VARCHAR(255) NULL', 'entry_fee' => 'DECIMAL(12,2) NOT NULL DEFAULT 0.00', 'prize_pool' => 'DECIMAL(12,2) NOT NULL DEFAULT 0.00'] as $col => $def) {
    if (table_exists($pdo, 'matches') && !column_exists($pdo, 'matches', $col)) {
        $pdo->exec("ALTER TABLE matches ADD COLUMN $col $def");
        $ran[] = "matches.$col added";
    }
}

// --- settings: wallet_enabled toggle ---
if (table_exists($pdo, 'settings') && !column_exists($pdo, 'settings', 'wallet_enabled')) {
    $pdo->exec("ALTER TABLE settings ADD COLUMN wallet_enabled TINYINT(1) NOT NULL DEFAULT 1");
    $ran[] = 'settings.wallet_enabled added';
}

// --- registrations: fee_status marker (prevents double refunds) ---
if (table_exists($pdo, 'registrations') && !column_exists($pdo, 'registrations', 'fee_status')) {
    $pdo->exec("ALTER TABLE registrations ADD COLUMN fee_status ENUM('none','paid','refunded') NOT NULL DEFAULT 'none'");
    $ran[] = 'registrations.fee_status added';
}

// --- deposits: unique UTR (transaction_id) to prevent double-approval ---
if (table_exists($pdo, 'deposits')) {
    $dup = $pdo->query('SELECT transaction_id, COUNT(*) AS n FROM deposits GROUP BY transaction_id HAVING n > 1 LIMIT 1')->fetch();
    $idx = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'deposits' AND INDEX_NAME = 'uq_dep_transaction'")->fetchColumn();
    if (!$dup && (int)$idx === 0) {
        $pdo->exec('ALTER TABLE deposits ADD UNIQUE KEY uq_dep_transaction (transaction_id)');
        $ran[] = 'deposits.transaction_id UNIQUE added';
    } elseif ($dup) {
        $ran[] = 'SKIPPED deposits unique UTR: duplicate transaction_ids exist (see report)';
    }
}

// --- users: Free Fire UID + IGN binding ---
foreach ([
    'ff_uid' => 'VARCHAR(30) NULL',
    'ff_ign' => 'VARCHAR(60) NULL',
] as $col => $def) {
    if (table_exists($pdo, 'users') && !column_exists($pdo, 'users', $col)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN $col $def");
        $ran[] = "users.$col added";
    }
}

// --- users: three-bucket wallet ---
foreach ([
    'deposit_balance'   => 'DECIMAL(10,2) NOT NULL DEFAULT 0.00',
    'winnings_balance'  => 'DECIMAL(10,2) NOT NULL DEFAULT 0.00',
    'bonus_balance'     => 'DECIMAL(10,2) NOT NULL DEFAULT 0.00',
] as $col => $def) {
    if (table_exists($pdo, 'users') && !column_exists($pdo, 'users', $col)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN $col $def");
        $ran[] = "users.$col added";
    }
}

// --- users: backfill buckets from existing single wallet_balance ---
if (table_exists($pdo, 'users') && column_exists($pdo, 'users', 'deposit_balance')) {
    $pdo->exec(
        "UPDATE users SET deposit_balance = wallet_balance
         WHERE deposit_balance = 0.00 AND winnings_balance = 0.00 AND bonus_balance = 0.00"
    );
    $ran[] = 'users buckets backfilled from wallet_balance';
}

// --- matches: room / map / rules / prize lock columns ---
foreach ([
    'room_id'            => 'VARCHAR(50) NULL',
    'room_password'       => 'VARCHAR(50) NULL',
    'room_published'      => 'TINYINT(1) NOT NULL DEFAULT 0',
    'map_name'            => "VARCHAR(50) NOT NULL DEFAULT 'Bermuda'",
    'match_rules'         => 'TEXT NULL',
    'prizes_distributed'  => 'TINYINT(1) NOT NULL DEFAULT 0',
] as $col => $def) {
    if (table_exists($pdo, 'matches') && !column_exists($pdo, 'matches', $col)) {
        $pdo->exec("ALTER TABLE matches ADD COLUMN $col $def");
        $ran[] = "matches.$col added";
    }
}

// --- registrations: Fast Fire snapshot + slot number ---
foreach ([
    'ff_uid' => 'VARCHAR(30) NULL',
    'ff_ign' => 'VARCHAR(60) NULL',
    'slot_number' => 'INT NULL',
] as $col => $def) {
    if (table_exists($pdo, 'registrations') && !column_exists($pdo, 'registrations', $col)) {
        $pdo->exec("ALTER TABLE registrations ADD COLUMN $col $def");
        $ran[] = "registrations.$col added";
    }
}
// Unique (match_id, ff_uid) — same FF UID cannot join the same match twice.
if (table_exists($pdo, 'registrations') && column_exists($pdo, 'registrations', 'ff_uid')) {
    $hasIdx = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'registrations' AND INDEX_NAME = 'uq_match_ffuid'")->fetchColumn();
    if ((int)$hasIdx === 0) {
        $pdo->exec("ALTER TABLE registrations ADD UNIQUE KEY uq_match_ffuid (match_id, ff_uid)");
        $ran[] = 'registrations unique (match_id, ff_uid) added';
    }
}

// --- registrations: team_members (JSON array of {ff_uid, ff_ign}) for Duo/Squad/2v2/4v4 ---
if (table_exists($pdo, 'registrations') && !column_exists($pdo, 'registrations', 'team_members')) {
    $pdo->exec("ALTER TABLE registrations ADD COLUMN team_members TEXT NULL");
    $ran[] = 'registrations.team_members added';
}

// --- match_claims: player result claims + screenshot + hack report ---
if (!table_exists($pdo, 'match_claims')) {
    $pdo->exec("
        CREATE TABLE match_claims (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            match_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            claimed_kills INT NOT NULL DEFAULT 0,
            claimed_rank INT NOT NULL DEFAULT 0,
            screenshot_path VARCHAR(255) NULL,
            report_suspect_ign VARCHAR(100) NULL,
            report_reason TEXT NULL,
            status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_match_user_claim (match_id, user_id),
            KEY idx_claim_status (status),
            CONSTRAINT fk_claim_match FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
            CONSTRAINT fk_claim_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $ran[] = 'match_claims table created';
}

// --- transactions: widen `type` enum to include 'points' (leaderboard credits) ---
if (table_exists($pdo, 'transactions')) {
    $txcol = $pdo->query("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'transactions' AND COLUMN_NAME = 'type'")->fetchColumn();
    if ($txcol !== false && strpos((string)$txcol, 'points') === false) {
        $pdo->exec("ALTER TABLE transactions MODIFY COLUMN type ENUM('credit','debit','points') NOT NULL");
        $ran[] = 'transactions.type widened to include points';
    }
}

// --- login_attempts (rate limiting) ---
if (!table_exists($pdo, 'login_attempts')) {
    $pdo->exec("
        CREATE TABLE login_attempts (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            identifier VARCHAR(120) NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            attempted_at INT UNSIGNED NOT NULL,
            KEY idx_attempt (identifier, ip_address, attempted_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $ran[] = 'login_attempts created';
}

// --- notifications (FamPay notify_user hook) ---
if (!table_exists($pdo, 'notifications')) {
    $pdo->exec("
        CREATE TABLE notifications (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            message TEXT NOT NULL,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_user (user_id, is_read)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $ran[] = 'notifications created';
} else {
    $ran[] = 'notifications already exist';
}

// --- notifications: kind + link (for tournament-linked notifications) ---
foreach (['kind' => 'VARCHAR(40) NULL', 'link' => 'VARCHAR(255) NULL'] as $col => $def) {
    if (!column_exists($pdo, 'notifications', $col)) {
        $pdo->exec("ALTER TABLE notifications ADD COLUMN $col $def");
        $ran[] = "notifications.$col added";
    }
}

// --- results (rank/kills/rewards per match participant; unique = anti double-pay) ---
if (!table_exists($pdo, 'results')) {
    $pdo->exec("
        CREATE TABLE results (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            match_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            rank INT NOT NULL DEFAULT 0,
            kills INT NOT NULL DEFAULT 0,
            reward_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_match_user (match_id, user_id),
            KEY idx_match (match_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $ran[] = 'results created';
} else {
    $ran[] = 'results already exist';
}

// --- settings: reward rule config ---
foreach ([
    'reward_rank_json'       => 'TEXT NULL',
    'reward_participation'   => 'DECIMAL(12,2) NOT NULL DEFAULT 0.00',
    'reward_per_kill'        => 'DECIMAL(12,2) NOT NULL DEFAULT 0.00',
] as $col => $def) {
    if (table_exists($pdo, 'settings') && !column_exists($pdo, 'settings', $col)) {
        $pdo->exec("ALTER TABLE settings ADD COLUMN $col $def");
        $ran[] = "settings.$col added";
    }
}
// seed default rank rewards (1st/2nd/3rd) if empty
if (table_exists($pdo, 'settings')) {
    $rw = $pdo->query('SELECT reward_rank_json FROM settings WHERE id = 1')->fetchColumn();
    if ($rw === null || $rw === '') {
        $pdo->exec("UPDATE settings SET reward_rank_json = '{\"1\":250,\"2\":150,\"3\":100}' WHERE id = 1");
        $ran[] = 'settings.reward_rank_json defaulted';
    }
}

// --- matches: add 'Registration Closed' to status ENUM ---
if (table_exists($pdo, 'matches')) {
    $col = $pdo->prepare(
        "SELECT COLUMN_TYPE FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'matches' AND COLUMN_NAME = 'status'"
    );
    $col->execute();
    $colType = (string)$col->fetchColumn();
    if ($colType !== '' && strpos($colType, 'Registration Closed') === false) {
        $pdo->exec("ALTER TABLE matches MODIFY COLUMN status ENUM('Upcoming','Registration Closed','Live','Completed','Cancelled') NOT NULL DEFAULT 'Upcoming'");
        $ran[] = 'matches.status ENUM extended (Registration Closed)';
    }
}

// --- admin_log (FamPay notify_admin hook) ---
if (!table_exists($pdo, 'admin_log')) {
    $pdo->exec("
        CREATE TABLE admin_log (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            event VARCHAR(80) NOT NULL,
            payload TEXT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_event (event)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $ran[] = 'admin_log created';
} else {
    $ran[] = 'admin_log already exist';
}

$pdo = null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update — EXALOTE EXN</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-950 text-gray-100 min-h-screen flex items-center justify-center p-6">
  <div class="max-w-md w-full bg-gray-900 border border-gray-800 rounded-2xl p-8 text-center">
    <h1 class="text-xl font-bold mb-3">Database Update</h1>
    <?php if ($ran): ?>
      <ul class="text-left text-green-400 space-y-1 mb-4">
        <?php foreach ($ran as $r): ?>
          <li>✅ <?= htmlspecialchars($r) ?></li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="text-gray-400 mb-4">Schema is already up to date. No changes required.</p>
    <?php endif; ?>
    <a href="index.php" class="inline-block bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-6 py-3 rounded-xl transition">Go Home</a>
  </div>
</body>
</html>
