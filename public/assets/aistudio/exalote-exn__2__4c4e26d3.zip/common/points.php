<?php
/**
 * EXALOTE EXN — Virtual points helpers (non-cash rewards).
 */
require_once __DIR__ . '/config.php';

/**
 * Recent points transactions for a user (type='points').
 */
function points_history(int $userId, int $limit = 20): array
{
    $stmt = db()->prepare('SELECT * FROM transactions WHERE user_id = ? AND type = "points" ORDER BY created_at DESC, id DESC LIMIT ?');
    $stmt->bindValue(1, $userId, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Basic performance summary for a user.
 */
function player_stats(int $userId): array
{
    $played = db()->prepare("SELECT COUNT(*) FROM registrations r JOIN matches m ON m.id = r.match_id WHERE r.user_id = ? AND r.status = 'Approved' AND m.status = 'Completed'");
    $played->execute([$userId]);

    $wins = db()->prepare('SELECT COUNT(*) FROM matches WHERE winner_user_id = ? AND status = "Completed"');
    $wins->execute([$userId]);

    $totalKills = db()->prepare('SELECT COALESCE(SUM(kills),0) FROM results WHERE user_id = ?');
    $totalKills->execute([$userId]);

    return [
        'played'   => (int)$played->fetchColumn(),
        'wins'     => (int)$wins->fetchColumn(),
        'kills'    => (int)$totalKills->fetchColumn(),
    ];
}
