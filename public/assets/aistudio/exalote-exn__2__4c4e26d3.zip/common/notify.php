<?php
/**
 * EXALOTE EXN — Notification helper.
 * Provides notify() for generating in-app notifications from backend events.
 */

require_once __DIR__ . '/config.php';

/**
 * Insert a notification for a user.
 *
 * @param int    $userId    recipient user id
 * @param string $message   display text (HTML allowed, escaped where needed)
 * @param string $kind      event kind (join|approve|reject|start|room|cancel|result|win|deposit|withdraw|new_match|reminder)
 * @param string $link      optional relative URL (e.g. my_tournaments.php)
 * @param bool   $dedupe    if true, skip insert if an unread notification with same kind+message exists
 */
function notify(int $userId, string $message, string $kind = '', string $link = '', bool $dedupe = false): void
{
    if ($userId <= 0) {
        return;
    }
    try {
        if ($dedupe) {
            $chk = db()->prepare(
                'SELECT id FROM notifications WHERE user_id = ? AND kind = ? AND message = ? AND is_read = 0 LIMIT 1'
            );
            $chk->execute([$userId, $kind, $message]);
            if ($chk->fetch()) {
                return;
            }
        }
        $stmt = db()->prepare('INSERT INTO notifications (user_id, message, kind, link) VALUES (?, ?, ?, ?)');
        $stmt->execute([$userId, $message, $kind, $link]);
    } catch (Throwable $e) {
        // notification failure must never break the main action
    }
}

/**
 * Unread notification count for a user (for the header badge).
 */
function unread_notifications(int $userId): int
{
    if ($userId <= 0) {
        return 0;
    }
    try {
        $stmt = db()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Cron job: send "match starts in 15 minutes" reminders to approved players,
 * and "room available" notices when a live match has host_note set.
 * Idempotent via dedupe (kind + message). Safe to run frequently.
 *
 * @return array{log:list<string>,reminders:int,rooms:int}
 */
function send_match_reminders(): array
{
    date_default_timezone_set('Asia/Kolkata');
    $log = [];
    $reminders = 0;
    $rooms = 0;

    $now = time();
    $in15 = date('Y-m-d H:i:s', $now + 15 * 60);

    // Matches starting within the next 15 minutes (IST)
    $stmt = db()->prepare("
        SELECT m.id, m.match_date, m.start_time, m.host_note, c.name AS cat_name
        FROM matches m
        JOIN categories c ON c.id = m.category_id
        WHERE m.status IN ('Upcoming','Registration Closed')
          AND TIMESTAMP(m.match_date, m.start_time) BETWEEN NOW() AND ?
    ");
    $stmt->execute([$in15]);
    $due = $stmt->fetchAll();

    $players = db()->prepare("SELECT user_id FROM registrations WHERE match_id = ? AND status = 'Approved'");

    foreach ($due as $m) {
        $mTime = date('h:i A', strtotime($m['match_date'] . ' ' . $m['start_time']));
        $players->execute([$m['id']]);
        while ($p = $players->fetch()) {
            notify(
                (int)$p['user_id'],
                '⏰ ' . $m['cat_name'] . ' starts in 15 minutes (' . $mTime . ' IST). Get ready!',
                'reminder',
                'my_tournaments.php',
                true
            );
            $reminders++;
        }
        $log[] = 'reminder: match #' . $m['id'] . ' (' . $m['cat_name'] . ') @ ' . $mTime;
    }

    // Live matches with a room note: notify approved players once
    $live = db()->query("
        SELECT m.id, m.host_note, c.name AS cat_name
        FROM matches m
        JOIN categories c ON c.id = m.category_id
        WHERE m.status = 'Live' AND m.host_note IS NOT NULL AND TRIM(m.host_note) <> ''
    ")->fetchAll();
    foreach ($live as $m) {
        $players->execute([$m['id']]);
        while ($p = $players->fetch()) {
            notify(
                (int)$p['user_id'],
                '🏟️ ' . $m['cat_name'] . ' room is ready. Room: ' . $m['host_note'],
                'room',
                'my_tournaments.php',
                true
            );
            $rooms++;
        }
        $log[] = 'room notice: match #' . $m['id'];
    }

    return ['log' => $log, 'reminders' => $reminders, 'rooms' => $rooms];
}
