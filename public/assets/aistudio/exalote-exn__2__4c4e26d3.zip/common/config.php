<?php
/**
 * EXALOTE EXN — Database configuration & shared helpers
 */

// ------------------------------------------------------------------
// Configuration loading
// ------------------------------------------------------------------
// Priority: environment variables > config.local.php (untracked) > defaults.
// No hardcoded secrets remain. Copy common/config.local.php.example to
// common/config.local.php and fill in production values, or export env vars.
$__localConfig = __DIR__ . '/config.local.php';
$__local = [];
if (is_file($__localConfig)) {
    $__local = (array)include $__localConfig;
}
if (!is_array($__local)) {
    $__local = [];
}
function env_or(array $local, string $key, string $default): string
{
    $v = getenv($key);
    if ($v !== false && $v !== '') {
        return $v;
    }
    return isset($local[$key]) && $local[$key] !== '' ? (string)$local[$key] : $default;
}

// --- Database credentials ---
define('DB_HOST', env_or($__local, 'DB_HOST', '127.0.0.1'));
define('DB_NAME', env_or($__local, 'DB_NAME', 'tournament_app'));
define('DB_USER', env_or($__local, 'DB_USER', 'root'));
define('DB_PASS', env_or($__local, 'DB_PASS', 'root'));

// --- One-time installer token. Never accept the known-insecure default. ---
$__installerDefault = 'change_me_installer_token';
define('INSTALLER_TOKEN', env_or($__local, 'INSTALLER_TOKEN', $__installerDefault));
define('INSTALLER_TOKEN_IS_DEFAULT', INSTALLER_TOKEN === $__installerDefault);

// --- FamPay gateway service (optional local Python daemon) ---
define('GATEWAY_BASE', env_or($__local, 'GATEWAY_BASE', 'http://127.0.0.1:8666'));
define('GATEWAY_HOOK_SECRET', env_or($__local, 'GATEWAY_HOOK_SECRET', 'exn-fampay-hook-secret'));

// --- Error handling: log to file, never display outside installer ---
error_reporting(E_ALL);
if (PHP_SAPI !== 'cli' && !defined('EXN_INSTALLING')) {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', __DIR__ . '/../storage/app.log');
}

// --- Session bootstrap with hardened cookie flags ---
if (session_status() === PHP_SESSION_NONE) {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

date_default_timezone_set('Asia/Kolkata');

/**
 * Return a shared PDO connection.
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            die('Database unavailable. Please run install.php first.');
        }
    }
    return $pdo;
}

/**
 * Redirect helper.
 */
function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/**
 * CSRF: get (and lazily create) the session token.
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * CSRF: render a hidden input field.
 */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/**
 * CSRF: verify the submitted token; redirects (POST) on failure.
 */
function csrf_verify(): void
{
    if (empty($_SESSION['csrf_token'])
        || empty($_POST['csrf_token'])
        || !hash_equals($_SESSION['csrf_token'], (string)$_POST['csrf_token'])) {
        http_response_code(419);
        die('Invalid or expired session token. Please go back and try again.');
    }
}

/**
 * Whether a user is logged in.
 */
function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

/**
 * Current logged-in user id (or 0).
 */
function current_user_id(): int
{
    return (int)($_SESSION['user_id'] ?? 0);
}

/**
 * Current user row (fresh from DB).
 */
function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([current_user_id()]);
    return $stmt->fetch() ?: null;
}

/**
 * Is the current session an admin?
 */
function is_admin(): bool
{
    return !empty($_SESSION['admin_id']);
}

/**
 * Clean a string for display (basic XSS guard).
 */
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/**
 * Format money as rupee string.
 */
function money($amount): string
{
    return '₹' . number_format((float)$amount, 2);
}

/**
 * Log an in-app transaction for a user.
 */
function log_transaction(int $userId, float $amount, string $type, string $description): void
{
    $stmt = db()->prepare(
        'INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)'
    );
    $stmt->execute([$userId, $amount, $type, $description]);
}

/**
 * Insert a user notification.
 */
function notify_user_db(int $userId, string $message): void
{
    notify($userId, $message);
}

/**
 * Whether the wallet / cash features are enabled (settings.wallet_enabled).
 */
function wallet_enabled(): bool
{
    static $cached = null;
    if ($cached === null) {
        $cached = (bool)db()->query('SELECT wallet_enabled FROM settings WHERE id = 1')->fetchColumn();
    }
    return $cached;
}

/**
 * Login rate limiting helper.
 * Returns true if the given identifier+IP is currently rate-limited
 * (>= 5 failed attempts in the last 15 minutes). Records a failed attempt
 * when $fail is true.
 */
function login_rate_limit(string $identifier, string $ip, bool $fail = false): bool
{
    $window = 900; // 15 min
    $max = 5;
    $now = time();
    if ($fail) {
        db()->prepare('INSERT INTO login_attempts (identifier, ip_address, attempted_at) VALUES (?, ?, ?)')
            ->execute([$identifier, $ip, $now]);
    }
    $cut = $now - $window;
    $stmt = db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE identifier = ? AND ip_address = ? AND attempted_at > ?');
    $stmt->execute([$identifier, $ip, $cut]);
    return (int)$stmt->fetchColumn() >= $max;
}

/**
 * Read reward rule config from settings (in virtual points).
 *
 * @return array{rank:array<int,float>,participation:float,per_kill:float}
 */
function reward_rules(): array
{
    $s = db()->query('SELECT reward_rank_json, reward_participation, reward_per_kill FROM settings WHERE id = 1')->fetch();
    $rank = [];
    $raw = $s['reward_rank_json'] ?? '';
    if ($raw !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            foreach ($decoded as $k => $v) {
                $rank[(int)$k] = (float)$v;
            }
        }
    }
    return [
        'rank'         => $rank,
        'participation' => (float)($s['reward_participation'] ?? 0),
        'per_kill'     => (float)($s['reward_per_kill'] ?? 0),
    ];
}

/**
 * Credit virtual points to a user inside a DB transaction.
 * Duplicate-award guard is handled by the caller via the unique (match_id, user_id)
 * key on `results`; this function only performs the actual, atomic credit.
 *
 * @param float  $points      points to credit
 * @param string $description transaction description
 * @param string $reference   optional reference string appended to the description
 */
function credit_points(int $userId, float $points, string $description, string $reference = ''): bool
{
    if ($points <= 0) {
        return false;
    }
    $pd = db();
    $ownTx = !$pd->inTransaction();
    try {
        if ($ownTx) {
            $pd->beginTransaction();
        }
        $stmt = $pd->prepare('UPDATE users SET virtual_points = virtual_points + ? WHERE id = ?');
        $stmt->execute([$points, $userId]);
        if ($stmt->rowCount() !== 1) {
            if ($ownTx) {
                $pd->rollBack();
            }
            return false;
        }
        $desc = $description . ($reference !== '' ? ' (' . $reference . ')' : '');
        $pd->prepare('INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)')
            ->execute([$userId, $points, 'points', $desc]);
        if ($ownTx) {
            $pd->commit();
        }
        return true;
    } catch (Throwable $e) {
        if ($ownTx && $pd->inTransaction()) {
            $pd->rollBack();
        }
        return false;
    }
}

/**
 * Call the local FamPay gateway service (HTTP JSON). Returns
 * ['status' => int, 'body' => array].
 */
function gateway_request(string $method, string $path, array $body = []): array
{
    $url = GATEWAY_BASE . $path;
    $opts = [
        'http' => [
            'method'        => $method,
            'timeout'       => 15,
            'ignore_errors' => true,
            'header'        => "Content-Type: application/json\r\n",
            'content'       => json_encode($body),
        ],
    ];
    $ctx = stream_context_create($opts);
    $raw = @file_get_contents($url, false, $ctx);
    $status = 0;
    if (isset($http_response_header[0]) && preg_match('#HTTP/\S+ (\d+)#', $http_response_header[0], $m)) {
        $status = (int)$m[1];
    }
    $decoded = $raw !== false ? json_decode($raw, true) : null;
    return [
        'status' => $status,
        'body'   => is_array($decoded) ? $decoded : ['raw' => $raw, 'error' => 'gateway_unreachable'],
    ];
}

/**
 * Credit a user's wallet for a verified payment (deposit).
 * Updates wallet_balance, logs a 'credit' transaction, and records a deposit row.
 *
 * @return bool true on success
 */
function credit_wallet(int $userId, float $amount, string $utr, string $orderId): bool
{
    if ($amount <= 0 || $userId <= 0) {
        return false;
    }
    $pd = db();
    $ownTx = !$pd->inTransaction();
    try {
        if ($ownTx) {
            $pd->beginTransaction();
        }
        // Deposits credit the DEPOSIT bucket (not directly withdrawable).
        $stmt = $pd->prepare('UPDATE users SET deposit_balance = deposit_balance + ?, wallet_balance = wallet_balance + ? WHERE id = ?');
        $stmt->execute([$amount, $amount, $userId]);
        if ($stmt->rowCount() !== 1) {
            if ($ownTx) {
                $pd->rollBack();
            }
            return false;
        }
        $pd->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', ?)")
            ->execute([$userId, $amount, 'Deposit via UPI (UTR ' . $utr . ')']);
        $pd->prepare("INSERT INTO deposits (user_id, amount, transaction_id, status) VALUES (?, ?, ?, 'Completed')")
            ->execute([$userId, $amount, $utr]);
        if ($ownTx) {
            $pd->commit();
        }
        return true;
    } catch (Throwable $e) {
        if ($ownTx && $pd->inTransaction()) {
            $pd->rollBack();
        }
        return false;
    }
}

/**
 * Credit a tournament reward (cash) to a user's wallet.
 * Transaction-aware: respects an existing outer transaction.
 */
function credit_reward(int $userId, float $amount, string $description, string $reference = ''): bool
{
    if ($amount <= 0 || $userId <= 0) {
        return false;
    }
    $pd = db();
    $ownTx = !$pd->inTransaction();
    try {
        if ($ownTx) {
            $pd->beginTransaction();
        }
        // Match prizes credit the WINNINGS bucket (withdrawable only).
        $stmt = $pd->prepare('UPDATE users SET winnings_balance = winnings_balance + ?, wallet_balance = wallet_balance + ? WHERE id = ?');
        $stmt->execute([$amount, $amount, $userId]);
        if ($stmt->rowCount() !== 1) {
            if ($ownTx) {
                $pd->rollBack();
            }
            return false;
        }
        $desc = $description . ($reference !== '' ? ' (' . $reference . ')' : '');
        $pd->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', ?)")
            ->execute([$userId, $amount, $desc]);
        if ($ownTx) {
            $pd->commit();
        }
        return true;
    } catch (Throwable $e) {
        if ($ownTx && $pd->inTransaction()) {
            $pd->rollBack();
        }
        return false;
    }
}

/**
 * Deduct an entry fee from a user's wallet inside the CURRENT transaction.
 * Order: Bonus (up to 10% of fee) → Deposit → Winnings. Keeps wallet_balance
 * in sync. Returns true if the full fee could be covered; false otherwise.
 */
function deduct_entry_fee(int $userId, float $fee): bool
{
    if ($fee <= 0) {
        return true;
    }
    $pd = db();
    $u = $pd->prepare('SELECT deposit_balance, winnings_balance, bonus_balance FROM users WHERE id = ? FOR UPDATE');
    $u->execute([$userId]);
    $row = $u->fetch();
    if (!$row) {
        return false;
    }
    $deposit = (float)$row['deposit_balance'];
    $winnings = (float)$row['winnings_balance'];
    $bonus = (float)$row['bonus_balance'];

    $remaining = $fee;

    // 1) Bonus cash: up to 10% of the entry fee.
    $bonusUse = min($bonus, $remaining * 0.10);
    $bonus -= $bonusUse;
    $remaining -= $bonusUse;

    // 2) Deposit cash.
    $depositUse = min($deposit, $remaining);
    $deposit -= $depositUse;
    $remaining -= $depositUse;

    // 3) Winnings cash.
    $winningsUse = min($winnings, $remaining);
    $winnings -= $winningsUse;
    $remaining -= $winningsUse;

    if ($remaining > 0.0001) {
        return false; // cannot cover the full fee
    }

    $total = $deposit + $winnings + $bonus;
    $pd->prepare('UPDATE users SET deposit_balance = ?, winnings_balance = ?, bonus_balance = ?, wallet_balance = ? WHERE id = ?')
        ->execute([$deposit, $winnings, $bonus, $total, $userId]);
    return true;
}

require_once __DIR__ . '/notify.php';
