<?php
/**
 * EXALOTE EXN — Bottom navigation / tab bar.
 */
if (!isset($active_tab)) {
    $active_tab = 'none';
}

$tabs = [
    ['home',   'index.php',          'fa-house',        'Home'],
    ['matches', 'my_tournaments.php', 'fa-trophy',      'My Matches'],
    ['wallet', 'wallet.php',          'fa-wallet',      'Wallet'],
    ['profile', 'profile.php',         'fa-user',        'Profile'],
];
?>
  </div><!-- /content wrapper -->

  <!-- Bottom navigation -->
  <nav class="fixed bottom-0 left-1/2 -translate-x-1/2 z-40 w-full max-w-md bg-[#101010]/95 backdrop-blur border-t border-red-900/40">
    <div class="grid grid-cols-4">
      <?php foreach ($tabs as $t): ?>
        <?php $isActive = ($active_tab === $t[0]); ?>
        <a href="<?= e($t[1]) ?>" class="flex flex-col items-center gap-1 py-3 transition-colors <?= $isActive ? 'text-red-500' : 'text-gray-600' ?>">
          <i class="fa-solid <?= e($t[2]) ?> <?= $isActive ? 'scale-110' : '' ?> transition-transform"></i>
          <span class="text-[10px] font-semibold"><?= e($t[3]) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </nav>

</main>
</body>
</html>
