<?php
/**
 * EXALOTE EXN — automatic daily tournament scheduling.
 * Generates matches idempotently for the current IST day (morning + evening).
 * Safe to call from cron or from a throttled page-load fallback.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/notify.php';

function ex_settings(): array
{
    static $row = null;
    if ($row === null) {
        $st = db()->query('SELECT * FROM settings WHERE id = 1');
        $row = $st->fetch() ?: [];
    }
    return $row;
}

function ex_time_to_minutes(string $t): int
{
    if ($t === '00:00') {
        return 1440;
    }
    [$h, $i] = array_map('intval', explode(':', $t));
    return $h * 60 + $i;
}

/**
 * Run the daily generator. Returns [createdCount, logLines].
 */
function auto_schedule_run(): array
{
    date_default_timezone_set('Asia/Kolkata');
    $log   = [];
    $created = 0;

    $cfg = ex_settings();
    $today = date('Y-m-d');

    if (!empty($cfg['last_generated_date']) && $cfg['last_generated_date'] === $today) {
        $log[] = 'already generated for ' . $today;
        return [$created, $log];
    }
    if (empty($cfg['automation_enabled'])) {
        $log[] = 'automation disabled';
        return [$created, $log];
    }

    $skip = array_filter(array_map('trim', explode(',', (string)($cfg['skip_dates'] ?? ''))));
    if (in_array($today, $skip, true)) {
        db()->prepare('UPDATE settings SET last_generated_date = ? WHERE id = 1')->execute([$today]);
        $log[] = $today . ' is in skip list';
        return [$created, $log];
    }

    $dur = max(1, (int)($cfg['duration_min'] ?? 20));
    $buf = max(0, (int)($cfg['buffer_min'] ?? 5));
    $cap = max(1, (int)($cfg['capacity_default'] ?? 10));

    $cats = db()->query('SELECT id, code FROM categories ORDER BY sort_order')->fetchAll();

    $sessions = [
        'morning' => ['start' => '10:00', 'end' => '14:00'],
        'evening' => ['start' => '20:00', 'end' => '00:00'],
    ];

    $ins = db()->prepare('INSERT INTO matches (category_id, match_date, session, start_time, player_capacity) VALUES (?, ?, ?, ?, ?)');
    $exs = db()->prepare('SELECT id FROM matches WHERE category_id = ? AND match_date = ? AND session = ?');

    foreach ($sessions as $sn => $sp) {
        $cursor = new DateTime($today . ' ' . $sp['start'], new DateTimeZone('Asia/Kolkata'));
        $endMin = ex_time_to_minutes($sp['end']);

        foreach ($cats as $c) {
            $startMin = ex_time_to_minutes($cursor->format('H:i'));
            if ($startMin + $dur > $endMin) {
                $log[] = "session $sn full (no room for {$c['code']})";
                break;
            }

            $exs->execute([$c['id'], $today, $sn]);
            if ($exs->fetch()) {
                // already scheduled for this date+session — skip + keep spacing
                $cursor->modify('+' . ($dur + $buf) . ' minutes');
                continue;
            }

            $ins->execute([$c['id'], $today, $sn, $cursor->format('H:i:s'), $cap]);
            $created++;
            $log[] = "created {$c['code']} $sn at " . $cursor->format('H:i');
            $cursor->modify('+' . ($dur + $buf) . ' minutes');
        }
    }

    // Archive stale matches from previous days (never started).
    db()->prepare("UPDATE matches SET status='Cancelled' WHERE match_date < ? AND status='Upcoming'")->execute([$today]);

    db()->prepare('UPDATE settings SET last_generated_date = ? WHERE id = 1')->execute([$today]);
    $log[] = "generated $created matches for $today";

    // Broadcast a "new matches published" notification to active users.
    if ($created > 0) {
        $users = db()->query('SELECT id FROM users ORDER BY id')->fetchAll();
        foreach ($users as $u) {
            notify((int)$u['id'], '🔥 Today\'s EXALOTE EXN schedule is live! ' . $created . ' matches published for today. Tap to register.', 'new_match', 'index.php', true);
        }
        $log[] = "broadcast 'new match' to " . count($users) . ' users';
    }

    return [$created, $log];
}

/**
 * Throttled fallback used on page load for environments without cron.
 * Runs at most once every 30 minutes.
 */
function auto_schedule_maybe(): void
{
    $marker = __DIR__ . '/../storage/autothrottle.txt';
    if (is_file($marker) && (time() - (int)filemtime($marker)) < 1800) {
        return;
    }
    @file_put_contents($marker, (string)time());
    auto_schedule_run();
}
