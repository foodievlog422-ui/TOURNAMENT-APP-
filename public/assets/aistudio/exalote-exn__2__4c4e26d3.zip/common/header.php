<?php
/**
 * EXALOTE EXN — Shared page header / top navigation.
 * Expects: $page_title (string), $active_tab (string: home|matches|wallet|profile|none)
 * Requires a logged-in user (redirects to login.php otherwise).
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/scheduler.php';
require_once __DIR__ . '/notify.php';

// Fallback auto-scheduler for environments without a real cron job.
auto_schedule_maybe();

// Fallback match reminders (throttled) for environments without cron.
if (!empty($_SESSION['nb_last_reminder']) && (time() - (int)$_SESSION['nb_last_reminder']) < 300) {
    // skip — recently ran
} else {
    $_SESSION['nb_last_reminder'] = time();
    send_match_reminders();
}

if (!is_logged_in()) {
    redirect('login.php');
}

$page_title = $page_title ?? 'EXALOTE EXN';
if (!isset($active_tab)) {
    $active_tab = 'none';
}
$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#0a0a0a">
<title><?= e($page_title) ?> · EXALOTE EXN</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<script>
  tailwind.config = {
    theme: {
      extend: {
        colors: { brand: { 400:'#ff3b4e', 500:'#e11d2e', 600:'#b9122a' } }
      }
    }
  };
</script>
<style>
  :root { color-scheme: dark; }
  body { -webkit-tap-highlight-color: transparent; }
  .no-select { -webkit-user-select: none; user-select: none; }
  @keyframes fadeUp { from { opacity:0; transform: translateY(8px); } to { opacity:1; transform: translateY(0); } }
  .fade-up { animation: fadeUp .45s ease both; }
  @keyframes pulseGlow { 0%,100% { box-shadow: 0 0 0 0 rgba(225,29,46,.45); } 50% { box-shadow: 0 0 0 6px rgba(225,29,46,0); } }
  .glow { animation: pulseGlow 2s infinite; }
  .scrollbar-hide::-webkit-scrollbar { display:none; }
  .scrollbar-hide { -ms-overflow-style:none; scrollbar-width:none; }
</style>
</head>
<body class="bg-[#0a0a0a] text-gray-100 no-select min-h-screen antialiased">

<script>
  // Disable right-click, text selection and pinch-zoom
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  document.addEventListener('selectstart', function (e) { e.preventDefault(); });
  document.addEventListener('touchmove', function (e) {
    if (e.touches.length > 1) e.preventDefault();
  }, { passive: false });
</script>

<main class="max-w-md mx-auto min-h-screen pb-28">

  <!-- Top app bar -->
  <header class="sticky top-0 z-40 bg-[#0a0a0a]/92 backdrop-blur border-b border-red-900/40">
    <div class="flex items-center justify-between px-4 py-3">
      <div class="flex items-center gap-2.5">
        <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-red-500 to-black ring-1 ring-red-500/50 flex items-center justify-center text-white text-lg shadow-lg shadow-red-500/30">
          <i class="fa-solid fa-bolt"></i>
        </div>
        <div>
          <div class="font-extrabold text-white leading-none tracking-wide">EXALOTE <span class="text-red-500">EXN</span></div>
          <div class="text-[10px] text-gray-500 -mt-0.5 tracking-widest uppercase">Tournament Center</div>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <?php $unread = unread_notifications($user['id']); ?>
        <a href="notifications.php" class="relative flex items-center justify-center w-9 h-9 rounded-full bg-[#151515] border border-red-900/40 text-gray-300 hover:text-white transition">
          <i class="fa-solid fa-bell"></i>
          <?php if ($unread > 0): ?>
            <span class="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-[#0a0a0a]"><?= $unread > 99 ? '99+' : $unread ?></span>
          <?php endif; ?>
        </a>
        <a href="index.php" class="flex items-center gap-2 bg-[#151515] border border-red-900/40 rounded-full pl-3 pr-4 py-1.5 shadow">
          <i class="fa-solid fa-star text-yellow-400"></i>
          <span class="text-white font-bold text-sm"><?= (int)$user['virtual_points'] ?> pts</span>
        </a>
      </div>
    </div>
  </header>

  <div class="px-4 pt-4">
