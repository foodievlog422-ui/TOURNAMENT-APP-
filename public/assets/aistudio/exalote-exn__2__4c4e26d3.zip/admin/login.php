<?php
/**
 * EXALOTE EXN — Admin login. Default: admin / admin123
 */
require_once __DIR__ . '/../common/config.php';

if (is_admin()) {
    redirect('dashboard.php');
}

$error = null;
$clientIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (login_rate_limit('admin|' . $username, $clientIp)) {
        $error = 'Too many failed attempts. Please try again in 15 minutes.';
    } else {
        $stmt = db()->prepare('SELECT * FROM admin WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $row = $stmt->fetch();

        if (!$row || !password_verify($password, $row['password'])) {
            login_rate_limit('admin|' . $username, $clientIp, true);
            $error = 'Invalid admin credentials.';
        } else {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int)$row['id'];
            redirect('dashboard.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#030712">
<title>Admin Login</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
  :root { color-scheme: dark; }
  body { -webkit-tap-highlight-color: transparent; }
  .no-select { -webkit-user-select: none; user-select: none; }
</style>
</head>
<body class="bg-gray-950 text-gray-100 no-select min-h-screen antialiased">
<script>
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  document.addEventListener('selectstart', function (e) { e.preventDefault(); });
</script>

<div class="min-h-screen flex items-center justify-center px-5">
  <div class="w-full max-w-sm">
    <div class="text-center mb-6">
      <div class="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-2xl shadow-xl shadow-purple-500/30 mb-3">
        <i class="fa-solid fa-shield-halved"></i>
      </div>
      <h1 class="text-xl font-extrabold">Admin Login</h1>
      <p class="text-gray-400 text-sm">EXALOTE EXN Control Panel</p>
    </div>

    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-2xl">
      <?php if ($error): ?>
        <div class="bg-red-500/10 border border-red-500/30 text-red-300 text-sm rounded-xl px-4 py-3 mb-4 flex items-center gap-2">
          <i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?>
        </div>
      <?php endif; ?>
      <form method="post" class="space-y-4">
        <?= csrf_field() ?>
        <div>
          <label class="text-xs text-gray-400 mb-1 block">Username</label>
          <input type="text" name="username" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500" placeholder="admin">
        </div>
        <div>
          <label class="text-xs text-gray-400 mb-1 block">Password</label>
          <input type="password" name="password" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500" placeholder="••••••••">
        </div>
        <button type="submit" class="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90 text-white font-bold rounded-xl py-3.5 transition shadow-lg shadow-purple-500/25">
          <i class="fa-solid fa-right-to-bracket mr-2"></i>Sign in
        </button>
      </form>
      <div class="mt-4 text-center text-xs text-gray-500">Exalote EXN Admin</div>
    </div>

    <p class="text-center text-gray-600 text-xs mt-6">
      <a href="../login.php" class="hover:text-gray-400"><i class="fa-solid fa-user mr-1"></i>User login</a>
    </p>
  </div>
</div>
</body>
</html>
