<?php
/**
 * EXALOTE EXN — Admin shared header.
 * Requires admin login.
 */
require_once __DIR__ . '/../common/config.php';

if (isset($_GET['logout'])) {
    unset($_SESSION['admin_id']);
    session_destroy();
    redirect('login.php');
}

if (!is_admin()) {
    redirect('login.php');
}

// Force a password change while the default password is still in use.
$__adminRow = db()->prepare('SELECT password FROM admin WHERE id = ?');
$__adminRow->execute([$_SESSION['admin_id']]);
$__adminHash = $__adminRow->fetchColumn();
$__defaultPw = !empty($__adminHash) && password_verify('admin123', $__adminHash);
$__curPage = basename($_SERVER['PHP_SELF'] ?? '');
if ($__defaultPw && $__curPage !== 'change_password.php') {
    redirect('change_password.php');
}

$page_title = $page_title ?? 'Admin Panel';
if (!isset($active_admin)) {
    $active_admin = '';
}
$adminUser = db()->prepare('SELECT username, password FROM admin WHERE id = ?');
$adminUser->execute([$_SESSION['admin_id']]);
$adminRow = $adminUser->fetch();
$adminName = $adminRow['username'] ?? 'admin';

// Warn if the default admin password is still in use.
$adminDefaultPw = !empty($adminRow['password']) && password_verify('admin123', $adminRow['password']);

$adminNav = [
    'dashboard'     => ['dashboard.php',       'fa-gauge-high',          'Dashboard'],
    'matches'       => ['matches.php',         'fa-bolt',                'Matches'],
    'requests'      => ['custom_requests.php', 'fa-screwdriver-wrench',  'Requests'],
    'results'       => ['results.php',          'fa-flag-checkered',      'Results'],
    'automation'    => ['automation.php',      'fa-robot',               'Auto'],
    'gateway'       => ['gateway.php',         'fa-circle-dollar-to-slot','Gateway'],
    'deposits'      => ['deposits.php',        'fa-arrow-trend-up',      'Deposits'],
    'withdrawals'   => ['withdrawals.php',     'fa-arrow-trend-down',    'Withdrawals'],
    'users'         => ['users.php',           'fa-users',               'Users'],
    'transactions'  => ['transactions.php',    'fa-clock-rotate-left',   'Transactions'],
    'settings'      => ['settings.php',        'fa-gear',                'Settings'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#0a0a0a">
<title><?= e($page_title) ?> · EXALOTE EXN Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<script>
  tailwind.config = {
    theme: { extend: { colors: { brand: { 400:'#ff3b4e', 500:'#e11d2e', 600:'#b9122a' } } } }
  };
</script>
<style>
  :root { color-scheme: dark; }
  body { -webkit-tap-highlight-color: transparent; }
  .no-select { -webkit-user-select: none; user-select: none; }
  @keyframes fadeUp { from { opacity:0; transform: translateY(8px); } to { opacity:1; transform: translateY(0); } }
  .fade-up { animation: fadeUp .4s ease both; }
  .scrollbar-hide::-webkit-scrollbar { display:none; }
  .scrollbar-hide { -ms-overflow-style:none; scrollbar-width:none; }
</style>
</head>
<body class="bg-[#0a0a0a] text-gray-100 no-select min-h-screen antialiased">
<script>
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  document.addEventListener('selectstart', function (e) { e.preventDefault(); });
</script>

<main class="max-w-md mx-auto min-h-screen pb-40">

  <header class="sticky top-0 z-40 bg-[#0a0a0a]/92 backdrop-blur border-b border-red-900/40">
    <div class="flex items-center justify-between px-4 py-3">
      <div class="flex items-center gap-2.5">
        <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-red-500 to-black ring-1 ring-red-500/50 flex items-center justify-center text-white text-lg shadow-lg shadow-red-500/30">
          <i class="fa-solid fa-shield-halved"></i>
        </div>
        <div>
          <div class="font-extrabold text-white leading-none tracking-wide">EXALOTE <span class="text-red-500">EXN</span></div>
          <div class="text-[10px] text-gray-500 -mt-0.5 tracking-widest uppercase">Admin Panel</div>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <span class="text-xs text-gray-400 hidden sm:block"><?= e($adminName) ?></span>
        <a href="?logout=1" class="bg-red-500/10 border border-red-500/30 text-red-300 rounded-lg px-3 py-1.5 text-xs font-semibold hover:bg-red-500/20 transition">
          <i class="fa-solid fa-right-from-bracket"></i>
        </a>
      </div>
    </div>
  </header>

  <div class="px-4 pt-4">

  <?php if (!empty($adminDefaultPw)): ?>
    <div class="mb-4 rounded-xl px-4 py-3 text-sm bg-red-500/10 border border-red-500/40 text-red-300 flex items-center gap-2">
      <i class="fa-solid fa-triangle-exclamation"></i>
      <span>You are using the default admin password. <a href="settings.php" class="underline font-semibold">Change it now</a>.</span>
    </div>
  <?php endif; ?>
