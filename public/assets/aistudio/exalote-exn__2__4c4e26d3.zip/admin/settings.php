<?php
/**
 * EXALOTE EXN — Admin settings: reward rules (virtual points).
 */
$page_title = 'Settings';
$active_admin = 'settings';
require_once __DIR__ . '/_header.php';

$flash = null;
if (isset($_SESSION['admin_flash'])) {
    $flash = $_SESSION['admin_flash'];
    unset($_SESSION['admin_flash']);
}

// ---- Reward rules (form helper) ----
$rewardParse = function (): array {
    $rank = [];
    foreach ([1, 2, 3] as $i) {
        $v = round((float)($_POST["reward_rank_$i"] ?? 0), 2);
        $rank[$i] = $v;
    }
    return ['rank' => $rank, 'participation' => round((float)($_POST['reward_participation'] ?? 0), 2), 'per_kill' => round((float)($_POST['reward_per_kill'] ?? 0), 2)];
};

// ---- Save settings ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    csrf_verify();
    $rp = $rewardParse();
    db()->prepare('UPDATE settings SET reward_rank_json = ?, reward_participation = ?, reward_per_kill = ? WHERE id = 1')
        ->execute([json_encode($rp['rank']), $rp['participation'], $rp['per_kill']]);
    $flash = ['type' => 'success', 'text' => 'Reward rules saved.'];
    $_SESSION['admin_flash'] = $flash;
    redirect('settings.php');
}

// ---- Toggle wallet on/off ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_wallet'])) {
    csrf_verify();
    $new = (int)($_POST['wallet_enabled'] ?? 0) ? 1 : 0;
    db()->prepare('UPDATE settings SET wallet_enabled = ? WHERE id = 1')->execute([$new]);
    $flash = ['type' => 'success', 'text' => $new ? 'Wallet enabled.' : 'Wallet disabled. Deposits/withdrawals hidden & blocked.'];
    $_SESSION['admin_flash'] = $flash;
    redirect('settings.php');
}

// ---- Save UPI / QR settings ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_upi'])) {
    csrf_verify();
    $upi = trim($_POST['upi_id'] ?? '');

    // Handle QR image upload (optional)
    $qrPath = '';
    if (!empty($_FILES['qr_image']['name']) && $_FILES['qr_image']['error'] === UPLOAD_ERR_OK) {
        $f = $_FILES['qr_image'];
        $mime = (function_exists('mime_content_type') ? mime_content_type($f['tmp_name']) : '') ?: ($f['type'] ?? '');
        $maxSize = 2 * 1024 * 1024; // 2MB
        if ($f['size'] > $maxSize) {
            $flash = ['type' => 'error', 'text' => 'QR image too large (max 2MB).'];
        } elseif (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp'], true)) {
            $flash = ['type' => 'error', 'text' => 'QR image must be PNG, JPG or WebP.'];
        } else {
            $ext = $mime === 'image/jpeg' ? 'jpg' : ($mime === 'image/webp' ? 'webp' : 'png');
            $name = 'upi_qr_' . time() . '.' . $ext;
            $dir = __DIR__ . '/uploads';
            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }
            if (move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
                $qrPath = 'uploads/' . $name;
            } else {
                $flash = ['type' => 'error', 'text' => 'Failed to save QR image.'];
            }
        }
    }

    // If a fresh QR was provided, update it; otherwise keep existing.
    $old = db()->query('SELECT qr_code FROM settings WHERE id = 1')->fetchColumn();
    $qr = $qrPath !== '' ? $qrPath : ($old ?: '');

    if ($flash === null) {
        db()->prepare('UPDATE settings SET upi_id = ?, qr_code = ? WHERE id = 1')->execute([$upi, $qr]);
        $flash = ['type' => 'success', 'text' => 'UPI payment settings saved.'];
        $_SESSION['admin_flash'] = $flash;
        redirect('settings.php');
    } else {
        $_SESSION['admin_flash'] = $flash;
        redirect('settings.php');
    }
}

// ---- Change admin password ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_admin_password'])) {
    csrf_verify();
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $a = db()->prepare('SELECT password FROM admin WHERE id = ?');
    $a->execute([$_SESSION['admin_id']]);
    $hash = $a->fetchColumn();

    if (!password_verify($current, (string)$hash)) {
        $flash = ['type' => 'error', 'text' => 'Current password is incorrect.'];
    } elseif (strlen($new) < 8) {
        $flash = ['type' => 'error', 'text' => 'New password must be at least 8 characters.'];
    } elseif ($new !== $confirm) {
        $flash = ['type' => 'error', 'text' => 'New passwords do not match.'];
    } else {
        db()->prepare('UPDATE admin SET password = ? WHERE id = ?')
            ->execute([password_hash($new, PASSWORD_BCRYPT), $_SESSION['admin_id']]);
        $flash = ['type' => 'success', 'text' => 'Admin password changed successfully.'];
    }
    $_SESSION['admin_flash'] = $flash;
    redirect('settings.php');
}

$rr = reward_rules();
$rrRank = $rr['rank'];
$sRow = db()->query('SELECT upi_id, qr_code, wallet_enabled FROM settings WHERE id = 1')->fetch();
$sUpi = $sRow['upi_id'] ?? '';
$sQr = $sRow['qr_code'] ?? '';
$walletOn = (bool)($sRow['wallet_enabled'] ?? 1);
?>
<?php if ($flash): ?>
  <div class="mb-4 rounded-xl px-4 py-3 text-sm flex items-center gap-2 <?= $flash['type'] === 'error' ? 'bg-red-500/10 border border-red-500/30 text-red-300' : 'bg-green-500/10 border border-green-500/30 text-green-300' ?>">
    <i class="fa-solid <?= $flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<div class="mb-5">
  <h2 class="text-xl font-extrabold">Reward Rules</h2>
  <p class="text-sm text-gray-400">Cash rewards auto-calculated when publishing match results.</p>
</div>

<!-- Wallet on/off toggle -->
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mb-5">
  <div class="flex items-center justify-between">
    <div class="flex items-center gap-3">
      <i class="fa-solid fa-wallet text-2xl <?= $walletOn ? 'text-emerald-400' : 'text-gray-600' ?>"></i>
      <div>
        <div class="font-bold text-white">Wallet Features</div>
        <div class="text-xs text-gray-400">Deposits, withdrawals &amp; cash rewards</div>
      </div>
    </div>
    <span class="text-xs font-bold px-3 py-1.5 rounded-full border <?= $walletOn ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300' : 'bg-gray-700/50 border-gray-700 text-gray-400' ?>">
      <?= $walletOn ? '● ENABLED' : '○ DISABLED' ?>
    </span>
  </div>
  <form method="post" class="mt-4">
    <?= csrf_field() ?>
    <input type="hidden" name="toggle_wallet" value="1">
    <input type="hidden" name="wallet_enabled" value="<?= $walletOn ? 0 : 1 ?>">
    <button class="w-full <?= $walletOn ? 'bg-gray-800 text-gray-300' : 'bg-emerald-600 hover:bg-emerald-500 text-white' ?> text-sm font-bold py-3 rounded-xl transition">
      <?= $walletOn ? '<i class="fa-solid fa-pause mr-2"></i>Disable Wallet' : '<i class="fa-solid fa-play mr-2"></i>Enable Wallet' ?>
    </button>
  </form>
</div>

<!-- UPI / QR settings -->
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mb-5">
  <h3 class="font-bold text-white mb-4 flex items-center gap-2">
    <i class="fa-solid fa-circle-dollar-to-slot text-emerald-400"></i>UPI Payment Settings
  </h3>
  <form method="post" enctype="multipart/form-data" class="space-y-4">
    <?= csrf_field() ?>
    <div>
      <label class="text-xs text-gray-400 mb-1 block">Admin UPI ID</label>
      <input type="text" name="upi_id" value="<?= e($sUpi) ?>" placeholder="you@upi"
        class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-emerald-500">
    </div>
    <div>
      <label class="text-xs text-gray-400 mb-1 block">UPI QR Code (optional image)</label>
      <input type="file" name="qr_image" accept="image/png,image/jpeg,image/webp"
        class="w-full text-sm text-gray-400 file:mr-3 file:rounded-lg file:border-0 file:bg-gray-700 file:px-4 file:py-2 file:text-gray-200">
      <?php if ($sQr): ?>
        <div class="mt-2 flex items-center gap-3">
          <img src="../<?= e($sQr) ?>" alt="UPI QR" class="w-20 h-20 rounded-xl bg-white p-1 object-contain">
          <span class="text-[11px] text-gray-500">Current QR. Upload a new one to replace it.</span>
        </div>
      <?php endif; ?>
    </div>
    <button type="submit" name="update_upi" value="1"
      class="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl py-3 text-sm transition">
      <i class="fa-solid fa-floppy-disk mr-2"></i>Save UPI Settings
    </button>
  </form>
</div>

<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow">
  <form method="post" class="space-y-4">
    <?= csrf_field() ?>
    <div class="border-b border-gray-800 pb-4">
      <label class="text-xs text-gray-400 mb-2 block">Rank bonuses (points)</label>
      <div class="grid grid-cols-3 gap-2">
        <div>
          <label class="text-[10px] text-gray-500 uppercase">1st</label>
          <input type="number" name="reward_rank_1" min="0" step="0.01" value="<?= (float)($rrRank[1] ?? 0) ?>"
            class="mt-1 w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2.5 text-sm text-yellow-300 outline-none focus:border-yellow-500">
        </div>
        <div>
          <label class="text-[10px] text-gray-500 uppercase">2nd</label>
          <input type="number" name="reward_rank_2" min="0" step="0.01" value="<?= (float)($rrRank[2] ?? 0) ?>"
            class="mt-1 w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2.5 text-sm text-yellow-300 outline-none focus:border-yellow-500">
        </div>
        <div>
          <label class="text-[10px] text-gray-500 uppercase">3rd</label>
          <input type="number" name="reward_rank_3" min="0" step="0.01" value="<?= (float)($rrRank[3] ?? 0) ?>"
            class="mt-1 w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2.5 text-sm text-yellow-300 outline-none focus:border-yellow-500">
        </div>
      </div>
    </div>
    <div class="grid grid-cols-2 gap-2">
      <div>
        <label class="text-[10px] text-gray-500 uppercase">Participation</label>
        <input type="number" name="reward_participation" min="0" step="0.01" value="<?= (float)$rr['participation'] ?>"
          class="mt-1 w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-yellow-500">
      </div>
      <div>
        <label class="text-[10px] text-gray-500 uppercase">Per kill</label>
        <input type="number" name="reward_per_kill" min="0" step="0.01" value="<?= (float)$rr['per_kill'] ?>"
          class="mt-1 w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-yellow-500">
      </div>
    </div>
    <p class="text-[10px] text-gray-500">Defaults auto-fill in the Results screen; you can override per player.</p>

    <button type="submit" name="update_settings" value="1"
      class="w-full bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl py-3 text-sm transition">
      <i class="fa-solid fa-floppy-disk mr-2"></i>Save Settings
    </button>
  </form>
</div>

<!-- Change admin password -->
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mt-4">
  <h3 class="font-bold mb-4 flex items-center gap-2">
    <i class="fa-solid fa-lock text-amber-400"></i>Change Admin Password
  </h3>
  <form method="post" class="space-y-3">
    <?= csrf_field() ?>
    <div>
      <label class="text-xs text-gray-400 mb-1 block">Current Password</label>
      <input type="password" name="current_password" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs text-gray-400 mb-1 block">New Password</label>
        <input type="password" name="new_password" required minlength="8" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Confirm</label>
        <input type="password" name="confirm_password" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
      </div>
    </div>
    <button type="submit" name="change_admin_password" value="1"
      class="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl py-3 text-sm transition">
      <i class="fa-solid fa-rotate mr-2"></i>Update Password
    </button>
  </form>
</div>
<?php require_once __DIR__ . '/_footer.php'; ?>
