<?php
/**
 * EXALOTE EXN — Admin dashboard.
 */
$page_title = 'Dashboard';
$active_admin = 'dashboard';
require_once __DIR__ . '/_header.php';

function scount(string $sql): int
{
    $s = db()->query($sql);
    return (int)$s->fetchColumn();
}

$today = date('Y-m-d');

$stats = [
    'players'   => scount('SELECT COUNT(*) FROM users'),
    'upcoming'  => scount("SELECT COUNT(*) FROM matches WHERE status='Upcoming'"),
    'live'      => scount("SELECT COUNT(*) FROM matches WHERE status='Live'"),
    'completed' => scount("SELECT COUNT(*) FROM matches WHERE status='Completed'"),
    'pendingReq'=> scount("SELECT COUNT(*) FROM custom_requests WHERE status='Pending'"),
    'today'     => scount("SELECT COUNT(*) FROM matches WHERE match_date = '" . $today . "'"),
];

$todayBy = db()->prepare("SELECT session, COUNT(*) AS n FROM matches WHERE match_date = ? GROUP BY session");
$todayBy->execute([$today]);
$todayBy = $todayBy->fetchAll();

$cards = [
    ['fa-users',           'Players',        $stats['players'],   'from-red-600 to-rose-700'],
    ['fa-calendar-day',    "Today's Matches", $stats['today'],    'from-[#7a0b1c] to-black'],
    ['fa-bolt',            'Live Now',       $stats['live'],      'from-red-600 to-orange-600'],
    ['fa-flag-checkered',  'Completed',       $stats['completed'], 'from-emerald-600 to-teal-600'],
    ['fa-hourglass-half',  'Upcoming',        $stats['upcoming'],  'from-yellow-600 to-amber-700'],
    ['fa-screwdriver-wrench','Custom Requests',$stats['pendingReq'],'from-gray-700 to-gray-900'],
];
?>
<div class="mb-5 fade-up">
  <h2 class="text-xl font-extrabold text-white">Dashboard</h2>
  <p class="text-sm text-gray-500">EXALOTE EXN tournament control center</p>
</div>

<div class="grid grid-cols-2 gap-3 mb-5">
  <?php foreach ($cards as $c): ?>
    <div class="rounded-2xl p-4 bg-gradient-to-br <?= $c[3] ?> text-white shadow-lg">
      <div class="flex items-center justify-between">
        <span class="text-xs opacity-90 uppercase tracking-wide"><?= e($c[1]) ?></span>
        <i class="fa-solid <?= e($c[0]) ?> opacity-70"></i>
      </div>
      <div class="text-3xl font-extrabold mt-2"><?= (int)$c[2] ?></div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Today's schedule -->
<?php if ($stats['today'] > 0): ?>
  <div class="bg-[#121212] border border-gray-800 rounded-2xl p-4 mb-5">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-bold text-white">Today's Schedule</h3>
      <span class="text-[11px] text-gray-500"><?= e(date('d M Y')) ?> IST</span>
    </div>
    <?php foreach ($todayBy as $s): ?>
      <div class="flex items-center justify-between py-2 border-b border-gray-800/60 last:border-0">
        <span class="flex items-center gap-2 text-sm text-gray-300">
          <i class="fa-solid <?= $s['session'] === 'morning' ? 'fa-sun text-yellow-400' : 'fa-moon text-indigo-400' ?>"></i>
          <?= ucfirst(e($s['session'])) ?>
        </span>
        <span class="text-sm font-bold text-white"><?= (int)$s['n'] ?> matches</span>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<!-- Quick actions -->
<div class="bg-[#121212] border border-gray-800 rounded-2xl p-5 shadow">
  <h3 class="font-bold text-white mb-4">Quick Actions</h3>
  <div class="space-y-2">
    <a href="matches.php" class="flex items-center justify-between bg-[#1a1a1a] hover:bg-[#202020] border border-gray-800 rounded-xl px-4 py-3 text-sm transition">
      <span class="flex items-center gap-3"><i class="fa-solid fa-bolt text-red-400"></i>Manage Matches / Players</span>
      <span class="bg-red-500/20 text-red-300 text-xs font-bold rounded-full px-2 py-0.5"><?= $stats['live'] ?> live</span>
    </a>
    <a href="custom_requests.php" class="flex items-center justify-between bg-[#1a1a1a] hover:bg-[#202020] border border-gray-800 rounded-xl px-4 py-3 text-sm transition">
      <span class="flex items-center gap-3"><i class="fa-solid fa-screwdriver-wrench text-yellow-400"></i>Custom Match Requests</span>
      <span class="bg-yellow-500/20 text-yellow-300 text-xs font-bold rounded-full px-2 py-0.5"><?= $stats['pendingReq'] ?></span>
    </a>
    <a href="results.php" class="flex items-center justify-between bg-[#1a1a1a] hover:bg-[#202020] border border-gray-800 rounded-xl px-4 py-3 text-sm transition">
      <span class="flex items-center gap-3"><i class="fa-solid fa-flag-checkered text-emerald-400"></i>Advanced Results</span>
      <i class="fa-solid fa-chevron-right text-gray-600"></i>
    </a>
    <a href="automation.php" class="flex items-center justify-between bg-[#1a1a1a] hover:bg-[#202020] border border-gray-800 rounded-xl px-4 py-3 text-sm transition">
      <span class="flex items-center gap-3"><i class="fa-solid fa-robot text-green-400"></i>Daily Automation</span>
      <i class="fa-solid fa-chevron-right text-gray-600"></i>
    </a>
    <a href="users.php" class="flex items-center justify-between bg-[#1a1a1a] hover:bg-[#202020] border border-gray-800 rounded-xl px-4 py-3 text-sm transition">
      <span class="flex items-center gap-3"><i class="fa-solid fa-users text-indigo-400"></i>Player Management</span>
      <i class="fa-solid fa-chevron-right text-gray-600"></i>
    </a>
    <a href="gateway.php" class="flex items-center justify-between bg-[#1a1a1a] hover:bg-[#202020] border border-gray-800 rounded-xl px-4 py-3 text-sm transition">
      <span class="flex items-center gap-3"><i class="fa-solid fa-circle-dollar-to-slot text-emerald-400"></i>Payment Gateway</span>
      <i class="fa-solid fa-chevron-right text-gray-600"></i>
    </a>
    <a href="deposits.php" class="flex items-center justify-between bg-[#1a1a1a] hover:bg-[#202020] border border-gray-800 rounded-xl px-4 py-3 text-sm transition">
      <span class="flex items-center gap-3"><i class="fa-solid fa-arrow-trend-up text-green-400"></i>Deposits</span>
      <i class="fa-solid fa-chevron-right text-gray-600"></i>
    </a>
    <a href="withdrawals.php" class="flex items-center justify-between bg-[#1a1a1a] hover:bg-[#202020] border border-gray-800 rounded-xl px-4 py-3 text-sm transition">
      <span class="flex items-center gap-3"><i class="fa-solid fa-arrow-trend-down text-amber-400"></i>Withdrawals</span>
      <i class="fa-solid fa-chevron-right text-gray-600"></i>
    </a>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
