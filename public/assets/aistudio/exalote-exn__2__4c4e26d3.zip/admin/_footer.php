<?php
/**
 * EXALOTE EXN — Admin shared bottom navigation.
 */
if (!isset($active_admin)) {
    $active_admin = '';
}
$adminNav = [
    'dashboard'     => ['dashboard.php',       'fa-gauge-high',          'Dashboard'],
    'matches'       => ['matches.php',         'fa-bolt',                'Matches'],
    'requests'      => ['custom_requests.php', 'fa-screwdriver-wrench',  'Requests'],
    'automation'    => ['automation.php',      'fa-robot',               'Auto'],
    'users'         => ['users.php',           'fa-users',               'Users'],
    'deposits'      => ['deposits.php',        'fa-circle-plus',         'Deposits'],
    'withdrawals'   => ['withdrawals.php',     'fa-hand-holding-usd',    'Withdrawals'],
    'transactions'  => ['transactions.php',    'fa-clock-rotate-left',   'Transactions'],
    'settings'      => ['settings.php',        'fa-gear',                'Settings'],
];
?>
  </div><!-- /content -->

  <nav class="fixed bottom-0 left-1/2 -translate-x-1/2 z-40 w-full max-w-md bg-[#101010]/95 backdrop-blur border-t border-red-900/40">
    <div class="grid grid-cols-5 gap-y-1 px-2 pt-2 pb-2">
      <?php foreach ($adminNav as $key => $item): ?>
        <?php $isActive = ($active_admin === $key); ?>
        <a href="<?= e($item[0]) ?>" class="flex flex-col items-center gap-1 py-1.5 rounded-xl <?= $isActive ? 'text-red-500 bg-red-500/10' : 'text-gray-600' ?>">
          <i class="fa-solid <?= e($item[1]) ?> <?= $isActive ? 'scale-110' : '' ?>"></i>
          <span class="text-[9px] font-semibold"><?= e($item[2]) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </nav>

</main>
</body>
</html>
