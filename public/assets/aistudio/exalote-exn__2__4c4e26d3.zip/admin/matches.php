<?php
/**
 * EXALOTE EXN — Admin: match management (single-host scheduling).
 */
$page_title = 'Matches';
$active_admin = 'matches';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../common/scheduler.php';
require_once __DIR__ . '/../common/notify.php';

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

define('REG_PARTICIPATION', 10);
define('REG_WINNER_BONUS', 40);
$dur = max(1, (int)(ex_settings()['duration_min'] ?? 20));
$buf = max(0, (int)(ex_settings()['buffer_min'] ?? 5));

function session_of_time(string $t): string
{
    $m = ex_time_to_minutes(substr($t, 0, 5));
    return ($m >= 600 && $m < 840) ? 'morning' : 'evening';
}

function award_match_points(int $matchId, ?int $winnerId): void
{
    $st = db()->prepare("SELECT user_id FROM registrations WHERE match_id = ? AND status = 'Approved'");
    $st->execute([$matchId]);
    $add = db()->prepare('UPDATE users SET virtual_points = virtual_points + ? WHERE id = ?');
    foreach ($st->fetchAll() as $row) {
        $pts = $row['user_id'] === $winnerId ? REG_WINNER_BONUS : REG_PARTICIPATION;
        $add->execute([$pts, $row['user_id']]);
    }
}

/**
 * Refund the entry fee to a user if they were actually charged (fee_status='paid').
 * Runs inside the caller's transaction. Never refunds twice (guarded by
 * the fee_status='paid' check + update).
 */
function refund_entry_fee(int $matchId, int $userId, string $reason): void
{
    $fee = db()->prepare('SELECT entry_fee FROM matches WHERE id = ?');
    $fee->execute([$matchId]);
    $amount = (float)$fee->fetchColumn();

    $upd = db()->prepare(
        "UPDATE registrations SET fee_status = 'refunded'
         WHERE match_id = ? AND user_id = ? AND fee_status = 'paid'"
    );
    $upd->execute([$matchId, $userId]);

    if ($amount > 0 && $upd->rowCount() === 1) {
        // Fees were paid from the mixed buckets; refund back to DEPOSIT bucket.
        db()->prepare('UPDATE users SET deposit_balance = deposit_balance + ?, wallet_balance = wallet_balance + ? WHERE id = ?')
            ->execute([$amount, $amount, $userId]);
        db()->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', ?)")
            ->execute([$userId, $amount, $reason]);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'save_match') {
        $id         = (int)($_POST['id'] ?? 0);
        $catId      = (int)($_POST['category_id'] ?? 0);
        $date       = trim($_POST['match_date'] ?? '');
        $time       = trim($_POST['start_time'] ?? '');
        $capacity   = max(1, (int)($_POST['player_capacity'] ?? 10));
        $fee        = round((float)($_POST['entry_fee'] ?? 0), 2);
        $prize      = round((float)($_POST['prize_pool'] ?? 0), 2);
        $session    = session_of_time($time);
        $roomId     = trim($_POST['room_id'] ?? '');
        $roomPass   = trim($_POST['room_password'] ?? '');
        $mapName    = trim($_POST['map_name'] ?? 'Bermuda');
        $rules      = trim($_POST['match_rules'] ?? '');

        $startMin = ex_time_to_minutes(substr($time, 0, 5));
        $endMin = $session === 'morning' ? 840 : 1440;
        if ($date === '' || $catId === 0 || $time === '') {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Fill all required fields.'];
            redirect('matches.php');
        }
        if ($startMin + $dur > $endMin) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => "Match must end within its session window (morning 10:00–14:00, evening 20:00–00:00)."];
            redirect('matches.php');
        }

        // Overlap check (single host, buffer enforced)
        $oc = db()->prepare("SELECT start_time FROM matches WHERE match_date = ? AND session = ? AND status != 'Cancelled' AND id != ?");
        $oc->execute([$date, $session, $id]);
        while ($row = $oc->fetch()) {
            $other = ex_time_to_minutes(substr($row['start_time'], 0, 5));
            if (abs($other - $startMin) < ($dur + $buf)) {
                $_SESSION['flash'] = ['type' => 'error', 'text' => 'Overlap with another match in this session. Host needs a ' . $buf . ' min buffer.'];
                redirect('matches.php');
            }
        }

        if ($id) {
            db()->prepare('UPDATE matches SET category_id = ?, match_date = ?, session = ?, start_time = ?, player_capacity = ?, entry_fee = ?, prize_pool = ?, room_id = ?, room_password = ?, map_name = ?, match_rules = ? WHERE id = ?')
                ->execute([$catId, $date, $session, $time, $capacity, $fee, $prize, $roomId !== '' ? $roomId : null, $roomPass !== '' ? $roomPass : null, $mapName, $rules !== '' ? $rules : null, $id]);
            $_SESSION['flash'] = ['type' => 'success', 'text' => 'Match updated.'];
        } else {
            db()->prepare('INSERT INTO matches (category_id, match_date, session, start_time, player_capacity, entry_fee, prize_pool, room_id, room_password, map_name, match_rules) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$catId, $date, $session, $time, $capacity, $fee, $prize, $roomId !== '' ? $roomId : null, $roomPass !== '' ? $roomPass : null, $mapName, $rules !== '' ? $rules : null]);
            $_SESSION['flash'] = ['type' => 'success', 'text' => 'Match created.'];
        }
        redirect('matches.php');
    }

    if ($action === 'approve_reg' || $action === 'reject_reg') {
        $regId = (int)($_POST['reg_id'] ?? 0);
        $status = $action === 'approve_reg' ? 'Approved' : 'Rejected';
        $reg = db()->prepare('SELECT r.id, r.match_id, r.user_id, r.fee_status, m.*, c.name AS cat_name FROM registrations r JOIN matches m ON m.id = r.match_id JOIN categories c ON c.id = m.category_id WHERE r.id = ?');
        $reg->execute([$regId]);
        $row = $reg->fetch();
        if (!$row) {
            redirect('matches.php');
        }

        try {
            db()->beginTransaction();
            db()->prepare('UPDATE registrations SET status = ? WHERE id = ?')->execute([$status, $regId]);

            // Refund the entry fee (once) only if the registration was rejected
            // and the player had actually been charged.
            if ($status === 'Rejected') {
                refund_entry_fee($row['match_id'], $row['user_id'], 'Entry fee refunded — registration rejected (match #' . $row['match_id'] . ')');
            }

            if ($status === 'Approved') {
                // Capacity enforcement at approve-time (count Pending+Approved).
                $cap = (int)$row['player_capacity'];
                $cnt = db()->prepare("SELECT COUNT(*) FROM registrations WHERE match_id = ? AND status IN ('Pending','Approved')");
                $cnt->execute([$row['match_id']]);
                if ((int)$cnt->fetchColumn() > $cap) {
                    db()->rollBack();
                    $_SESSION['flash'] = ['type' => 'error', 'text' => 'Match is full — cannot approve more players.'];
                    redirect('matches.php');
                }
                notify($row['user_id'], '✅ Your registration for ' . $row['cat_name'] . ' on ' . $row['match_date'] . ' has been approved!', 'approve', 'my_tournaments.php');
            } else {
                notify($row['user_id'], 'Your registration for ' . $row['cat_name'] . ' on ' . $row['match_date'] . ' was rejected.', 'reject', 'my_tournaments.php');
            }

            // Auto-close registration when slots are full (same transaction)
            $cap = (int)$row['player_capacity'];
            $cnt = db()->prepare("SELECT COUNT(*) FROM registrations WHERE match_id = ? AND status = 'Approved'");
            $cnt->execute([$row['match_id']]);
            if ((int)$cnt->fetchColumn() >= $cap) {
                db()->prepare("UPDATE matches SET status = 'Registration Closed' WHERE id = ? AND status = 'Upcoming'")->execute([$row['match_id']]);
            }

            db()->commit();
            $_SESSION['flash'] = ['type' => 'info', 'text' => 'Registration ' . strtolower($status) . '.'];
        } catch (Throwable $e) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Could not process registration.'];
        }
        redirect('matches.php');
    }

    if ($action === 'start') {
        $id = (int)($_POST['id'] ?? 0);
        // only one host-run match at a time
        if (db()->query("SELECT COUNT(*) FROM matches WHERE status='Live'")->fetchColumn() > 0) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Another match is already LIVE. Finish it first.'];
            redirect('matches.php');
        }
        $sm = db()->prepare('SELECT m.*, c.name AS cat_name FROM matches m JOIN categories c ON c.id = m.category_id WHERE m.id = ?');
        $sm->execute([$id]);
        $srow = $sm->fetch();
        db()->prepare("UPDATE matches SET status='Live' WHERE id=? AND status IN ('Upcoming','Registration Closed')")->execute([$id]);
        if ($srow) {
            // notify approved players: match started + room available (host note)
            $pl = db()->prepare("SELECT user_id FROM registrations WHERE match_id = ? AND status = 'Approved'");
            $pl->execute([$id]);
            while ($p = $pl->fetch()) {
                $roomMsg = '🏟️ ' . $srow['cat_name'] . ' has started! ' . (trim((string)$srow['host_note']) !== '' ? 'Room: ' . $srow['host_note'] : 'Tap for room details.') . ' Good luck!';
                notify($p['user_id'], $roomMsg, 'start', 'my_tournaments.php');
            }
            // toast for the admin (room published to players)
            if (trim((string)$srow['host_note']) !== '') {
                $_SESSION['flash'] = ['type' => 'success', 'text' => 'Match started. Room details sent to players.'];
            } else {
                $_SESSION['flash'] = ['type' => 'success', 'text' => 'Match started.'];
            }
        }
        redirect('matches.php');
    }

    if ($action === 'publish_room') {
        $id = (int)($_POST['id'] ?? 0);
        $pm = db()->prepare('SELECT m.*, c.name AS cat_name FROM matches m JOIN categories c ON c.id = m.category_id WHERE m.id = ?');
        $pm->execute([$id]);
        $prow = $pm->fetch();
        if ($prow) {
            db()->prepare("UPDATE matches SET room_published = 1 WHERE id = ?")->execute([$id]);
            // Notify every approved (joined) player with the room credentials.
            $pl = db()->prepare("SELECT user_id FROM registrations WHERE match_id = ? AND status = 'Approved'");
            $pl->execute([$id]);
            $roomInfo = 'Room: ' . ($prow['room_id'] ?? '—') . ' | Pass: ' . ($prow['room_password'] ?? '—');
            while ($p = $pl->fetch()) {
                notify($p['user_id'], '🏟️ ' . $prow['cat_name'] . ' custom room is now available! ' . $roomInfo, 'room', 'index.php');
            }
            $_SESSION['flash'] = ['type' => 'success', 'text' => 'Room published & notified to joined players.'];
        }
        redirect('matches.php');
    }

    if ($action === 'cancel') {
        $id = (int)($_POST['id'] ?? 0);

        try {
            db()->beginTransaction();

            $cm = db()->prepare('SELECT m.*, c.name AS cat_name FROM matches m JOIN categories c ON c.id = m.category_id WHERE m.id = ? FOR UPDATE');
            $cm->execute([$id]);
            $crow = $cm->fetch();
            if ($crow) {
                // Only cancel matches that are not already completed.
                if ($crow['status'] === 'Completed') {
                    if (db()->inTransaction()) { db()->rollBack(); }
                    $_SESSION['flash'] = ['type' => 'error', 'text' => 'Completed matches cannot be cancelled.'];
                    redirect('matches.php');
                }
                db()->prepare("UPDATE matches SET status='Cancelled' WHERE id=?")->execute([$id]);

                $pl = db()->prepare("SELECT user_id, fee_status FROM registrations WHERE match_id = ?");
                $pl->execute([$id]);
                while ($p = $pl->fetch()) {
                    // Refund the entry fee (once) to every player who was charged.
                    refund_entry_fee($id, $p['user_id'], 'Entry fee refunded — match cancelled (match #' . $id . ')');
                    notify($p['user_id'], '⚠️ ' . $crow['cat_name'] . ' on ' . $crow['match_date'] . ' has been cancelled.', 'cancel', 'my_tournaments.php');
                }
            }
            db()->commit();
            $_SESSION['flash'] = ['type' => 'info', 'text' => 'Match cancelled. Players notified (entry fees refunded).'];
        } catch (Throwable $e) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Could not cancel match.'];
        }
        redirect('matches.php');
    }

    if ($action === 'complete') {
        $id = (int)($_POST['id'] ?? 0);
        $winner = $_POST['winner_user_id'] !== '' ? (int)($_POST['winner_user_id']) : null;
        $m = db()->prepare('SELECT * FROM matches WHERE id=?');
        $m->execute([$id]);
        $match = $m->fetch();
        if (!$match) {
            redirect('matches.php');
        }
        award_match_points($id, $winner);
        db()->prepare("UPDATE matches SET status='Completed', winner_user_id=?, published=1 WHERE id=?")->execute([$winner, $id]);
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Match completed & results published. Points awarded.'];
        redirect('matches.php');
    }
}

// --- Data ---
$categories = db()->query('SELECT * FROM categories ORDER BY sort_order')->fetchAll();

$matches = db()->query("
    SELECT m.*, c.name AS cat_name, c.format AS cat_format, wu.username AS winner_name,
           (SELECT COUNT(*) FROM registrations r WHERE r.match_id = m.id AND r.status = 'Approved') AS approved_count,
           (SELECT COUNT(*) FROM registrations r WHERE r.match_id = m.id) AS total_regs
    FROM matches m
    JOIN categories c ON c.id = m.category_id
    LEFT JOIN users wu ON wu.id = m.winner_user_id
    ORDER BY m.match_date DESC, FIELD(m.session,'morning','evening'), m.start_time DESC
")->fetchAll();

$edit = null;
if (isset($_GET['edit'])) {
    $em = db()->prepare('SELECT * FROM matches WHERE id = ?');
    $em->execute([(int)$_GET['edit']]);
    $edit = $em->fetch() ?: null;
}
?>
<div class="mb-5 fade-up">
  <h2 class="text-xl font-extrabold text-white">Match Management</h2>
  <p class="text-sm text-gray-500">Single host · no overlaps · <?= $dur ?> min match + <?= $buf ?> min buffer</p>
</div>

<?php if ($flash): ?>
  <div class="mb-4 px-4 py-3 rounded-2xl border text-sm font-medium
      <?= $flash['type'] === 'success' ? 'bg-green-500/10 border-green-500/30 text-green-300'
         : ($flash['type'] === 'error' ? 'bg-red-500/10 border-red-500/30 text-red-300' : 'bg-gray-800 border-gray-700 text-gray-200') ?>">
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<!-- Create / override form -->
<div class="bg-[#121212] border border-gray-800 rounded-2xl p-4 mb-6">
  <h3 class="font-bold text-white mb-3"><?= $edit ? 'Override Match #' . (int)$edit['id'] : 'Create Match' ?></h3>
  <form method="post" action="matches.php" class="space-y-3">
    <input type="hidden" name="action" value="save_match">
    <input type="hidden" name="id" value="<?= $edit ? (int)$edit['id'] : 0 ?>">
    <?= csrf_field() ?>
    <div>
      <label class="text-[11px] text-gray-500 font-semibold uppercase">Category</label>
      <select name="category_id" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
        <?php foreach ($categories as $c): ?>
          <option value="<?= (int)$c['id'] ?>" <?= $edit && (int)$edit['category_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?> (<?= e($c['format']) ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Date</label>
        <input type="date" name="match_date" required value="<?= e($edit['match_date'] ?? date('Y-m-d')) ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Start (IST)</label>
        <input type="time" name="start_time" required value="<?= e($edit['start_time'] ?? '20:00') ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
    </div>
    <div>
      <label class="text-[11px] text-gray-500 font-semibold uppercase">Player capacity</label>
      <input type="number" name="player_capacity" min="1" required value="<?= (int)($edit['player_capacity'] ?? ex_settings()['capacity_default'] ?? 10) ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Entry Fee (₹)</label>
        <input type="number" name="entry_fee" min="0" step="0.01" value="<?= number_format((float)($edit['entry_fee'] ?? 0), 2, '.', '') ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Prize Pool (₹)</label>
        <input type="number" name="prize_pool" min="0" step="0.01" value="<?= number_format((float)($edit['prize_pool'] ?? 0), 2, '.', '') ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Map</label>
        <select name="map_name" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
          <?php foreach (['Bermuda', 'Purgatory', 'Kalahari', 'NeXTerra', 'Alpine'] as $map): ?>
            <option value="<?= e($map) ?>" <?= ($edit['map_name'] ?? 'Bermuda') === $map ? 'selected' : '' ?>><?= e($map) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Room ID</label>
        <input type="text" name="room_id" maxlength="50" value="<?= e($edit['room_id'] ?? '') ?>" placeholder="e.g. 123456789" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Room Password</label>
        <input type="text" name="room_password" maxlength="50" value="<?= e($edit['room_password'] ?? '') ?>" placeholder="4-digit room pass" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Rules</label>
        <input type="text" name="match_rules" maxlength="200" value="<?= e($edit['match_rules'] ?? '') ?>" placeholder="No Emulator, Character Skill Yes" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
    </div>
    <button type="submit" class="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white text-sm font-extrabold py-3 rounded-xl transition-all">
      <i class="fa-solid <?= $edit ? 'fa-pen-to-square' : 'fa-plus' ?> mr-1.5"></i><?= $edit ? 'Save Override' : 'Create Match' ?>
    </button>
    <?php if ($edit): ?>
      <a href="matches.php" class="block text-center text-xs text-gray-500 hover:text-gray-300">Cancel edit</a>
    <?php endif; ?>
  </form>
</div>

<!-- Matches list -->
<?php if (!$matches): ?>
  <div class="text-center py-10 text-gray-500">
    <i class="fa-solid fa-calendar-xmark text-3xl mb-2 text-gray-700"></i>
    <p class="text-sm">No matches yet. Create one above or check Automation.</p>
  </div>
<?php endif; ?>

<?php foreach ($matches as $m): ?>
  <?php
    $statusColors = match ($m['status']) {
        'Upcoming' => ['text-yellow-300', 'bg-yellow-500/10', 'border-yellow-500/40', 'Upcoming'],
        'Registration Closed' => ['text-orange-300', 'bg-orange-500/10', 'border-orange-500/40', 'Reg Closed'],
        'Live'     => ['text-red-400', 'bg-red-500/10', 'border-red-500/40', 'LIVE'],
        'Completed' => ['text-green-300', 'bg-green-500/10', 'border-green-500/40', 'Completed'],
        'Cancelled' => ['text-gray-400', 'bg-gray-700/50', 'border-gray-700', 'Cancelled'],
    };
    $regs = db()->prepare('SELECT r.id AS reg_id, r.status AS reg_status, r.ff_uid, r.ff_ign, r.slot_number, r.team_members, u.username, u.id AS user_id FROM registrations r JOIN users u ON u.id = r.user_id WHERE r.match_id = ? ORDER BY r.created_at');
    $regs->execute([$m['id']]);
    $regList = $regs->fetchAll();
    $approvedUsers = array_values(array_filter($regList, fn($r) => $r['reg_status'] === 'Approved'));
  ?>
  <div class="fade-up mb-4 bg-[#121212] border border-gray-800 rounded-2xl p-4">
    <div class="flex items-start justify-between gap-2">
      <div>
        <div class="font-bold text-white"><?= e($m['cat_name']) ?></div>
        <div class="text-[11px] text-gray-500 mt-0.5">
          <?= e($m['match_date']) ?> · <?= e(date('h:i A', strtotime($m['start_time']))) ?> IST · <?= e($m['session']) ?>
        </div>
      </div>
      <span class="shrink-0 text-[10px] font-bold px-2 py-1 rounded-full border <?= $statusColors[1] . ' ' . $statusColors[2] . ' ' . $statusColors[0] ?>"><?= $statusColors[3] ?></span>
    </div>

    <div class="mt-3 grid grid-cols-3 gap-2 text-center">
      <div class="bg-black/40 border border-gray-800 rounded-xl py-2">
        <div class="text-base font-extrabold text-white"><?= (int)$m['approved_count'] ?><span class="text-gray-500 text-xs">/<?= (int)$m['player_capacity'] ?></span></div>
        <div class="text-[10px] text-gray-500 uppercase">Approved</div>
      </div>
      <div class="bg-black/40 border border-gray-800 rounded-xl py-2">
        <div class="text-base font-extrabold text-white"><?= (int)$m['total_regs'] ?></div>
        <div class="text-[10px] text-gray-500 uppercase">Total Regs</div>
      </div>
      <div class="bg-black/40 border border-gray-800 rounded-xl py-2">
        <div class="text-base font-extrabold text-white"><?= $m['published'] ? '<i class="fa-solid fa-check text-green-400"></i>' : '—' ?></div>
        <div class="text-[10px] text-gray-500 uppercase">Published</div>
      </div>
    </div>

    <!-- Actions -->
    <div class="mt-3 flex gap-2">
      <?php if ($m['status'] === 'Upcoming'): ?>
        <form method="post" action="matches.php" class="flex-1">
          <input type="hidden" name="action" value="start"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
          <?= csrf_field() ?>
          <button class="w-full bg-gradient-to-r from-red-600 to-red-500 text-white text-xs font-bold py-2.5 rounded-xl">Start</button>
        </form>
        <?php if ((string)$m['room_id'] !== ''): ?>
          <form method="post" action="matches.php" class="flex-1">
            <input type="hidden" name="action" value="publish_room"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
            <?= csrf_field() ?>
            <button class="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-2.5 rounded-xl" <?= (int)$m['room_published'] === 1 ? 'disabled' : '' ?>>
              <i class="fa-solid fa-share-nodes mr-1"></i><?= (int)$m['room_published'] === 1 ? 'Room Published' : 'Publish Room' ?>
            </button>
          </form>
        <?php endif; ?>
        <a href="matches.php?edit=<?= (int)$m['id'] ?>" class="flex-1 text-center bg-[#1a1a1a] border border-gray-700 text-gray-300 text-xs font-bold py-2.5 rounded-xl"><i class="fa-solid fa-pen"></i> Override</a>
        <form method="post" action="matches.php" class="flex-1">
          <input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
          <?= csrf_field() ?>
          <button class="w-full bg-gray-800 text-gray-400 text-xs font-bold py-2.5 rounded-xl">Cancel</button>
        </form>
      <?php elseif ($m['status'] === 'Live'): ?>
        <form method="post" action="matches.php" class="flex-1">
          <input type="hidden" name="action" value="complete"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
          <?= csrf_field() ?>
          <select name="winner_user_id" class="w-full bg-black/40 border border-gray-700 rounded-xl px-2 py-2 text-xs text-white">
            <option value="">Select winner…</option>
            <?php foreach ($approvedUsers as $au): ?>
              <option value="<?= (int)$au['user_id'] ?>"><?= e($au['username']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="mt-2 grid grid-cols-2 gap-2">
            <button class="bg-green-600 hover:bg-green-500 text-white text-xs font-bold py-2.5 rounded-xl transition">Complete &amp; Publish</button>
            <button form="cancel-<?= (int)$m['id'] ?>" type="submit" class="bg-gray-800 text-gray-400 text-xs font-bold py-2.5 rounded-xl">Cancel</button>
          </div>
        </form>
        <form id="cancel-<?= (int)$m['id'] ?>" method="post" action="matches.php">
          <input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
          <?= csrf_field() ?>
        </form>
      <?php elseif ($m['status'] === 'Completed'): ?>
        <div class="flex-1 text-center bg-green-500/10 border border-green-500/40 text-green-300 text-xs font-bold py-2.5 rounded-xl">
          <i class="fa-solid fa-crown mr-1"></i> <?= e($m['winner_name'] ?: 'No winner') ?> · Results published
        </div>
      <?php else: ?>
        <div class="flex-1 text-center bg-gray-800 text-gray-500 text-xs font-bold py-2.5 rounded-xl">Cancelled</div>
      <?php endif; ?>
    </div>

    <!-- Registrations -->
    <details class="mt-3 bg-black/30 border border-gray-800 rounded-xl">
      <summary class="px-4 py-3 text-xs font-bold text-gray-400 cursor-pointer list-none flex items-center justify-between">
        <span><i class="fa-solid fa-users mr-2 text-red-500"></i>Registrations (<?= count($regList) ?>)</span>
        <i class="fa-solid fa-chevron-down"></i>
      </summary>
      <div class="px-4 pb-4 divide-y divide-gray-800/60">
        <?php if (!$regList): ?>
          <div class="py-3 text-xs text-gray-500">No registrations.</div>
        <?php endif; ?>
        <?php foreach ($regList as $r): ?>
          <div class="py-2.5 flex items-center justify-between">
            <div>
              <div class="text-sm font-semibold text-white">
                <?php if ($r['slot_number']): ?><span class="text-gray-500 text-xs mr-1">#<?= (int)$r['slot_number'] ?></span><?php endif; ?>
                <?= e($r['username']) ?>
              </div>
              <div class="text-[10px] text-gray-500 mt-0.5">
                UID: <?= e($r['ff_uid'] ?: '—') ?> · IGN: <?= e($r['ff_ign'] ?: '—') ?>
              </div>
              <?php if (!empty($r['team_members'])): ?>
                <?php $tm = json_decode((string)$r['team_members'], true) ?: []; ?>
                <?php if ($tm): ?>
                  <div class="text-[10px] text-indigo-300/80 mt-0.5">
                    Team: <?php foreach ($tm as $i => $t): if ($i > 0) echo ' · '; echo e($t['ff_uid'] ?? '?') . ' (' . e($t['ff_ign'] ?? '?') . ')'; endforeach; ?>
                  </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="text-[10px] <?= $r['reg_status'] === 'Approved' ? 'text-green-400' : ($r['reg_status'] === 'Pending' ? 'text-yellow-400' : 'text-gray-500') ?> uppercase">
                <?= e($r['reg_status']) ?>
              </div>
            </div>
            <?php if ($r['reg_status'] === 'Pending'): ?>
              <div class="flex gap-2">
                <form method="post" action="matches.php">
                  <input type="hidden" name="action" value="approve_reg"><input type="hidden" name="reg_id" value="<?= (int)$r['reg_id'] ?>">
                  <?= csrf_field() ?>
                  <button class="bg-green-600/90 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg">Approve</button>
                </form>
                <form method="post" action="matches.php">
                  <input type="hidden" name="action" value="reject_reg"><input type="hidden" name="reg_id" value="<?= (int)$r['reg_id'] ?>">
                  <?= csrf_field() ?>
                  <button class="bg-gray-700 text-gray-300 text-[11px] font-bold px-3 py-1.5 rounded-lg">Reject</button>
                </form>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </details>
  </div>
<?php endforeach; ?>

<?php require_once __DIR__ . '/_footer.php'; ?>
