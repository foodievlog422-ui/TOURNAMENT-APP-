<?php
/**
 * EXALOTE EXN — Admin: deposit requests (approve/reject).
 */
$page_title = 'Deposits';
$active_admin = 'deposits';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../common/notify.php';

$flash = null;
if (isset($_SESSION['admin_flash'])) {
    $flash = $_SESSION['admin_flash'];
    unset($_SESSION['admin_flash']);
}

// ---- Approve ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_deposit'])) {
    csrf_verify();
    $id = (int)$_POST['id'];
    $d = db()->prepare('SELECT * FROM deposits WHERE id = ? AND status = "Pending" FOR UPDATE');
    $d->execute([$id]);
    $dep = $d->fetch();
    if ($dep) {
        db()->beginTransaction();
        try {
            // Re-check (locked) row inside the transaction.
            $d2 = db()->prepare('SELECT * FROM deposits WHERE id = ? AND status = "Pending" FOR UPDATE');
            $d2->execute([$id]);
            $dep = $d2->fetch();
            if (!$dep) {
                db()->rollBack();
                $flash = ['type' => 'error', 'text' => 'Deposit already processed.'];
            } else {
                // Deposits credit the DEPOSIT bucket (not directly withdrawable).
                db()->prepare('UPDATE users SET deposit_balance = deposit_balance + ?, wallet_balance = wallet_balance + ? WHERE id = ?')
                    ->execute([$dep['amount'], $dep['amount'], $dep['user_id']]);
                log_transaction($dep['user_id'], $dep['amount'], 'credit', 'Deposit verified (Txn ' . $dep['transaction_id'] . ')');
                db()->prepare('UPDATE deposits SET status = "Completed" WHERE id = ?')->execute([$id]);
                db()->commit();
                notify($dep['user_id'], '✅ Your deposit of ₹' . number_format((float)$dep['amount'], 2) . ' has been approved and credited to your wallet.', 'deposit', 'wallet.php');
                $flash = ['type' => 'success', 'text' => 'Deposit approved & balance credited.'];
            }
        } catch (Exception $e) {
            if (db()->inTransaction()) { db()->rollBack(); }
            $flash = ['type' => 'error', 'text' => 'Approval failed.'];
        }
    } else {
        $flash = ['type' => 'error', 'text' => 'Deposit not found or already processed.'];
    }
    $_SESSION['admin_flash'] = $flash;
    redirect('deposits.php');
}

// ---- Reject ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_deposit'])) {
    csrf_verify();
    $rid = (int)$_POST['id'];
    try {
        db()->beginTransaction();
        $rd = db()->prepare('SELECT * FROM deposits WHERE id = ? AND status = "Pending" FOR UPDATE');
        $rd->execute([$rid]);
        $rdep = $rd->fetch();
        if ($rdep) {
            db()->prepare('UPDATE deposits SET status = "Rejected" WHERE id = ?')->execute([$rid]);
            notify($rdep['user_id'], 'Your deposit of ₹' . number_format((float)$rdep['amount'], 2) . ' was rejected. Contact support if this is a mistake.', 'deposit', 'wallet.php');
        }
        db()->commit();
    } catch (Exception $e) {
        if (db()->inTransaction()) { db()->rollBack(); }
    }
    $_SESSION['admin_flash'] = ['type' => 'success', 'text' => 'Deposit rejected.'];
    redirect('deposits.php');
}

$rows = db()->query(
    "SELECT d.*, u.username, u.email FROM deposits d JOIN users u ON u.id = d.user_id ORDER BY d.created_at DESC"
)->fetchAll();
?>
<?php if ($flash): ?>
  <div class="mb-4 rounded-xl px-4 py-3 text-sm flex items-center gap-2 <?= $flash['type'] === 'error' ? 'bg-red-500/10 border border-red-500/30 text-red-300' : 'bg-green-500/10 border border-green-500/30 text-green-300' ?>">
    <i class="fa-solid <?= $flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<div class="flex items-center justify-between mb-4">
  <h2 class="text-xl font-extrabold">Deposit Requests</h2>
  <span class="text-xs text-gray-400"><?= count($rows) ?> total</span>
</div>

<?php if (empty($rows)): ?>
  <div class="text-center py-14 text-gray-500">
    <i class="fa-solid fa-circle-plus text-4xl text-gray-700 mb-3"></i>
    <p class="text-sm">No deposits yet.</p>
  </div>
<?php else: ?>
  <div class="space-y-3">
    <?php foreach ($rows as $r): ?>
      <div class="bg-gray-900 border border-gray-800 rounded-2xl p-4 shadow">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="font-bold text-white"><?= e($r['username']) ?></div>
            <div class="text-xs text-gray-400 truncate"><?= e($r['email']) ?></div>
          </div>
          <div class="text-right shrink-0">
            <div class="text-lg font-extrabold text-green-400"><?= e(money($r['amount'])) ?></div>
            <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full
              <?= $r['status'] === 'Pending' ? 'bg-amber-500/15 text-amber-400' : ($r['status'] === 'Completed' ? 'bg-green-500/15 text-green-400' : 'bg-red-500/15 text-red-400') ?>">
              <?= e($r['status']) ?>
            </span>
          </div>
        </div>
        <div class="mt-2 bg-gray-800/50 rounded-lg px-3 py-2 text-xs">
          <span class="text-gray-500">Txn ID: </span><span class="font-mono text-white"><?= e($r['transaction_id']) ?></span>
        </div>
        <div class="text-[10px] text-gray-500 mt-2"><?= e(date('d M Y, h:i A', strtotime($r['created_at']))) ?></div>

        <?php if ($r['status'] === 'Pending'): ?>
          <div class="mt-3 grid grid-cols-2 gap-2">
            <form method="post">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <?= csrf_field() ?>
              <button type="submit" name="approve_deposit" value="1" class="w-full bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl py-2.5 text-sm transition">
                <i class="fa-solid fa-check mr-1"></i>Approve
              </button>
            </form>
            <form method="post">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <?= csrf_field() ?>
              <button type="submit" name="reject_deposit" value="1" class="w-full bg-gray-800 hover:bg-red-500/20 border border-gray-700 text-red-300 font-bold rounded-xl py-2.5 text-sm transition">
                <i class="fa-solid fa-xmark mr-1"></i>Reject
              </button>
            </form>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?php require_once __DIR__ . '/_footer.php'; ?>
