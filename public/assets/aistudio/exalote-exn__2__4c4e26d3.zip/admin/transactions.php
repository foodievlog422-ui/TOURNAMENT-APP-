<?php
/**
 * EXALOTE EXN — Admin: transaction log (money credits/debits).
 */
$page_title = 'Transactions';
$active_admin = 'transactions';
require_once __DIR__ . '/_header.php';

$rows = db()->query(
    "SELECT t.*, u.username FROM transactions t JOIN users u ON u.id = t.user_id ORDER BY t.created_at DESC LIMIT 100"
)->fetchAll();
?>
<div class="flex items-center justify-between mb-4">
  <h2 class="text-xl font-extrabold">Transactions</h2>
  <span class="text-xs text-gray-400">Latest 100</span>
</div>

<?php if (empty($rows)): ?>
  <div class="text-center py-14 text-gray-500">
    <i class="fa-solid fa-clock-rotate-left text-4xl text-gray-700 mb-3"></i>
    <p class="text-sm">No transactions yet.</p>
  </div>
<?php else: ?>
  <div class="space-y-2">
    <?php foreach ($rows as $tx): ?>
      <?php $isCredit = $tx['type'] === 'credit'; ?>
      <div class="flex items-center justify-between bg-gray-900 border border-gray-800 rounded-xl px-4 py-3">
        <div class="flex items-center gap-3 min-w-0">
          <div class="w-8 h-8 rounded-lg shrink-0 flex items-center justify-center <?= $isCredit ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400' ?>">
            <i class="fa-solid <?= $isCredit ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down' ?>"></i>
          </div>
          <div class="min-w-0">
            <div class="text-sm font-medium text-white truncate"><?= e($tx['description']) ?></div>
            <div class="text-[10px] text-gray-500">
              <?= e($tx['username']) ?> · <?= e(date('d M Y, h:i A', strtotime($tx['created_at']))) ?>
            </div>
          </div>
        </div>
        <div class="text-sm font-bold shrink-0 <?= $isCredit ? 'text-emerald-400' : 'text-red-400' ?>">
          <?= $isCredit ? '+' : '−' ?><?= money($tx['amount']) ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?php require_once __DIR__ . '/_footer.php'; ?>
