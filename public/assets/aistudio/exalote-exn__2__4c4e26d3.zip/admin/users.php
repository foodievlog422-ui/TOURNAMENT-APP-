<?php
/**
 * EXALOTE EXN — Admin: users list.
 */
$page_title = 'Users';
$active_admin = 'users';
require_once __DIR__ . '/_header.php';

$rows = db()->query(
    "SELECT u.*, (SELECT COUNT(*) FROM participants p WHERE p.user_id = u.id) AS joined_count,
            (SELECT COUNT(*) FROM deposits d WHERE d.user_id = u.id AND d.status='Completed') AS dep_count
     FROM users u ORDER BY u.id DESC"
)->fetchAll();
?>
<div class="flex items-center justify-between mb-4">
  <h2 class="text-xl font-extrabold">Users</h2>
  <span class="text-xs text-gray-400"><?= count($rows) ?> total</span>
</div>

<?php if (empty($rows)): ?>
  <div class="text-center py-14 text-gray-500">
    <i class="fa-solid fa-users text-4xl text-gray-700 mb-3"></i>
    <p class="text-sm">No users registered yet.</p>
  </div>
<?php else: ?>
  <div class="space-y-3">
    <?php foreach ($rows as $r): ?>
      <div class="bg-gray-900 border border-gray-800 rounded-2xl p-4 shadow">
        <div class="flex items-start justify-between gap-3">
          <div class="flex items-center gap-3 min-w-0">
            <div class="w-11 h-11 rounded-xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center text-white font-extrabold shrink-0">
              <?= e(strtoupper(substr($r['username'], 0, 1))) ?>
            </div>
            <div class="min-w-0">
              <div class="font-bold text-white truncate"><?= e($r['username']) ?></div>
              <div class="text-xs text-gray-400 truncate"><?= e($r['email']) ?></div>
            </div>
          </div>
          <div class="text-right shrink-0">
            <div class="text-[10px] text-gray-500 uppercase">Balance</div>
            <div class="font-extrabold text-green-400"><?= e(money($r['wallet_balance'])) ?></div>
          </div>
        </div>
        <div class="mt-3 grid grid-cols-2 gap-2 text-center">
          <div class="bg-gray-800/60 rounded-xl py-2">
            <div class="text-[10px] text-gray-400 uppercase">Joined</div>
            <div class="text-sm font-bold"><?= (int)$r['joined_count'] ?> tourneys</div>
          </div>
          <div class="bg-gray-800/60 rounded-xl py-2">
            <div class="text-[10px] text-gray-400 uppercase">Verified Deposits</div>
            <div class="text-sm font-bold"><?= (int)$r['dep_count'] ?></div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?php require_once __DIR__ . '/_footer.php'; ?>
