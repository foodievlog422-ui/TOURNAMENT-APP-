<?php
/**
 * EXALOTE EXN — Admin: FamPay gateway health + admin log.
 */
$page_title = 'Payment Gateway';
$active_admin = 'gateway';
require_once __DIR__ . '/_header.php';

$health = gateway_request('GET', '/health');

$logStmt = db()->query('SELECT * FROM admin_log ORDER BY id DESC LIMIT 40');
$logRows = $logStmt->fetchAll();

$h = $health['body']['health'] ?? [];
$gwOk = $health['status'] === 200;
?>
<div class="mb-5 fade-up">
  <h2 class="text-xl font-extrabold text-white">Payment Gateway</h2>
  <p class="text-sm text-gray-500">FamPay UPI auto-verify engine</p>
</div>

<div class="grid grid-cols-2 gap-3 mb-5">
  <div class="rounded-2xl p-4 bg-[#121212] border <?= $gwOk ? 'border-green-500/40' : 'border-red-500/40' ?>">
    <div class="flex items-center gap-2 mb-1">
      <?php if ($gwOk): ?>
        <span class="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></span>
        <span class="text-xs font-bold text-green-400">ONLINE</span>
      <?php else: ?>
        <span class="w-2.5 h-2.5 rounded-full bg-red-500"></span>
        <span class="text-xs font-bold text-red-400">OFFLINE</span>
      <?php endif; ?>
    </div>
    <div class="text-[11px] text-gray-500">Service 127.0.0.1:8666</div>
  </div>
  <div class="rounded-2xl p-4 bg-[#121212] border border-gray-800">
    <div class="text-xs text-gray-400 mb-1">Configured</div>
    <div class="text-xl font-extrabold text-white"><?= ($h['configured'] ?? false) ? 'Yes' : 'No' ?></div>
  </div>
</div>

<div class="bg-[#121212] border border-gray-800 rounded-2xl p-5 mb-5">
  <h3 class="font-bold text-white mb-3">Health Checks</h3>
  <div class="space-y-2 text-sm">
    <div class="flex items-center justify-between">
      <span class="text-gray-400 flex items-center gap-2"><i class="fa-solid fa-envelope text-gray-500"></i>Gmail IMAP</span>
      <span class="<?= ($h['gmail_ok'] ?? false) ? 'text-green-400' : 'text-red-400' ?> font-semibold">
        <?= ($h['gmail_ok'] ?? false) ? 'Connected' : 'Failed' ?>
      </span>
    </div>
    <div class="flex items-center justify-between">
      <span class="text-gray-400 flex items-center gap-2"><i class="fa-solid fa-qrcode text-gray-500"></i>QR Generator</span>
      <span class="<?= ($h['qr_ok'] ?? false) ? 'text-green-400' : 'text-red-400' ?> font-semibold">
        <?= ($h['qr_ok'] ?? false) ? 'Ready' : 'Missing lib' ?>
      </span>
    </div>
    <div class="flex items-center justify-between">
      <span class="text-gray-400 flex items-center gap-2"><i class="fa-solid fa-circle-pause text-gray-500"></i>Circuit Breaker</span>
      <span class="<?= ($h['breaker_paused'] ?? false) ? 'text-red-400' : 'text-green-400' ?> font-semibold">
        <?= ($h['breaker_paused'] ?? false) ? 'Paused' : 'Active' ?>
      </span>
    </div>
  </div>
  <?php if (!empty($h['message'])): ?>
    <div class="mt-3 text-[11px] text-gray-500 bg-gray-900 rounded-lg px-3 py-2"><?= e($h['message']) ?></div>
  <?php endif; ?>
</div>

<div class="bg-[#121212] border border-gray-800 rounded-2xl p-5">
  <div class="flex items-center justify-between mb-3">
    <h3 class="font-bold text-white">Gateway Events</h3>
    <span class="text-[11px] text-gray-500">Last 40</span>
  </div>
  <?php if (empty($logRows)): ?>
    <div class="text-center py-8 text-gray-500">
      <i class="fa-solid fa-inbox text-3xl text-gray-700 mb-2"></i>
      <p class="text-sm">No gateway events yet.</p>
    </div>
  <?php else: ?>
    <div class="space-y-2">
      <?php foreach ($logRows as $row): ?>
        <div class="bg-[#1a1a1a] border border-gray-800 rounded-xl px-4 py-3">
          <div class="flex items-center justify-between">
            <span class="text-sm font-semibold text-white"><?= e($row['event']) ?></span>
            <span class="text-[10px] text-gray-500"><?= e(date('d M H:i', strtotime($row['created_at']))) ?></span>
          </div>
          <?php if (!empty($row['payload'])): ?>
            <div class="mt-1 text-[11px] text-gray-400 break-words"><?= e($row['payload']) ?></div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
