<?php
/**
 * EXALOTE EXN — Admin: advanced results management.
 * Select a match → view approved participants → enter rank/kills/rewards
 * → preview total → confirm & publish (credits wallet, marks Completed).
 */
$page_title = 'Results';
$active_admin = 'results';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../common/notify.php';

$flash = $_SESSION['admin_flash'] ?? null;
unset($_SESSION['admin_flash']);

// ---- Publish results ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['publish_results'])) {
    csrf_verify();

    $matchId = (int)($_POST['match_id'] ?? 0);
    $match = db()->prepare('SELECT * FROM matches WHERE id = ?');
    $match->execute([$matchId]);
    $m = $match->fetch();
    if (!$m) {
        $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'Match not found.'];
        redirect('results.php');
    }

    // Load participants
    $part = db()->prepare("SELECT u.id AS user_id, u.username FROM registrations r JOIN users u ON u.id = r.user_id WHERE r.match_id = ? AND r.status = 'Approved'");
    $part->execute([$matchId]);
    $participants = $part->fetchAll();
    if (!$participants) {
        $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'No approved participants to publish results for.'];
        redirect('results.php');
    }

    // Already has results? (duplicate guard)
    $existing = db()->prepare('SELECT COUNT(*) FROM results WHERE match_id = ?');
    $existing->execute([$matchId]);
    if ((int)$existing->fetchColumn() > 0) {
        $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'Results already published for this match. Duplicate publish blocked.'];
        redirect('results.php');
    }

    $ranks = $_POST['rank'] ?? [];
    $kills = $_POST['kills'] ?? [];
    $rewards = $_POST['reward'] ?? [];
    $rows = [];
    $totalReward = 0.0;
    $errors = [];

    foreach ($participants as $p) {
        $pid = (int)$p['user_id'];
        $rank = (int)($ranks[$pid] ?? 0);
        $kill = max(0, (int)($kills[$pid] ?? 0));
        $reward = round((float)($rewards[$pid] ?? 0), 2);
        if ($rank < 0) $rank = 0;
        if ($rank === 0 && $kill === 0 && $reward <= 0) {
            // skip unranked with no kills/reward? No — still record participation
        }
        if ($reward < 0) $reward = 0;
        $rows[] = ['user_id' => $pid, 'rank' => $rank, 'kills' => $kill, 'reward' => $reward];
        $totalReward += $reward;
    }

    // Single reward flow: virtual_points ALWAYS awarded; cash paid to wallet
    // ONLY when the wallet is enabled. Results insert (unique match+user) blocks
    // any double award for the same user/match.
    $walletOn = wallet_enabled();
    try {
        db()->beginTransaction();

        $ins = db()->prepare('INSERT INTO results (match_id, user_id, rank, kills, reward_amount) VALUES (?, ?, ?, ?, ?)');
        foreach ($rows as $r) {
            $ins->execute([$matchId, $r['user_id'], $r['rank'], $r['kills'], $r['reward']]);
        }

        // Award leaderboard points to every participant (always).
        $points = 10;
        foreach ($rows as $r) {
            credit_points($r['user_id'], $points, 'Match participation', 'Match #' . $matchId);
        }

        // Credit cash rewards to wallet only when wallet enabled + notify
        $winnerId = null;
        $winnerRank = PHP_INT_MAX;
        foreach ($rows as $r) {
            if ($walletOn && $r['reward'] > 0) {
                $ok = credit_reward($r['user_id'], $r['reward'], 'Tournament reward', 'Match #' . $matchId . ' Rank #' . $r['rank']);
                if (!$ok) {
                    throw new RuntimeException('Wallet credit failed for user ' . $r['user_id']);
                }
                notify($r['user_id'], '🎉 You won ₹' . number_format($r['reward'], 2) . ' for ' . e($m['cat_name'] ?? 'match') . '! Check your wallet.', 'result', 'wallet.php');
            } else {
                notify($r['user_id'], 'Results for your match are published. Check your match history.', 'result', 'my_tournaments.php');
            }
            if ($r['rank'] > 0 && $r['rank'] < $winnerRank) {
                $winnerRank = $r['rank'];
                $winnerId = $r['user_id'];
            }
        }

        // Mark match completed + published + prizes distributed (anti double-pay).
        db()->prepare("UPDATE matches SET status = 'Completed', published = 1, winner_user_id = ?, prizes_distributed = 1 WHERE id = ? AND prizes_distributed = 0")
            ->execute([$winnerId, $matchId]);

        db()->commit();

        $sumText = $walletOn
            ? 'Total ₹' . number_format($totalReward, 2)
            : 'Wallet disabled — points only';
        $_SESSION['admin_flash'] = ['type' => 'success', 'text' => 'Results published. Points awarded. ' . $sumText . '.'];
    } catch (Throwable $e) {
        if (db()->inTransaction()) {
            db()->rollBack();
        }
        $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'Publish failed: ' . $e->getMessage()];
    }
    redirect('results.php');
}

// ---- Data ----
// Matches eligible: Live, Upcoming, or Completed without results yet
$mQ = db()->query("
    SELECT m.*, c.name AS cat_name, c.format AS cat_format,
           (SELECT COUNT(*) FROM results r WHERE r.match_id = m.id) AS result_count
    FROM matches m
    JOIN categories c ON c.id = m.category_id
    LEFT JOIN results r ON r.match_id = m.id
    GROUP BY m.id
    ORDER BY m.match_date DESC, FIELD(m.session,'morning','evening'), m.start_time DESC
")->fetchAll();

$eligible = array_filter($mQ, fn($m) => (int)$m['result_count'] === 0);

$selected = null;
$participants = [];
$rules = reward_rules();
if (isset($_GET['match_id'])) {
    $mid = (int)$_GET['match_id'];
    foreach ($eligible as $e) {
        if ((int)$e['id'] === $mid) {
            $selected = $e;
            break;
        }
    }
    if ($selected) {
        $part = db()->prepare("
            SELECT u.id AS user_id, u.username, u.upi_id,
                   c.claimed_kills, c.claimed_rank, c.screenshot_path,
                   c.report_suspect_ign, c.report_reason, c.status AS claim_status
            FROM registrations r
            JOIN users u ON u.id = r.user_id
            LEFT JOIN match_claims c ON c.match_id = r.match_id AND c.user_id = r.user_id
            WHERE r.match_id = ? AND r.status = 'Approved'
        ");
        $part->execute([$mid]);
        foreach ($part->fetchAll() as $i => $p) {
            $p['rank'] = $i + 1; // default sequential rank
            $p['kills'] = 0;
            // Prefill from the player's claim when the admin hasn't edited yet.
            if (((int)$p['claimed_rank']) > 0) {
                $p['rank'] = (int)$p['claimed_rank'];
            }
            if (((int)$p['claimed_kills']) > 0) {
                $p['kills'] = (int)$p['claimed_kills'];
            }
            $p['reward'] = $rules['rank'][$p['rank']] ?? 0;
            $participants[] = $p;
        }
    }
}

function reward_cell(float $n): string
{
    return '₹' . number_format($n, 2);
}
?>
<?php if ($flash): ?>
  <div class="mb-4 rounded-xl px-4 py-3 text-sm flex items-center gap-2 <?= $flash['type'] === 'error' ? 'bg-red-500/10 border border-red-500/30 text-red-300' : 'bg-green-500/10 border border-green-500/30 text-green-300' ?>">
    <i class="fa-solid <?= $flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<div class="mb-5 fade-up">
  <h2 class="text-xl font-extrabold text-white">Advanced Results</h2>
  <p class="text-sm text-gray-500">Enter rank / kills / rewards, preview total, then publish.</p>
</div>

<!-- Select match -->
<div class="bg-[#121212] border border-gray-800 rounded-2xl p-4 mb-6">
  <h3 class="font-bold text-white mb-3">1 · Select a match</h3>
  <form method="get" action="results.php">
    <select name="match_id" required onchange="this.form.submit()" class="w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      <option value="">Choose a match…</option>
      <?php foreach ($eligible as $e): ?>
        <option value="<?= (int)$e['id'] ?>" <?= $selected && (int)$selected['id'] === (int)$e['id'] ? 'selected' : '' ?>>
          <?= e($e['cat_name']) ?> · <?= e($e['match_date']) ?> · <?= e(date('h:i A', strtotime($e['start_time']))) ?> (<?= e($e['status']) ?>)
        </option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<?php if ($selected): ?>
  <!-- Participants + reward editing -->
  <div class="bg-[#121212] border border-gray-800 rounded-2xl p-4 mb-6">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-bold text-white">2 · Entry results</h3>
      <span class="text-[10px] font-bold px-2 py-1 rounded-full border border-gray-700 text-gray-400"><?= e($selected['status']) ?></span>
    </div>
    <div class="mb-3 bg-black/30 border border-gray-800 rounded-xl px-3 py-2 text-xs text-gray-400">
      <?= e($selected['cat_name']) ?> · <?= e($selected['match_date']) ?> · <?= e(date('h:i A', strtotime($selected['start_time']))) ?> IST
    </div>

    <form method="post" action="results.php" id="results-form">
      <?= csrf_field() ?>
      <input type="hidden" name="publish_results" value="1">
      <input type="hidden" name="match_id" value="<?= (int)$selected['id'] ?>">

      <div class="space-y-3">
        <?php foreach ($participants as $p): ?>
          <div class="bg-black/30 border border-gray-800 rounded-xl p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-sm font-bold text-white"><?= e($p['username']) ?></span>
              <?php if (!empty($p['report_suspect_ign'])): ?>
                <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/40" title="Hack report">
                  <i class="fa-solid fa-triangle-exclamation mr-1"></i>Hack Report
                </span>
              <?php endif; ?>
            </div>
            <?php if (!empty($p['report_suspect_ign']) || !empty($p['report_reason'])): ?>
              <div class="mb-2 text-[10px] text-red-300/80 bg-red-500/5 border border-red-500/20 rounded-lg px-2.5 py-1.5">
                Suspect: <?= e($p['report_suspect_ign'] ?: '—') ?> · <?= e($p['report_reason'] ?: 'no reason') ?>
              </div>
            <?php endif; ?>
            <?php if (!empty($p['screenshot_path'])): ?>
              <div class="mb-2">
                <a href="<?= e($p['screenshot_path']) ?>" target="_blank" rel="noopener"
                   class="inline-flex items-center gap-1.5 text-[11px] font-semibold text-indigo-300 hover:text-indigo-200 bg-indigo-500/10 border border-indigo-500/30 rounded-lg px-2.5 py-1.5">
                  <i class="fa-solid fa-image"></i>View Claim Screenshot
                </a>
                <span class="ml-2 text-[10px] text-gray-500">Claimed: <?= (int)$p['claimed_kills'] ?> kills / Rank <?= (int)$p['claimed_rank'] ?></span>
              </div>
            <?php endif; ?>
            <div class="grid grid-cols-3 gap-2">
              <div>
                <label class="text-[10px] text-gray-500 uppercase">Rank</label>
                <input type="number" name="rank[<?= (int)$p['user_id'] ?>]" min="0" value="<?= (int)$p['rank'] ?>" class="mt-1 w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-sm text-center outline-none focus:border-red-500/60">
              </div>
              <div>
                <label class="text-[10px] text-gray-500 uppercase">Kills</label>
                <input type="number" name="kills[<?= (int)$p['user_id'] ?>]" min="0" value="<?= (int)$p['kills'] ?>" class="mt-1 w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-sm text-center outline-none focus:border-red-500/60">
              </div>
              <div>
                <label class="text-[10px] text-gray-500 uppercase">Reward ₹</label>
                <input type="number" name="reward[<?= (int)$p['user_id'] ?>]" min="0" step="0.01" value="<?= number_format((float)$p['reward'], 2, '.', '') ?>" class="mt-1 w-full bg-gray-900 border border-gray-800 rounded-lg px-2 py-2 text-sm text-center text-green-300 outline-none focus:border-red-500/60">
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="mt-4 bg-green-500/10 border border-green-500/30 rounded-xl px-4 py-3 text-sm">
        <div class="flex items-center justify-between text-green-300">
          <span class="font-semibold">Total rewards</span>
          <span class="text-lg font-extrabold"><span id="results-total">₹0.00</span></span>
        </div>
        <p class="text-[10px] text-green-500/70 mt-1">These are credited to each player's wallet on publish.</p>
      </div>

      <button type="submit" class="mt-4 w-full bg-gradient-to-r from-green-600 to-emerald-500 hover:from-green-500 hover:to-emerald-400 text-white text-sm font-extrabold py-3 rounded-xl transition-all">
        <i class="fa-solid fa-flag-checkered mr-1.5"></i>Confirm & Publish Results
      </button>
    </form>
  </div>

  <script>
    // Live total preview
    (function () {
      var form = document.getElementById('results-form');
      var totalEl = document.getElementById('results-total');
      function update() {
        var total = 0;
        var inputs = form.querySelectorAll('input[name^="reward["]');
        inputs.forEach(function (inp) {
          var v = parseFloat(inp.value) || 0;
          if (v > 0) total += v;
        });
        totalEl.textContent = '₹' + total.toFixed(2);
      }
      form.querySelectorAll('input[name^="reward["]').forEach(function (inp) {
        inp.addEventListener('input', update);
      });
      update();
    })();
  </script>
<?php else: ?>
  <div class="text-center py-14 text-gray-500">
    <i class="fa-solid fa-flag-checkered text-4xl text-gray-700 mb-3"></i>
    <p class="text-sm">Select a match to enter results.</p>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/_footer.php'; ?>
