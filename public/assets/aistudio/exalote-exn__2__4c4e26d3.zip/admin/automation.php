<?php
/**
 * EXALOTE EXN — Admin: daily automation controls.
 */
$page_title = 'Automation';
$active_admin = 'automation';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../common/scheduler.php';

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$cfg = ex_settings();
$skipList = array_filter(array_map('trim', explode(',', (string)($cfg['skip_dates'] ?? ''))));
$today = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_settings') {
        $dur = max(1, (int)($_POST['duration_min'] ?? 20));
        $buf = max(0, (int)($_POST['buffer_min'] ?? 5));
        $cap = max(1, (int)($_POST['capacity_default'] ?? 10));
        db()->prepare('UPDATE settings SET duration_min = ?, buffer_min = ?, capacity_default = ? WHERE id = 1')
            ->execute([$dur, $buf, $cap]);
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Recurring settings saved.'];
        redirect('automation.php');
    }

    if ($action === 'toggle_automation') {
        $new = (int)($_POST['enabled'] ?? 0);
        db()->prepare('UPDATE settings SET automation_enabled = ? WHERE id = 1')->execute([$new]);
        $_SESSION['flash'] = ['type' => 'info', 'text' => $new ? 'Automation enabled (resumed).' : 'Automation disabled (paused).'];
        redirect('automation.php');
    }

    if ($action === 'skip_date') {
        $date = trim($_POST['skip_date'] ?? '');
        if ($date !== '' && !in_array($date, $skipList, true)) {
            $skipList[] = $date;
            db()->prepare('UPDATE settings SET skip_dates = ? WHERE id = 1')->execute([implode(',', $skipList)]);
            $_SESSION['flash'] = ['type' => 'success', 'text' => "Skipped $date."];
        }
        redirect('automation.php');
    }

    if ($action === 'unskip_date') {
        $date = trim($_POST['date'] ?? '');
        $skipList = array_values(array_filter($skipList, fn($d) => $d !== $date));
        db()->prepare('UPDATE settings SET skip_dates = ? WHERE id = 1')->execute([implode(',', $skipList)]);
        $_SESSION['flash'] = ['type' => 'info', 'text' => "Un-skipped $date."];
        redirect('automation.php');
    }
}

// refresh after POST
$cfg = ex_settings();
$skipList = array_filter(array_map('trim', explode(',', (string)($cfg['skip_dates'] ?? ''))));

$todayStats = db()->prepare("SELECT session, COUNT(*) AS n FROM matches WHERE match_date = ? GROUP BY session");
$todayStats->execute([$today]);
$todayStats = $todayStats->fetchAll();
$tCount = array_sum(array_column($todayStats, 'n'));
?>
<div class="mb-5 fade-up">
  <h2 class="text-xl font-extrabold text-white">Daily Automation</h2>
  <p class="text-sm text-gray-500">Auto-publish all 9 categories every IST day</p>
</div>

<?php if ($flash): ?>
  <div class="mb-4 px-4 py-3 rounded-2xl border text-sm font-medium
      <?= $flash['type'] === 'success' ? 'bg-green-500/10 border-green-500/30 text-green-300'
         : ($flash['type'] === 'error' ? 'bg-red-500/10 border-red-500/30 text-red-300' : 'bg-gray-800 border-gray-700 text-gray-200') ?>">
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<!-- Status card -->
<div class="mb-4 bg-[#121212] border border-gray-800 rounded-2xl p-4">
  <div class="flex items-center justify-between">
    <div>
      <div class="text-sm font-bold text-white">Status</div>
      <div class="text-[11px] text-gray-500 mt-0.5">
        Last generated: <b class="text-gray-300"><?= e($cfg['last_generated_date'] ?? 'never') ?></b>
      </div>
    </div>
    <span class="text-xs font-bold px-3 py-1.5 rounded-full border <?= $cfg['automation_enabled']
        ? 'bg-green-500/10 border-green-500/40 text-green-300' : 'bg-gray-700/50 border-gray-700 text-gray-400' ?>">
      <?= $cfg['automation_enabled'] ? '● ENABLED' : '○ PAUSED' ?>
    </span>
  </div>
  <div class="mt-3 grid grid-cols-2 gap-2 text-center">
    <div class="bg-black/40 border border-gray-800 rounded-xl py-2">
      <div class="text-lg font-extrabold text-white"><?= (int)$tCount ?></div>
      <div class="text-[10px] text-gray-500 uppercase">Today's matches</div>
    </div>
    <div class="bg-black/40 border border-gray-800 rounded-xl py-2">
      <div class="text-lg font-extrabold text-white">9</div>
      <div class="text-[10px] text-gray-500 uppercase">Categories / session</div>
    </div>
  </div>
  <div class="mt-3 flex gap-2">
    <form method="post" action="automation.php" class="flex-1">
      <input type="hidden" name="action" value="toggle_automation">
      <?= csrf_field() ?>
      <input type="hidden" name="enabled" value="<?= $cfg['automation_enabled'] ? 0 : 1 ?>">
      <button class="w-full <?= $cfg['automation_enabled'] ? 'bg-gray-800 text-gray-300' : 'bg-gradient-to-r from-green-600 to-green-500 text-white' ?> text-xs font-bold py-2.5 rounded-xl">
        <?= $cfg['automation_enabled'] ? '<i class="fa-solid fa-pause mr-1"></i>Pause' : '<i class="fa-solid fa-play mr-1"></i>Resume' ?>
      </button>
    </form>
    <a href="matches.php" class="flex-1 text-center bg-[#1a1a1a] border border-gray-700 text-gray-300 text-xs font-bold py-2.5 rounded-xl">Manual Override</a>
  </div>
</div>

<!-- Recurring settings -->
<div class="bg-[#121212] border border-gray-800 rounded-2xl p-4 mb-4">
  <h3 class="font-bold text-white mb-3">Recurring Match Settings</h3>
  <form method="post" action="automation.php" class="space-y-3">
    <input type="hidden" name="action" value="update_settings">
    <?= csrf_field() ?>
    <div class="grid grid-cols-3 gap-3">
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Match</label>
        <input type="number" name="duration_min" min="1" required value="<?= (int)$cfg['duration_min'] ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Buffer</label>
        <input type="number" name="buffer_min" min="0" required value="<?= (int)$cfg['buffer_min'] ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
      <div>
        <label class="text-[11px] text-gray-500 font-semibold uppercase">Capacity</label>
        <input type="number" name="capacity_default" min="1" required value="<?= (int)$cfg['capacity_default'] ?>" class="mt-1 w-full bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
      </div>
    </div>
    <p class="text-[11px] text-gray-500">Match + buffer = slot. 9 slots must fit in a 4-hour session.</p>
    <button class="w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white text-sm font-extrabold py-3 rounded-xl transition">Save Settings</button>
  </form>
</div>

<!-- Skip a day -->
<div class="bg-[#121212] border border-gray-800 rounded-2xl p-4">
  <h3 class="font-bold text-white mb-3">Skip a Day</h3>
  <form method="post" action="automation.php" class="flex gap-2">
    <input type="hidden" name="action" value="skip_date">
    <?= csrf_field() ?>
    <input type="date" name="skip_date" min="<?= e($today) ?>" value="<?= e(date('Y-m-d', strtotime('+1 day'))) ?>" class="flex-1 bg-black/40 border border-gray-800 rounded-xl px-3 py-3 text-sm text-white focus:outline-none focus:border-red-500/60">
    <button class="bg-[#1a1a1a] border border-gray-700 text-gray-300 text-sm font-bold px-4 rounded-xl">Skip</button>
  </form>

  <?php if ($skipList): ?>
    <div class="mt-3 space-y-2">
      <?php foreach ($skipList as $d): ?>
        <div class="flex items-center justify-between bg-black/40 border border-gray-800 rounded-xl px-3 py-2">
          <span class="text-sm text-white"><?= e($d) ?></span>
          <form method="post" action="automation.php">
            <input type="hidden" name="action" value="unskip_date"><input type="hidden" name="date" value="<?= e($d) ?>">
            <?= csrf_field() ?>
            <button class="text-gray-500 hover:text-red-400 text-sm"><i class="fa-solid fa-xmark"></i></button>
          </form>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
