<?php
/**
 * EXALOTE EXN — Admin: withdrawals (complete/reject). Manual payout for trust.
 * Funds are deducted when the user requests; rejecting refunds the wallet.
 */
$page_title = 'Withdrawals';
$active_admin = 'withdrawals';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../common/notify.php';

$flash = null;
if (isset($_SESSION['admin_flash'])) {
    $flash = $_SESSION['admin_flash'];
    unset($_SESSION['admin_flash']);
}

// ---- Complete ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['complete_withdraw'])) {
    csrf_verify();
    $id = (int)$_POST['id'];
    try {
        db()->beginTransaction();
        $w = db()->prepare('SELECT * FROM withdrawals WHERE id = ? AND status = "Pending" FOR UPDATE');
        $w->execute([$id]);
        $wd = $w->fetch();
        if ($wd) {
            db()->prepare('UPDATE withdrawals SET status = "Completed" WHERE id = ?')->execute([$id]);
            notify($wd['user_id'], '✅ Your withdrawal of ₹' . number_format((float)$wd['amount'], 2) . ' has been completed and paid to your UPI.', 'withdraw', 'wallet.php');
            db()->commit();
            $flash = ['type' => 'success', 'text' => 'Withdrawal marked complete. Paid to user UPI.'];
        } else {
            db()->rollBack();
            $flash = ['type' => 'error', 'text' => 'Withdrawal not found or already processed.'];
        }
    } catch (Exception $e) {
        if (db()->inTransaction()) { db()->rollBack(); }
        $flash = ['type' => 'error', 'text' => 'Could not complete withdrawal.'];
    }
    $_SESSION['admin_flash'] = $flash;
    redirect('withdrawals.php');
}

// ---- Reject (refund) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_withdraw'])) {
    csrf_verify();
    $id = (int)$_POST['id'];
    try {
        db()->beginTransaction();
        $w = db()->prepare('SELECT * FROM withdrawals WHERE id = ? AND status = "Pending" FOR UPDATE');
        $w->execute([$id]);
        $wd = $w->fetch();
        if ($wd) {
            // Refunds go back to the WINNINGS bucket (withdrawals only come from here).
            db()->prepare('UPDATE users SET winnings_balance = winnings_balance + ?, wallet_balance = wallet_balance + ? WHERE id = ?')
                ->execute([$wd['amount'], $wd['amount'], $wd['user_id']]);
            log_transaction($wd['user_id'], $wd['amount'], 'credit', 'Withdrawal rejected — refunded');
            db()->prepare('UPDATE withdrawals SET status = "Rejected" WHERE id = ?')->execute([$id]);
            db()->commit();
            notify($wd['user_id'], 'Your withdrawal request of ₹' . number_format((float)$wd['amount'], 2) . ' was rejected and the amount has been refunded to your wallet.', 'withdraw', 'wallet.php');
            $flash = ['type' => 'success', 'text' => 'Withdrawal rejected & amount refunded.'];
        } else {
            db()->rollBack();
            $flash = ['type' => 'error', 'text' => 'Withdrawal not found or already processed.'];
        }
    } catch (Exception $e) {
        if (db()->inTransaction()) { db()->rollBack(); }
        $flash = ['type' => 'error', 'text' => 'Could not reject withdrawal.'];
    }
    $_SESSION['admin_flash'] = $flash;
    redirect('withdrawals.php');
}

$rows = db()->query(
    "SELECT w.*, u.username, u.email, u.upi_id FROM withdrawals w JOIN users u ON u.id = w.user_id ORDER BY w.created_at DESC"
)->fetchAll();
?>
<?php if ($flash): ?>
  <div class="mb-4 rounded-xl px-4 py-3 text-sm flex items-center gap-2 <?= $flash['type'] === 'error' ? 'bg-red-500/10 border border-red-500/30 text-red-300' : 'bg-green-500/10 border border-green-500/30 text-green-300' ?>">
    <i class="fa-solid <?= $flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<div class="flex items-center justify-between mb-4">
  <h2 class="text-xl font-extrabold">Withdrawal Requests</h2>
  <span class="text-xs text-gray-400"><?= count($rows) ?> total</span>
</div>

<?php if (empty($rows)): ?>
  <div class="text-center py-14 text-gray-500">
    <i class="fa-solid fa-hand-holding-usd text-4xl text-gray-700 mb-3"></i>
    <p class="text-sm">No withdrawal requests yet.</p>
  </div>
<?php else: ?>
  <div class="space-y-3">
    <?php foreach ($rows as $r): ?>
      <div class="bg-gray-900 border border-gray-800 rounded-2xl p-4 shadow">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="font-bold text-white"><?= e($r['username']) ?></div>
            <div class="text-2 text-gray-400 truncate"><?= e($r['email']) ?></div>
            <div class="mt-1 inline-flex items-center gap-1 bg-gray-800 rounded-lg px-2 py-1 text-xs font-mono text-indigo-300">
              <i class="fa-solid fa-sack-dollar text-[10px]"></i><?= e($r['upi_id'] ?: 'no UPI') ?>
            </div>
          </div>
          <div class="text-right shrink-0">
            <div class="text-lg font-extrabold text-amber-400"><?= e(money($r['amount'])) ?></div>
            <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full
              <?= $r['status'] === 'Pending' ? 'bg-amber-500/15 text-amber-400' : ($r['status'] === 'Completed' ? 'bg-green-500/15 text-green-400' : 'bg-red-500/15 text-red-400') ?>">
              <?= e($r['status']) ?>
            </span>
          </div>
        </div>
        <div class="text-[10px] text-gray-500 mt-2"><?= e(date('d M Y, h:i A', strtotime($r['created_at']))) ?></div>

        <?php if ($r['status'] === 'Pending'): ?>
          <div class="mt-3 grid grid-cols-2 gap-2">
            <form method="post">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <?= csrf_field() ?>
              <button type="submit" name="complete_withdraw" value="1"
                onclick="return confirm('Paid to user record UPI? Mark complete.')"
                class="w-full bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl py-2.5 text-sm transition">
                <i class="fa-solid fa-check mr-1"></i>Complete
              </button>
            </form>
            <form method="post">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <?= csrf_field() ?>
              <button type="submit" name="reject_withdraw" value="1" class="w-full bg-gray-800 hover:bg-red-500/20 border border-gray-700 text-red-300 font-bold rounded-xl py-2.5 text-sm transition">
                <i class="fa-solid fa-xmark mr-1"></i>Reject
              </button>
            </form>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?php require_once __DIR__ . '/_footer.php'; ?>
