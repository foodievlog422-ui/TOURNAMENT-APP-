<?php
/**
 * EXALOTE EXN — Admin: custom match requests.
 */
$page_title = 'Custom Requests';
$active_admin = 'requests';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../common/scheduler.php';

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$dur = max(1, (int)(ex_settings()['duration_min'] ?? 20));
$buf = max(0, (int)(ex_settings()['buffer_min'] ?? 5));
$cap = max(1, (int)(ex_settings()['capacity_default'] ?? 10));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    if ($action === 'approve_request') {
        $q = db()->prepare('SELECT * FROM custom_requests WHERE id = ?');
        $q->execute([$id]);
        $req = $q->fetch();
        if (!$req) {
            redirect('custom_requests.php');
        }

        $cat = db()->prepare('SELECT id FROM categories WHERE name = ?');
        $cat->execute([$req['category_name']]);
        $catId = (int)$cat->fetchColumn() ?: 1;

        // single-host overlap check
        $startMin = ex_time_to_minutes(substr($req['start_time'], 0, 5));
        $session = ($startMin >= 600 && $startMin < 840) ? 'morning' : 'evening';
        $oc = db()->prepare("SELECT start_time FROM matches WHERE match_date = ? AND session = ? AND status != 'Cancelled'");
        $oc->execute([$req['match_date'], $session]);
        $overlap = false;
        while ($row = $oc->fetch()) {
            if (abs(ex_time_to_minutes(substr($row['start_time'], 0, 5)) - $startMin) < ($dur + $buf)) {
                $overlap = true;
            }
        }
        if ($overlap) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Overlaps an existing match in this session. Create it manually with a free slot.'];
            redirect('custom_requests.php');
        }

        db()->prepare('INSERT INTO matches (category_id, match_date, session, start_time, player_capacity, host_note) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$catId, $req['match_date'], $session, $req['start_time'], $cap, 'From custom request #' . $id]);
        db()->prepare("UPDATE custom_requests SET status='Approved', admin_note=? WHERE id=?")->execute(['Approved — match created', $id]);
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Request approved: match created.'];
        redirect('custom_requests.php');
    }

    if ($action === 'reject_request') {
        $note = trim($_POST['admin_note'] ?? '');
        db()->prepare("UPDATE custom_requests SET status='Rejected', admin_note=? WHERE id=?")->execute([$note, $id]);
        $_SESSION['flash'] = ['type' => 'info', 'text' => 'Request rejected.'];
        redirect('custom_requests.php');
    }
}

$requests = db()->query('
    SELECT cr.*, u.username FROM custom_requests cr
    JOIN users u ON u.id = cr.user_id
    ORDER BY FIELD(cr.status,"Pending","Approved","Rejected"), cr.created_at DESC
')->fetchAll();

$pending = array_values(array_filter($requests, fn($r) => $r['status'] === 'Pending'));
$others  = array_values(array_filter($requests, fn($r) => $r['status'] !== 'Pending'));
?>
<div class="mb-5 fade-up">
  <h2 class="text-xl font-extrabold text-white">Custom Match Requests</h2>
  <p class="text-sm text-gray-500"><?= count($pending) ?> pending</p>
</div>

<?php if ($flash): ?>
  <div class="mb-4 px-4 py-3 rounded-2xl border text-sm font-medium
      <?= $flash['type'] === 'success' ? 'bg-green-500/10 border-green-500/30 text-green-300'
         : ($flash['type'] === 'error' ? 'bg-red-500/10 border-red-500/30 text-red-300' : 'bg-gray-800 border-gray-700 text-gray-200') ?>">
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<?php if (!$requests): ?>
  <div class="text-center py-10 text-gray-500">
    <i class="fa-solid fa-inbox text-3xl mb-2 text-gray-700"></i>
    <p class="text-sm">No custom requests yet.</p>
  </div>
<?php endif; ?>

<!-- Pending -->
<?php foreach ($pending as $q): ?>
  <div class="mb-4 bg-[#121212] border border-yellow-500/30 rounded-2xl p-4">
    <div class="flex items-start justify-between">
      <div>
        <div class="font-bold text-white"><?= e($q['title']) ?></div>
        <div class="text-[11px] text-gray-500 mt-0.5">
          <span class="inline-block bg-yellow-500/10 text-yellow-300 text-[10px] font-bold px-2 py-0.5 rounded-full mr-1.5">Pending</span>
          <?= e($q['username']) ?>
        </div>
      </div>
    </div>
    <div class="mt-3 grid grid-cols-2 gap-2 text-xs">
      <div class="bg-black/40 border border-gray-800 rounded-xl px-3 py-2">
        <div class="text-gray-500 uppercase text-[10px]">Category</div>
        <div class="text-white font-semibold"><?= e($q['category_name']) ?> · <?= e($q['format']) ?></div>
      </div>
      <div class="bg-black/40 border border-gray-800 rounded-xl px-3 py-2">
        <div class="text-gray-500 uppercase text-[10px]">Requested time</div>
        <div class="text-white font-semibold"><?= e($q['match_date']) ?> <?= e($q['start_time']) ?> IST</div>
      </div>
    </div>
    <?php if ($q['notes']): ?>
      <div class="mt-2 text-[11px] text-gray-400 bg-black/30 border border-gray-800 rounded-lg px-3 py-2"><?= e($q['notes']) ?></div>
    <?php endif; ?>

    <div class="mt-3 grid grid-cols-2 gap-2">
      <form method="post" action="custom_requests.php">
        <input type="hidden" name="action" value="approve_request"><input type="hidden" name="id" value="<?= (int)$q['id'] ?>">
        <?= csrf_field() ?>
        <button class="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white text-xs font-extrabold py-3 rounded-xl transition">
          <i class="fa-solid fa-check mr-1"></i>Approve
        </button>
      </form>
      <form method="post" action="custom_requests.php">
        <input type="hidden" name="action" value="reject_request"><input type="hidden" name="id" value="<?= (int)$q['id'] ?>">
        <?= csrf_field() ?>
        <div class="flex gap-2">
          <input type="text" name="admin_note" placeholder="Reason (optional)" class="flex-1 bg-black/40 border border-gray-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500/60">
          <button class="bg-gray-800 text-gray-300 text-xs font-bold px-3 py-2 rounded-xl">Reject</button>
        </div>
      </form>
    </div>
  </div>
<?php endforeach; ?>

<!-- History -->
<?php if ($others): ?>
  <h3 class="font-bold text-white mb-3 mt-6">History</h3>
  <?php foreach ($others as $q): ?>
    <div class="mb-3 bg-[#121212] border border-gray-800 rounded-2xl p-4 opacity-90">
      <div class="flex items-start justify-between">
        <div>
          <div class="font-bold text-white"><?= e($q['title']) ?></div>
          <div class="text-[11px] text-gray-500 mt-0.5">
            <span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded-full mr-1.5
                <?= $q['status'] === 'Approved' ? 'bg-green-500/15 text-green-300 border border-green-500/40' : 'bg-gray-700 text-gray-400 border border-gray-700' ?>">
              <?= e($q['status']) ?>
            </span>
            <?= e($q['username']) ?> · <?= e($q['match_date']) ?> <?= e($q['start_time']) ?>
          </div>
          <?php if ($q['admin_note']): ?>
            <div class="text-[11px] text-gray-400 mt-2"><?= e($q['admin_note']) ?></div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/_footer.php'; ?>
