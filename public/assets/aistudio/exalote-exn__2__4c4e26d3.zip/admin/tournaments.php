<?php
/**
 * EXALOTE EXN — Admin: tournaments CRUD, players/room, declare winner.
 */
$page_title = 'Tournaments';
$active_admin = 'tournaments';
require_once __DIR__ . '/_header.php';

$flash = null;
if (isset($_SESSION['admin_flash'])) {
    $flash = $_SESSION['admin_flash'];
    unset($_SESSION['admin_flash']);
}

// ---- CREATE ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_tournament'])) {
    csrf_verify();
    $title = trim($_POST['title'] ?? '');
    $game = trim($_POST['game_name'] ?? '');
    $fee = round((float)($_POST['entry_fee'] ?? 0), 2);
    $prize = round((float)($_POST['prize_pool'] ?? 0), 2);
    $matchTime = trim($_POST['match_time'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['Upcoming', 'Live', 'Completed']) ? $_POST['status'] : 'Upcoming';

    if ($title === '' || $game === '' || $matchTime === '') {
        $flash = ['type' => 'error', 'text' => 'Title, game and match time are required.'];
    } else {
        db()->prepare(
            'INSERT INTO tournaments (title, game_name, entry_fee, prize_pool, match_time, status)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([$title, $game, $fee, $prize, $matchTime, $status]);
        $flash = ['type' => 'success', 'text' => 'Tournament created.'];
    }
    $_SESSION['admin_flash'] = $flash;
    redirect('tournaments.php');
}

// ---- UPDATE ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_tournament'])) {
    csrf_verify();
    $id = (int)$_POST['id'];
    $title = trim($_POST['title'] ?? '');
    $game = trim($_POST['game_name'] ?? '');
    $fee = round((float)($_POST['entry_fee'] ?? 0), 2);
    $prize = round((float)($_POST['prize_pool'] ?? 0), 2);
    $matchTime = trim($_POST['match_time'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['Upcoming', 'Live', 'Completed']) ? $_POST['status'] : 'Upcoming';

    db()->prepare(
        'UPDATE tournaments SET title=?, game_name=?, entry_fee=?, prize_pool=?, match_time=?, status=? WHERE id=?'
    )->execute([$title, $game, $fee, $prize, $matchTime, $status, $id]);
    $flash = ['type' => 'success', 'text' => 'Tournament updated.'];
    $_SESSION['admin_flash'] = $flash;
    redirect('tournaments.php');
}

// ---- DELETE ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_tournament'])) {
    csrf_verify();
    db()->prepare('DELETE FROM tournaments WHERE id = ?')->execute([(int)$_POST['id']]);
    $flash = ['type' => 'success', 'text' => 'Tournament deleted.'];
    $_SESSION['admin_flash'] = $flash;
    redirect('tournaments.php');
}

// ---- SAVE ROOM ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_room'])) {
    csrf_verify();
    $id = (int)$_POST['tournament_id'];
    $roomId = trim($_POST['room_id'] ?? '');
    $roomPass = trim($_POST['room_password'] ?? '');
    db()->prepare('UPDATE tournaments SET room_id=?, room_password=? WHERE id=?')
        ->execute([$roomId !== '' ? $roomId : null, $roomPass !== '' ? $roomPass : null, $id]);
    $flash = ['type' => 'success', 'text' => 'Room details saved.'];
    $_SESSION['admin_flash'] = $flash;
    redirect('tournaments.php');
}

// ---- DECLARE WINNER ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['declare_winner'])) {
    csrf_verify();
    $id = (int)$_POST['tournament_id'];
    $winnerId = (int)$_POST['winner_user_id'];

    $t = db()->prepare('SELECT * FROM tournaments WHERE id = ?');
    $t->execute([$id]);
    $tournament = $t->fetch();

    if (!$tournament) {
        $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'Tournament not found.'];
    } elseif ($tournament['status'] === 'Completed') {
        $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'Tournament is already completed.'];
    } elseif (!$winnerId) {
        $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'Select a winner participant.'];
    } else {
        $w = db()->prepare('SELECT id, wallet_balance FROM users WHERE id = ?');
        $w->execute([$winnerId]);
        $winner = $w->fetch();
        if (!$winner) {
            $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'Winner user not found.'];
        } else {
            db()->beginTransaction();
            try {
                $prize = (float)$tournament['prize_pool'];
                db()->prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?')
                    ->execute([$prize, $winnerId]);
                log_transaction($winnerId, $prize, 'credit', 'Prize won — ' . $tournament['title']);
                db()->prepare('UPDATE tournaments SET status = "Completed", winner_user_id = ? WHERE id = ?')
                    ->execute([$winnerId, $id]);
                db()->commit();
                $_SESSION['admin_flash'] = ['type' => 'success', 'text' => 'Winner declared. Prize pool credited to wallet.'];
            } catch (Exception $e) {
                db()->rollBack();
                $_SESSION['admin_flash'] = ['type' => 'error', 'text' => 'Could not declare winner.'];
            }
        }
    }
    redirect('tournaments.php');
}

// ---- Load data ----
$tournaments = db()->query('SELECT * FROM tournaments ORDER BY created_at DESC')->fetchAll();

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$edit = null;
if ($editId) {
    $eStmt = db()->prepare('SELECT * FROM tournaments WHERE id = ?');
    $eStmt->execute([$editId]);
    $edit = $eStmt->fetch();
}
?>
<?php if ($flash): ?>
  <div class="mb-4 rounded-xl px-4 py-3 text-sm flex items-center gap-2 <?= $flash['type'] === 'error' ? 'bg-red-500/10 border border-red-500/30 text-red-300' : 'bg-green-500/10 border border-green-500/30 text-green-300' ?>">
    <i class="fa-solid <?= $flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <?= e($flash['text']) ?>
  </div>
<?php endif; ?>

<div class="flex items-center justify-between mb-4">
  <h2 class="text-xl font-extrabold">Tournaments</h2>
  <span class="text-xs text-gray-400"><?= count($tournaments) ?> total</span>
</div>

<!-- Create / Edit form -->
<div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow mb-5">
  <h3 class="font-bold mb-4 flex items-center gap-2">
    <i class="fa-solid <?= $edit ? 'fa-pen' : 'fa-plus' ?> text-purple-400"></i>
    <?= $edit ? 'Edit Tournament' : 'Create Tournament' ?>
  </h3>
  <form method="post" class="space-y-3">
    <?= csrf_field() ?>
    <?php if ($edit): ?>
      <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
    <?php endif; ?>
    <div class="grid grid-cols-2 gap-3">
      <div class="col-span-2">
        <label class="text-xs text-gray-400 mb-1 block">Title</label>
        <input type="text" name="title" required value="<?= $edit ? e($edit['title']) : '' ?>" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500" placeholder="BGMI Season Final">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Game</label>
        <input type="text" name="game_name" required value="<?= $edit ? e($edit['game_name']) : '' ?>" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500" placeholder="BGMI">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Status</label>
        <select name="status" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500">
          <?php foreach (['Upcoming', 'Live', 'Completed'] as $s): ?>
            <option value="<?= $s ?>" <?= ($edit && $edit['status'] === $s) ? 'selected' : '' ?>><?= $s ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Entry Fee (₹)</label>
        <input type="number" name="entry_fee" step="0.01" min="0" value="<?= $edit ? e($edit['entry_fee']) : '0' ?>" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Prize Pool (₹)</label>
        <input type="number" name="prize_pool" step="0.01" min="0" value="<?= $edit ? e($edit['prize_pool']) : '0' ?>" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500">
      </div>
      <div class="col-span-2">
        <label class="text-xs text-gray-400 mb-1 block">Match Time</label>
        <input type="datetime-local" name="match_time" required value="<?= $edit ? e(date('Y-m-d\TH:i', strtotime($edit['match_time']))) : '' ?>" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-purple-500">
      </div>
    </div>
    <button type="submit" name="<?= $edit ? 'update_tournament' : 'create_tournament' ?>" value="1"
      class="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl py-3 text-sm transition">
      <i class="fa-solid <?= $edit ? 'fa-check' : 'fa-circle-plus' ?> mr-2"></i><?= $edit ? 'Save Changes' : 'Create Tournament' ?>
    </button>
    <?php if ($edit): ?>
      <a href="tournaments.php" class="block text-center text-xs text-gray-500 hover:text-gray-300">Cancel edit</a>
    <?php endif; ?>
  </form>
</div>

<!-- Tournament list -->
<div class="space-y-4">
  <?php foreach ($tournaments as $t): ?>
    <?php
      $players = db()->prepare('SELECT u.id, u.username, u.upi_id FROM participants p JOIN users u ON u.id=p.user_id WHERE p.tournament_id=? ORDER BY p.joined_at');
      $players->execute([$t['id']]);
      $participants = $players->fetchAll();
      $winnerName = null;
      if (!empty($t['winner_user_id'])) {
          $wn = db()->prepare('SELECT username FROM users WHERE id = ?');
          $wn->execute([$t['winner_user_id']]);
          $winnerName = $wn->fetchColumn() ?: 'User #' . $t['winner_user_id'];
      }
    ?>
    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-4 shadow">
      <div class="flex items-start justify-between gap-3">
        <div class="min-w-0">
          <div class="flex items-center gap-2 flex-wrap">
            <span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase
              <?= $t['status'] === 'Completed' ? 'bg-gray-700/40 text-gray-300' : ($t['status'] === 'Live' ? 'bg-red-500/15 text-red-400' : 'bg-blue-500/15 text-blue-400') ?>">
              <?= e($t['status']) ?>
            </span>
            <span class="text-[10px] text-gray-500"><?= e(date('d M, h:i A', strtotime($t['match_time']))) ?></span>
          </div>
          <h4 class="font-bold text-white mt-1 leading-snug"><?= e($t['title']) ?></h4>
          <div class="text-xs text-gray-400 mt-0.5">
            <i class="fa-solid fa-gamepad mr-1"></i><?= e($t['game_name']) ?> ·
            Fee <?= e(money($t['entry_fee'])) ?> · Prize <span class="text-green-400 font-semibold"><?= e(money($t['prize_pool'])) ?></span>
          </div>
        </div>
        <div class="flex gap-2 shrink-0">
          <a href="tournaments.php?edit=<?= (int)$t['id'] ?>" class="w-9 h-9 rounded-lg bg-gray-800 hover:bg-gray-700 flex items-center justify-center text-indigo-300 transition">
            <i class="fa-solid fa-pen text-xs"></i>
          </a>
          <form method="post" onsubmit="return confirm('Delete this tournament?')">
            <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
            <?= csrf_field() ?>
            <button type="submit" name="delete_tournament" value="1" class="w-9 h-9 rounded-lg bg-gray-800 hover:bg-red-500/20 flex items-center justify-center text-red-400 transition">
              <i class="fa-solid fa-trash text-xs"></i>
            </button>
          </form>
        </div>
      </div>

      <!-- Room + players -->
      <div class="mt-3 bg-gray-800/40 rounded-xl p-3">
        <form method="post" class="grid grid-cols-[1fr_1fr_auto] gap-2 mb-3">
          <input type="hidden" name="tournament_id" value="<?= (int)$t['id'] ?>">
          <?= csrf_field() ?>
          <input type="text" name="room_id" value="<?= e($t['room_id'] ?? '') ?>" placeholder="Room ID" class="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-xs outline-none focus:border-purple-500">
          <input type="text" name="room_password" value="<?= e($t['room_password'] ?? '') ?>" placeholder="Password" class="bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-xs outline-none focus:border-purple-500">
          <button type="submit" name="save_room" value="1" class="bg-purple-600 hover:bg-purple-500 text-white rounded-lg px-3 text-xs font-semibold transition">
            <i class="fa-solid fa-floppy-disk"></i>
          </button>
        </form>

        <div class="text-[10px] text-gray-400 uppercase tracking-wide mb-1">Players (<?= count($participants) ?>)</div>
        <?php if (empty($participants)): ?>
          <div class="text-xs text-gray-600 py-1">No players joined yet.</div>
        <?php else: ?>
          <ul class="space-y-1">
            <?php foreach ($participants as $p): ?>
              <li class="flex items-center justify-between text-sm">
                <span class="flex items-center gap-2">
                  <i class="fa-solid fa-user text-gray-500 text-xs"></i>
                  <?= e($p['username']) ?>
                </span>
                <span class="text-[10px] text-gray-500"><?= e($p['upi_id'] ?: 'no UPI') ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>

        <!-- Declare winner -->
        <?php if ($t['status'] !== 'Completed' && !empty($participants)): ?>
          <form method="post" class="mt-3 flex items-end gap-2">
            <input type="hidden" name="tournament_id" value="<?= (int)$t['id'] ?>">
            <?= csrf_field() ?>
            <div class="flex-1">
              <label class="text-[10px] text-gray-400 mb-1 block">Declare Winner</label>
              <select name="winner_user_id" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-xs outline-none focus:border-green-500">
                <option value="">Select player…</option>
                <?php foreach ($participants as $p): ?>
                  <option value="<?= (int)$p['id'] ?>"><?= e($p['username']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <button type="submit" name="declare_winner" value="1" class="bg-green-600 hover:bg-green-500 text-white rounded-lg px-4 py-2 text-xs font-bold transition">
              <i class="fa-solid fa-crown mr-1"></i>Win
            </button>
          </form>
        <?php elseif ($t['status'] === 'Completed'): ?>
          <div class="mt-3 text-xs text-gray-400">
            <i class="fa-solid fa-flag-checkered mr-1 text-green-400"></i>
            Winner: <b class="text-white"><?= e($winnerName ?: '—') ?></b>
          </div>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/_footer.php'; ?>
