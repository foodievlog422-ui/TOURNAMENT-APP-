<?php
/**
 * EXALOTE EXN — Admin: forced password change (first login / default password).
 * Accessible only to logged-in admins; does not require the OLD password to be
 * non-default (but does require the current password to authenticate).
 */
$page_title = 'Change Password';
$active_admin = 'settings';
require_once __DIR__ . '/../common/config.php';

if (!is_admin()) {
    redirect('login.php');
}

$error = null;
$ok = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $a = db()->prepare('SELECT password FROM admin WHERE id = ?');
    $a->execute([$_SESSION['admin_id']]);
    $hash = $a->fetchColumn();

    if (!password_verify($current, (string)$hash)) {
        $error = 'Current password is incorrect.';
    } elseif (strlen($new) < 8) {
        $error = 'New password must be at least 8 characters.';
    } elseif ($new !== $confirm) {
        $error = 'New passwords do not match.';
    } else {
        db()->prepare('UPDATE admin SET password = ? WHERE id = ?')
            ->execute([password_hash($new, PASSWORD_BCRYPT), $_SESSION['admin_id']]);
        $ok = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0a0a0a">
<title>Change Password · EXALOTE EXN</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>:root{color-scheme:dark}</style>
</head>
<body class="bg-[#0a0a0a] text-gray-100 min-h-screen flex items-center justify-center px-5">
  <div class="w-full max-w-md bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-2xl">
    <div class="text-center mb-5">
      <div class="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-br from-red-500 to-black flex items-center justify-center text-white text-2xl mb-3">
        <i class="fa-solid fa-lock"></i>
      </div>
      <h1 class="text-xl font-extrabold">Set a New Admin Password</h1>
      <p class="text-gray-400 text-sm mt-1">You must change the default password before continuing.</p>
    </div>

    <?php if ($ok): ?>
      <div class="bg-green-500/10 border border-green-500/30 text-green-300 text-sm rounded-xl px-4 py-3 mb-4">
        <i class="fa-solid fa-check mr-2"></i>Password updated successfully.
      </div>
      <a href="dashboard.php" class="block text-center w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl py-3 transition">Go to Dashboard</a>
    <?php else: ?>
      <?php if ($error): ?>
        <div class="bg-red-500/10 border border-red-500/30 text-red-300 text-sm rounded-xl px-4 py-3 mb-4">
          <i class="fa-solid fa-circle-exclamation mr-2"></i><?= e($error) ?>
        </div>
      <?php endif; ?>
      <form method="post" class="space-y-3">
        <?= csrf_field() ?>
        <div>
          <label class="text-xs text-gray-400 mb-1 block">Current Password</label>
          <input type="password" name="current_password" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
        </div>
        <div>
          <label class="text-xs text-gray-400 mb-1 block">New Password (min 8 chars)</label>
          <input type="password" name="new_password" required minlength="8" class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
        </div>
        <div>
          <label class="text-xs text-gray-400 mb-1 block">Confirm New Password</label>
          <input type="password" name="confirm_password" required class="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-sm outline-none focus:border-amber-500">
        </div>
        <button type="submit" class="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl py-3 transition">Update Password</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
