-- ============================================================
-- EXALOTE EXN — Full Database Schema
-- Execute: mariadb -u root -proot < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS tournament_app
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tournament_app;

-- ------------------------------------------------------------
-- Users
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(120) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  wallet_balance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  deposit_balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  winnings_balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  bonus_balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  ff_uid VARCHAR(30) NULL,
  ff_ign VARCHAR(60) NULL,
  upi_id VARCHAR(100) NULL,
  virtual_points INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Admin
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO admin (username, password) VALUES ('admin', '$2y$12$aC4LQi0mlJ2X2uP5Aiye7entEvSnhRTo.5TQPUxm7p7CudLF1uLDW')
  ON DUPLICATE KEY UPDATE id = id;

-- ------------------------------------------------------------
-- Tournaments
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tournaments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  game_name VARCHAR(80) NOT NULL,
  entry_fee DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  prize_pool DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  match_time DATETIME NOT NULL,
  room_id VARCHAR(80) NULL,
  room_password VARCHAR(80) NULL,
  status ENUM('Upcoming','Live','Completed') NOT NULL DEFAULT 'Upcoming',
  winner_user_id INT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_status (status)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Participants
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS participants (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  tournament_id INT UNSIGNED NOT NULL,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_participant (user_id, tournament_id),
  CONSTRAINT fk_part_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_part_tourn FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Transactions
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS transactions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  type ENUM('credit','debit','points') NOT NULL,
  description VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_tx_user (user_id, created_at),
  CONSTRAINT fk_tx_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Deposits
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS deposits (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  transaction_id VARCHAR(100) NOT NULL,
  status ENUM('Pending','Completed','Rejected') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dep_transaction (transaction_id),
  INDEX idx_dep_status (status),
  CONSTRAINT fk_dep_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Withdrawals
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS withdrawals (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  status ENUM('Pending','Completed','Rejected') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_wd_status (status),
  CONSTRAINT fk_wd_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Settings
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  id TINYINT NOT NULL DEFAULT 1 PRIMARY KEY,
  upi_id VARCHAR(100) NULL,
  qr_code VARCHAR(255) NULL,
  automation_enabled TINYINT(1) NOT NULL DEFAULT 1,
  duration_min INT NOT NULL DEFAULT 20,
  buffer_min INT NOT NULL DEFAULT 5,
  capacity_default INT NOT NULL DEFAULT 10,
  last_generated_date DATE NULL,
  skip_dates TEXT NULL,
  reward_rank_json TEXT NULL,
  reward_participation DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  reward_per_kill DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  wallet_enabled TINYINT(1) NOT NULL DEFAULT 1,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO settings (id, upi_id, reward_rank_json)
VALUES (1, 'admin@upi', '{"1":250,"2":150,"3":100}')
ON DUPLICATE KEY UPDATE id = id;

-- ------------------------------------------------------------
-- Categories (EXALOTE EXN — 9 match categories)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  format VARCHAR(30) NOT NULL DEFAULT 'Solo',
  code VARCHAR(60) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_code (code)
) ENGINE=InnoDB;

INSERT IGNORE INTO categories (name, format, code, sort_order) VALUES
  ('Lone Wolf Body',    'Solo', 'lone-wolf-body',      1),
  ('Lone Wolf Headshot', 'Solo', 'lone-wolf-headshot', 2),
  ('Full Map Per Kill', 'Solo', 'full-map-per-kill',   3),
  ('Full Map Survival',  'Solo', 'full-map-survival',   4),
  ('Headshot',           '1v1', 'headshot-1v1',        5),
  ('Headshot',           '2v2', 'headshot-2v2',        6),
  ('UMP',                '1v1', 'ump-1v1',             7),
  ('Shotgun',            '1v1', 'shotgun-1v1',         8),
  ('Desert Eagle',       '1v1', 'desert-eagle-1v1',    9);

-- ------------------------------------------------------------
-- Matches (admin-scheduled, single host)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS matches (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  match_date DATE NOT NULL,
  session ENUM('morning','evening') NOT NULL,
  start_time TIME NOT NULL,
  player_capacity INT NOT NULL DEFAULT 10,
  entry_fee DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  prize_pool DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  status ENUM('Upcoming','Registration Closed','Live','Completed','Cancelled') NOT NULL DEFAULT 'Upcoming',
  winner_user_id INT UNSIGNED NULL,
  published TINYINT(1) NOT NULL DEFAULT 0,
  host_note VARCHAR(255) NULL,
  room_id VARCHAR(50) NULL,
  room_password VARCHAR(50) NULL,
  room_published TINYINT(1) NOT NULL DEFAULT 0,
  map_name VARCHAR(50) NOT NULL DEFAULT 'Bermuda',
  match_rules TEXT NULL,
  prizes_distributed TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cat_date_session (category_id, match_date, session),
  KEY idx_date (match_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Registrations (free player signups)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS registrations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  match_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  status ENUM('Approved','Pending','Rejected') NOT NULL DEFAULT 'Pending',
  fee_status ENUM('none','paid','refunded') NOT NULL DEFAULT 'none',
  ff_uid VARCHAR(30) NULL,
  ff_ign VARCHAR(60) NULL,
  slot_number INT NULL,
  team_members TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_match_user (match_id, user_id),
  UNIQUE KEY uq_match_ffuid (match_id, ff_uid)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Player result claims (screenshot + kill/rank claim + hack report)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS match_claims (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  match_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  claimed_kills INT NOT NULL DEFAULT 0,
  claimed_rank INT NOT NULL DEFAULT 0,
  screenshot_path VARCHAR(255) NULL,
  report_suspect_ign VARCHAR(100) NULL,
  report_reason TEXT NULL,
  status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_match_user_claim (match_id, user_id),
  KEY idx_claim_status (status),
  CONSTRAINT fk_claim_match FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
  CONSTRAINT fk_claim_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Custom requests
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS custom_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(120) NOT NULL,
  category_name VARCHAR(100) NOT NULL,
  format VARCHAR(30) NOT NULL DEFAULT 'Solo',
  match_date DATE NOT NULL,
  start_time TIME NOT NULL,
  notes TEXT NULL,
  status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  admin_note VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Notifications (in-app)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  message TEXT NOT NULL,
  kind VARCHAR(40) NULL,
  link VARCHAR(255) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user (user_id, is_read)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Results (rank/kills/rewards — unique (match_id,user_id) blocks double-pay)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS results (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  match_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  rank INT NOT NULL DEFAULT 0,
  kills INT NOT NULL DEFAULT 0,
  reward_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_match_user (match_id, user_id),
  KEY idx_match (match_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Login rate limiting
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  identifier VARCHAR(120) NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  attempted_at INT UNSIGNED NOT NULL,
  KEY idx_attempt (identifier, ip_address, attempted_at)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Admin event log
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event VARCHAR(80) NOT NULL,
  payload TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_event (event)
) ENGINE=InnoDB;

-- ============================================================
-- End of schema
-- ============================================================
